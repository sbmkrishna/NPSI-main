alter table EventTeam
add SortOrder int