﻿alter table dbo.Score alter column Score decimal(4, 2) NULL;
GO
