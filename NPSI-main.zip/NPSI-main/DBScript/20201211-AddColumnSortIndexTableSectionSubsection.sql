ALTER TABLE SectionSubsection
ADD SortIndex int