/*
select uer.UserID, e.[Name] as EventName, e.StartDateTime
  , s.[Name] as SectionName
  , c.[Name] as CategoryName
  , r.[Name] as RoleName
from dbo.UserEventRole uer
join dbo.[Event] e on uer.EventID = e.ID
join dbo.Category c on uer.CategoryID = c.ID
join dbo.AspNetRoles r on uer.RoleID = r.Id
left join dbo.JudgeSectionAssignment jsa on uer.UserID = jsa.JudgeUserID and uer.EventID = jsa.EventID
left join dbo.Section s on jsa.SectionID = s.ID;


select sc.ID, sc.Score, sc.CreatedDateTime, sc.SubsectionID, sc.JudgeUserID, sc.TeamID, sc.EventID, sc.SectionID, sc.Comments, sc.Photo
from dbo.Score sc
join dbo.[Event] e on sc.EventID = e.ID
join dbo.Team t on sc.TeamID = t.ID
left join dbo.Section s on sc.SectionID = s.ID
left join dbo.Subsection ss on sc.SubsectionID = ss.ID
where sc.JudgeUserID = '9f15bdd0fcd5423190c2e877ba0228ee'
and sc.EventID = 4
*/

alter table dbo.AspNetUsers add Organization nvarchar(256);
go
