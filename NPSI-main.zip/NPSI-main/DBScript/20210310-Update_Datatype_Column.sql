ALTER TABLE Score
ALTER COLUMN Score decimal(4, 2) not null