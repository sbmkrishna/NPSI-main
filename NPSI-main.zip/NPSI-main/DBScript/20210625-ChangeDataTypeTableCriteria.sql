ALTER TABLE Criteria
ALTER COLUMN Title nvarchar(255) null