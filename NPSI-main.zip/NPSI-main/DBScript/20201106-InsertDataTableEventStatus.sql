INSERT INTO EventStatus VALUES(1,'Opened','O')
INSERT INTO EventStatus VALUES(2,'Started','S')
INSERT INTO EventStatus VALUES(3,'Completed','C')