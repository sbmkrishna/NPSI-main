sp_RENAME 'Penalty.Deduction', 'DeductionMin', 'COLUMN' 

ALTER TABLE Penalty
ADD DeductionMax int null;