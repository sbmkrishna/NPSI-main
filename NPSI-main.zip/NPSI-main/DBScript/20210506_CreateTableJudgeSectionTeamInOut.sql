-- ****************** SqlDBM: Microsoft SQL Server ******************
-- ******************************************************************
-- ************************************** [JudgeSectionTeamInOut]
CREATE TABLE [JudgeSectionTeamInOut]
(
 [TeamID]      int NOT NULL ,
 [JudgeUserID] nvarchar(128) NOT NULL ,
 [SectionID]   int NOT NULL ,
 [EventID]     int NOT NULL ,
 [TimeIn]      smalldatetime NULL ,
 [TimeOut]     smalldatetime NULL ,

 CONSTRAINT [PK_judgesectionteam] PRIMARY KEY CLUSTERED ([TeamID] ASC, [JudgeUserID] ASC, [SectionID] ASC, [EventID] ASC),
 CONSTRAINT [FK_JudgeSectionTeamInOut_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_JudgeSectionTeamInOut_Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID]),
 CONSTRAINT [FK_JudgeSectionTeamInOut_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID]),
 CONSTRAINT [FK_JudgeSectionTeamInOut_AspNetUsers_JudgeUserID] FOREIGN KEY ([JudgeUserID])  REFERENCES [AspNetUsers]([ID])
);
GO

CREATE NONCLUSTERED INDEX [fkIdx_607] ON [JudgeSectionTeamInOut] 
 (
  [TeamID] ASC
 )
GO
CREATE NONCLUSTERED INDEX [fkIdx_610] ON [JudgeSectionTeamInOut] 
 (
  [JudgeUserID] ASC
 )
GO
CREATE NONCLUSTERED INDEX [fkIdx_613] ON [JudgeSectionTeamInOut] 
 (
  [SectionID] ASC
 )
GO
CREATE NONCLUSTERED INDEX [fkIdx_616] ON [JudgeSectionTeamInOut] 
 (
  [EventID] ASC
 )
GO