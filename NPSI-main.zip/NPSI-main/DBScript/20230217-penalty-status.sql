create table dbo.PenaltyStatus (
ID int not null constraint PK_PenaltyStatus primary key
,StatusName nvarchar(50) not null
,StatusCode nvarchar(50) not null
);
GO

insert into dbo.PenaltyStatus values
(0, 'Pending', 'P')
,(-1, 'Denied', 'D')
,(1, 'Approved', 'A');
GO

alter table dbo.TeamSectionPenalty add PenaltyStatusID int;
GO

update dbo.TeamSectionPenalty set PenaltyStatusID = 1;
GO

alter table dbo.TeamSectionPenalty alter column PenaltyStatusID int not null;
GO

alter table dbo.TeamSectionPenalty add 
	constraint FK_TeamSectionPenalty_PenaltyStatus foreign key (PenaltyStatusID) references dbo.PenaltyStatus;
GO

