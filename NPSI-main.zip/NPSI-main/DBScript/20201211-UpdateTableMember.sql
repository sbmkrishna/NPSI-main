ALTER TABLE Member
ALTER COLUMN Email nvarchar(255)

ALTER TABLE Member
ALTER COLUMN Phone nvarchar(255)