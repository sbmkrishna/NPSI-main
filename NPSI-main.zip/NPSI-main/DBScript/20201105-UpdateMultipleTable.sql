GO
ALTER TABLE Section
ALTER COLUMN Description nvarchar(max) not null

GO
ALTER TABLE Subsection
ALTER COLUMN Description nvarchar(max) not null

GO 
ALTER TABLE Team
ALTER COLUMN Name nvarchar(255) not null

GO 
ALTER TABLE Team
ALTER COLUMN Email nvarchar(255) not null

GO 
ALTER TABLE Member
ALTER COLUMN Name nvarchar(255) not null

GO 
ALTER TABLE Member
ALTER COLUMN Email nvarchar(255) not null

GO 
ALTER TABLE Member
ALTER COLUMN Phone nvarchar(20) not null

GO 
ALTER TABLE Event
ALTER COLUMN Name nvarchar(255) not null