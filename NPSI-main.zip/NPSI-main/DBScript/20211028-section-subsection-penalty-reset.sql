﻿update dbo.Section
set SortOrder = 3
where [Name] = 'Safety and Sanitation';

update dbo.Section
set SortOrder = 4
where [Name] = 'Product Taste - Starter';

update dbo.Section
set SortOrder = 5
where [Name] = 'Product Taste - Entrée';

update dbo.Section
set SortOrder = 6
where [Name] = 'Product Taste - Dessert';

update dbo.Section
set SortOrder = 7
where [Name] = 'Menu and Recipe Presentation';

--select s.Name as Section, ss.* 
update ss set ss.SortIndex = 4
from dbo.Subsection ss
join dbo.Section s on ss.SectionID = s.ID
where s.[Name] = 'Team Presentation / Work Skills / Organization'
and ss.[Name] = 'Proper Knife Usage';

update ss set ss.SortIndex = 5
from dbo.Subsection ss
join dbo.Section s on ss.SectionID = s.ID
where s.[Name] = 'Team Presentation / Work Skills / Organization'
and ss.[Name] = 'Degree of Difficulty';

insert into dbo.Section (Name, Description, Active, CategoryID, SortOrder, TimeInOutNeeded)
values ('Management Check-In','Management Check-In',1,1,1,0);

insert into dbo.Subsection (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex)
select 'Check-In'
  , '<p>Including, but not limited to:</p><ul><li>Arrival within timeframe</li><li>Items meet specifications</li><li>Complete submission</li><li>Uniform<br></li></ul>'
  , 5, 1, 1, ID, 1
from dbo.Section
where [Name] = 'Management Check-In'
and CategoryID = 1;

update dbo.Section
set SortOrder = 2
where [Name] = 'Menu & Recipe Costing';

update dbo.Section
set SortOrder = 3
where [Name] = 'Critical Thinking';

update dbo.Section
set SortOrder = 4
where [Name] = 'Concept';

update dbo.Section
set SortOrder = 5
where [Name] = 'Menu Costing';

update dbo.Section
set SortOrder = 6
where [Name] = 'Marketing';

update dbo.Section
set SortOrder = 7
where [Name] = 'Operations';

insert into dbo.EventSection (SectionID, EventID)
select s.ID, e.ID
from dbo.Section s, dbo.Event e
where s.[Name] = 'Management Check-In'
and s.CategoryID = 1;


delete dbo.TeamSectionPenalty;
delete dbo.SectionPenalty;
delete dbo.Penalty;

alter table Penalty alter column DeductionMin numeric(4,2) not null;
alter table Penalty alter column DeductionMax numeric(4,2);
GO

insert into dbo.Penalty (Name, DeductionMin, DeductionMax, Active)
select T.PName, T.Vmin, T.Vmax, T.ActiveYn
from
(values ('Team does not complete competition segment within their allotted time – ¼ pt to 10 pts',0.25,'10',1,2)
,('Station left in unsanitary manner – 3 pts',3,NULL,1,2)
,('Team did not submit folders with menu, plate photographs, recipe and recipe costing at Product Check-In – 2 pts',2,NULL,1,2)
,('Replacement product did not meet requirements and was discarded – 2 pts.',5,NULL,1,2)
,('Team manager touches or handles any equipment or food when not allowed – 5 pts',5,NULL,1,2)
,('Team not dressed in uniform – 5 pts.',5,NULL,1,2)
,('Team produces two meals, which are not identical – 2 pts',2,NULL,1,2)
,('Team begins competition segment before their assigned start time – ¼ pt to 10 pts',0.25,'10',1,2)
,('Team uses dishes/glassware other than those provided by Event Organizers – 5 pts',5,NULL,1,2)
,('Use of pre-prepared ingredients or prohibited equipment– 5 pts',5,NULL,1,2)

,('Team submits food costing worksheets for more or fewer than 1 menu item – 5 points',5,NULL,1,1)
,('Team submits more or fewer than 1 menu pricing worksheet – 5 points',5,NULL,1,1)
,('Team submits more or fewer than 2 marketing tactics – 5 points',5,NULL,1,1)
,('Team submits recipes for more or fewer than 1 menu item – 5 points',5,NULL,1,1)
,('Team not dressed in uniform – 5 points',5,NULL,1,1)
,('Posters do not meet specifications or include additional information – 5 points',5,NULL,1,1)
,('Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points',5,NULL,1,1)
,('Team includes an alcoholic beverage as one of their menu items – 5 points',5,NULL,1,1)
,('Team submits more or fewer than 12 menu items – 5 points',5,NULL,1,1)
,('Team uses an alcohol-related activity or promotion as one of their marketing tactics – 5 points',5,NULL,1,1)
,('Team did not successfully submit all items, items did not meet specifications. 1 point to 5 points.',1,5,1,1)) as T(PName, Vmin,Vmax, ActiveYn, CategoryID);


insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Operations'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Posters do not meet specifications or include additional information – 5 points'
,'Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points'
,'Team submits more or fewer than 12 menu items – 5 points'
,'Team includes an alcoholic beverage as one of their menu items – 5 points'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Marketing'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Posters do not meet specifications or include additional information – 5 points'
,'Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points'
,'Team submits more or fewer than 12 menu items – 5 points'
,'Team includes an alcoholic beverage as one of their menu items – 5 points'
,'Team submits more or fewer than 2 marketing tactics – 5 points'
,'Team uses an alcohol-related activity or promotion as one of their marketing tactics – 5 points'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Menu Costing'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Posters do not meet specifications or include additional information – 5 points'
,'Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points'
,'Team submits more or fewer than 12 menu items – 5 points'
,'Team includes an alcoholic beverage as one of their menu items – 5 points'
,'Team submits recipes for more or fewer than 1 menu item – 5 points'
,'Team submits food costing worksheets for more or fewer than 1 menu item – 5 points'
,'Team submits more or fewer than 1 menu pricing worksheet – 5 points'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Concept'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Posters do not meet specifications or include additional information – 5 points'
,'Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points'
,'Team submits more or fewer than 12 menu items – 5 points'
,'Team includes an alcoholic beverage as one of their menu items – 5 points'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Critical Thinking'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Posters do not meet specifications or include additional information – 5 points'
,'Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points'
,'Team submits more or fewer than 12 menu items – 5 points'
,'Team includes an alcoholic beverage as one of their menu items – 5 points'
,'Team uses an alcohol-related activity or promotion as one of their marketing tactics – 5 points'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Menu & Recipe Costing'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Restaurant concept is not located in ProStartville or does not match one of the provided restaurant space scenarios – 5 points'
,'Team submits more or fewer than 12 menu items – 5 points'
,'Team includes an alcoholic beverage as one of their menu items – 5 points'
,'Team submits recipes for more or fewer than 1 menu item – 5 points'
,'Team submits food costing worksheets for more or fewer than 1 menu item – 5 points'
,'Team submits more or fewer than 1 menu pricing worksheet – 5 points'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 1
and s.[Name] = 'Management Check-In'
and p.[Name] in (
'Team not dressed in uniform – 5 points'
,'Team did not successfully submit all items, items did not meet specifications. 1 point to 5 points.'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Menu and Recipe Presentation'
and p.[Name] in (
'Team did not submit folders with menu, plate photographs, recipe and recipe costing at Product Check-In – 2 pts'
,'Team not dressed in uniform – 5 pts.'
,'Team manager touches or handles any equipment or food when not allowed – 5 pts'
,'Team begins competition segment before their assigned start time – ¼ pt to 10 pts'
,'Team does not complete competition segment within their allotted time – ¼ pt to 10 pts'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Product Taste - Dessert'
and p.[Name] in (
'Team not dressed in uniform – 5 pts.'
,'Replacement product did not meet requirements and was discarded – 2 pts.'
,'Team manager touches or handles any equipment or food when not allowed – 5 pts'
,'Team uses dishes/glassware other than those provided by Event Organizers – 5 pts'
,'Team begins competition segment before their assigned start time – ¼ pt to 10 pts'
,'Team does not complete competition segment within their allotted time – ¼ pt to 10 pts'
,'Use of pre-prepared ingredients or prohibited equipment– 5 pts'
,'Team produces two meals, which are not identical – 2 pts'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Product Taste - Entrée'
and p.[Name] in (
'Team not dressed in uniform – 5 pts.'
,'Replacement product did not meet requirements and was discarded – 2 pts.'
,'Team manager touches or handles any equipment or food when not allowed – 5 pts'
,'Team uses dishes/glassware other than those provided by Event Organizers – 5 pts'
,'Team begins competition segment before their assigned start time – ¼ pt to 10 pts'
,'Team does not complete competition segment within their allotted time – ¼ pt to 10 pts'
,'Use of pre-prepared ingredients or prohibited equipment– 5 pts'
,'Team produces two meals, which are not identical – 2 pts'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Product Taste - Starter'
and p.[Name] in (
'Team not dressed in uniform – 5 pts.'
,'Replacement product did not meet requirements and was discarded – 2 pts.'
,'Team manager touches or handles any equipment or food when not allowed – 5 pts'
,'Team uses dishes/glassware other than those provided by Event Organizers – 5 pts'
,'Team begins competition segment before their assigned start time – ¼ pt to 10 pts'
,'Team does not complete competition segment within their allotted time – ¼ pt to 10 pts'
,'Use of pre-prepared ingredients or prohibited equipment– 5 pts'
,'Team produces two meals, which are not identical – 2 pts'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Safety and Sanitation'
and p.[Name] in (
'Team not dressed in uniform – 5 pts.'
,'Replacement product did not meet requirements and was discarded – 2 pts.'
,'Team manager touches or handles any equipment or food when not allowed – 5 pts'
,'Team uses dishes/glassware other than those provided by Event Organizers – 5 pts'
,'Team begins competition segment before their assigned start time – ¼ pt to 10 pts'
,'Team does not complete competition segment within their allotted time – ¼ pt to 10 pts'
,'Use of pre-prepared ingredients or prohibited equipment– 5 pts'
,'Team produces two meals, which are not identical – 2 pts'
,'Station left in unsanitary manner – 3 pts'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Team Presentation / Work Skills / Organization'
and p.[Name] in (
'Team not dressed in uniform – 5 pts.'
,'Replacement product did not meet requirements and was discarded – 2 pts.'
,'Team manager touches or handles any equipment or food when not allowed – 5 pts'
,'Team uses dishes/glassware other than those provided by Event Organizers – 5 pts'
,'Team begins competition segment before their assigned start time – ¼ pt to 10 pts'
,'Team does not complete competition segment within their allotted time – ¼ pt to 10 pts'
,'Use of pre-prepared ingredients or prohibited equipment– 5 pts'
,'Team produces two meals, which are not identical – 2 pts'
,'Station left in unsanitary manner – 3 pts'
);

insert into dbo.SectionPenalty (SectionID, PenaltyID)
select s.ID, p.ID
from dbo.Section s, dbo.Penalty p
where s.CategoryID = 2 
and s.[Name] = 'Product Check-in'
and p.[Name] in (
'Team not dressed in uniform – 5 pts.'
,'Team did not submit folders with menu, plate photographs, recipe and recipe costing at Product Check-In – 2 pts'
,'Replacement product did not meet requirements and was discarded – 2 pts.'
);

update dbo.Disqualification
set Name = 'Team started competition segment more than 10 minutes early, or finished more than 10 minutes late.'
where ID = 11;

--select sd.SectionID, s.Name as Section, sd.DisqualificationID, d.Name as Disqualification
delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
join dbo.Disqualification d on sd.DisqualificationID = d.ID
where s.CategoryID = 2
and s.Name = 'Product Check-in'
and d.Name = 'Team did not compete in each segment';

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Safety and Sanitation'
and d.Name in (
'Team did not produce two (2) complete meals.'
,'Team used an electric/battery operated device or additional butane burner.'
,'Team started competition segment more than 10 minutes early, or finished more than 10 minutes late.'
);

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Product Taste - Starter'
and d.Name in (
'Team used an electric/battery operated device or additional butane burner.'
,'Team started competition segment more than 10 minutes early, or finished more than 10 minutes late.'
);

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Product Taste - Entrée'
and d.Name in (
'Team used an electric/battery operated device or additional butane burner.'
,'Team started competition segment more than 10 minutes early, or finished more than 10 minutes late.'
);

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Product Taste - Dessert'
and d.Name in (
'Team used an electric/battery operated device or additional butane burner.'
,'Team started competition segment more than 10 minutes early, or finished more than 10 minutes late.'
);

--select sd.SectionID, s.Name as Section, sd.DisqualificationID, d.Name as Disqualification
delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
join dbo.Disqualification d on sd.DisqualificationID = d.ID
where s.CategoryID = 2
and s.Name = 'Menu and Recipe Presentation'
and d.Name = 'Team did not arrive at proper time.';

insert into dbo.Disqualification (Name, Active)
values ('Team did not arrive within the check in window.', 1);

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Management Check-In'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);

delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
where s.CategoryID = 1
and s.Name = 'Menu & Recipe Costing'

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Menu & Recipe Costing'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);

delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
where s.CategoryID = 1
and s.Name = 'Critical Thinking'

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Critical Thinking'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);

delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
where s.CategoryID = 1
and s.Name = 'Concept'

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Concept'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);

delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
where s.CategoryID = 1
and s.Name = 'Menu Costing'

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Menu Costing'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);

delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
where s.CategoryID = 1
and s.Name = 'Marketing'

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Marketing'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);

delete sd 
from dbo.SectionDisqualification sd
join dbo.Section s on sd.SectionID = s.ID
where s.CategoryID = 1
and s.Name = 'Operations'

insert into dbo.SectionDisqualification (SectionID, DisqualificationID)
select s.ID, d.id
from dbo.Section s, dbo.Disqualification d
where s.Name = 'Operations'
and d.Name in (
'Team received coaching during the event'
,'Team did not arrive at proper time.'
,'Team did not arrive within the check in window.'
,'Team did not compete in each segment'
);
