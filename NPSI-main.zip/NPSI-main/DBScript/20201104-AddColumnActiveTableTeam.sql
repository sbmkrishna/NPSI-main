ALTER TABLE Team
ADD Active Bit not null