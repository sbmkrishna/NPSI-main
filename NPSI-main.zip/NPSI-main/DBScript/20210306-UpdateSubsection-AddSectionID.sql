Alter table SubSection ADD SectionID INT NULL
Alter table SubSection ADD SortIndex INT NULL
Alter table Subsection DROP CONSTRAINT FK_492
DROP INDEX Subsection.fkIdx_492
Alter table Subsection DROP COLUMN CategoryID
Alter table SubSection ADD CONSTRAINT [FK_Section_Subsection_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID])

GO

Update ss
set SectionID = ISNULL (s.ID, 2)
from Subsection as ss
left join SectionSubsection as sss on sss.SubsectionID = ss.ID
left join Section as s on sss.SectionID = s.ID

Alter table SubSection Alter column SectionID INT NOT NULL

Drop table SectionSubsection