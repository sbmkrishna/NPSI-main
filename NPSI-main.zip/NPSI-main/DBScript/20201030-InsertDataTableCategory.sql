INSERT INTO Category VALUES (1,'Management')
INSERT INTO Category VALUES (2,'Culinary')


