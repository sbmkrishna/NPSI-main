﻿alter table dbo.JudgeSectionTeamInOut add Comments nvarchar(max);

