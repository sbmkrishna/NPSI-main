Alter Table EventTeam
Add StartTime datetime

Alter Table EventTeam
Add EndTime datetime

update EventTeam
set EventTeam.StartTime = (Select StartDateTime from [Event] where [Event].ID = EventTeam.EventID)

update EventTeam
set EventTeam.EndTime = (Select EndDateTime from [Event] where [Event].ID = EventTeam.EventID)

Alter Table EventTeam
Alter Column StartTime datetime not null

Alter Table EventTeam
Alter Column EndTime datetime not null