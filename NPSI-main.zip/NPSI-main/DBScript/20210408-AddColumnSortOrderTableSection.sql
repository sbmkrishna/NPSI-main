alter table Section
add SortOrder smallInt