alter table EventSection
drop column StartTime

alter table EventSection
drop column EndTime