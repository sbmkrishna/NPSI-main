GO
CREATE TABLE [Category]
(
 [ID]   smallint NOT NULL ,
 [Name] nvarchar(255) NOT NULL ,


 CONSTRAINT [PK_eventcategory] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO
CREATE TABLE [Section]
(
 [ID]          int IDENTITY (1, 1) NOT NULL ,
 [Name]        nvarchar(50) NOT NULL ,
 [Description] nvarchar(255) NOT NULL ,
 [Active]      bit NOT NULL ,
 [CategoryID]  smallint NOT NULL ,


 CONSTRAINT [PK_section] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_Section_Category_CategoryID] FOREIGN KEY ([CategoryID])  REFERENCES [Category]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_323] ON [Section] 
 (
  [CategoryID] ASC
 )
GO
CREATE TABLE [Team]
(
 [ID]                 int IDENTITY (1, 1) NOT NULL ,
 [Name]               nvarchar(50) ,
 [Email]              nvarchar(50) NOT NULL ,
 [Phone]              nvarchar(50) NOT NULL ,
 [PrimaryContactName] nvarchar(50) NOT NULL ,
 [SectionID]          int NOT NULL ,
 [SchoolName] nvarchar(255) not null,
 [CategoryID] smallint not null

 CONSTRAINT [PK_table_71] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

ALTER TABLE Team
ADD CONSTRAINT FK_Team_Category_CategoryID
FOREIGN KEY (CategoryID) REFERENCES Category(ID);

GO
CREATE TABLE [Disqualification]
(
 [ID]     int IDENTITY (1, 1) NOT NULL ,
 [Name]   nvarchar(255) NOT NULL ,
 [Active] bit NOT NULL ,


 CONSTRAINT [PK_disqualification] PRIMARY KEY CLUSTERED ([ID] ASC)
);

GO
CREATE TABLE [Event]
(
 [ID]              int IDENTITY (1, 1) NOT NULL ,
 [Name]            nvarchar(50) NOT NULL ,
 [StartDateTime]   datetime NOT NULL ,
 [EndDateTime]     datetime NOT NULL ,
 [CreatedDateTime] datetime NOT NULL ,
 [CreatedByUserID] nvarchar(128) NOT NULL ,


 CONSTRAINT [PK_event] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_Event_AspNetUsers_CreatedByUserID] FOREIGN KEY ([CreatedByUserID])  REFERENCES [AspNetUsers]([Id])
);
GO

CREATE NONCLUSTERED INDEX [fkIdx_407] ON [Event] 
 (
  [CreatedByUserID] ASC
 )

 GO

CREATE TABLE [EventSection]
(
 [SectionID] int NOT NULL ,
 [EventID]   int NOT NULL ,
 [StartTime] DateTime NOT NULL ,
 [EndTime] DateTime NOT NULL ,


 CONSTRAINT [PK_eventcategorysection] PRIMARY KEY CLUSTERED ([SectionID] ASC, [EventID] ASC),
 CONSTRAINT [FK_EventSection_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_EventSection-Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_112] ON [EventSection] 
 (
  [SectionID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_318] ON [EventSection] 
 (
  [EventID] ASC
 )
GO

CREATE TABLE [Member]
(
 [ID]     int IDENTITY (1, 1) NOT NULL ,
 [Name]   nvarchar(50) NOT NULL ,
 [Email]  nvarchar(50) NOT NULL ,
 [Phone]  nvarchar(50) NOT NULL ,
 [TeamID] int NOT NULL ,


 CONSTRAINT [PK_student] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_Member_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_171] ON [Member] 
 (
  [TeamID] ASC
 )

GO
CREATE TABLE [Penalty]
(
 [ID]        int IDENTITY (1, 1) NOT NULL ,
 [Name]      nvarchar(255) NOT NULL ,
 [Deduction] int NOT NULL ,
 [Active]    bit NOT NULL ,


 CONSTRAINT [PK_penalty] PRIMARY KEY CLUSTERED ([ID] ASC)
);

GO
CREATE TABLE [Subsection]
(
 [ID]          int IDENTITY (1, 1) NOT NULL ,
 [Name] nvarchar(255)  NOT NULL ,
 [Description] nvarchar(255) NOT NULL ,
 [MaxScore]    int NOT NULL ,
 [MinScore]	   int NOT NULL ,
 [CategoryID]  smallint NOT NULL ,
 [Active] bit NOT NULL ,


 CONSTRAINT [PK_id] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_492] FOREIGN KEY ([CategoryID])  REFERENCES [Category]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_492] ON [Subsection] 
 (
  [CategoryID] ASC
 )

GO

CREATE TABLE Criteria(
	ID int Primary Key identity,
	Title nvarchar(255) not null,
	[Description] nvarchar(max),
	MaxScore int not null,
	MinScore int not null,
	SubsectionId int not null,
)
GO
ALTER TABLE Criteria
ADD CONSTRAINT FK_Criteria_Subsection_SubsectionId
FOREIGN KEY (SubsectionId) REFERENCES Subsection(ID)

GO
CREATE TABLE [JudgeSectionAssignment]
(
 [JudgeUserID] nvarchar(128) NOT NULL ,
 [SectionID]   int NOT NULL ,
 [EventID]     int NOT NULL ,
 [SubmittedDateTime] datetimeoffset(7) ,


 CONSTRAINT [PK_eventcategorysectionjudge] PRIMARY KEY CLUSTERED ([JudgeUserID] ASC, [SectionID] ASC, [EventID] ASC),
 CONSTRAINT [FK_JudgeSectionAssignment_EventSection] FOREIGN KEY ([SectionID], [EventID])  REFERENCES [EventSection]([SectionID], [EventID]),
 CONSTRAINT [FK_JudgeSectionAssignment_User_JudgeUserID] FOREIGN KEY ([JudgeUserID])  REFERENCES [AspNetUsers]([ID])
);
GO
CREATE TABLE [JudgeSectionTeamAssignment]
(
 [JudgeUserID]       nvarchar(128) NOT NULL ,
 [TeamID]            int NOT NULL ,
 [EventID]           int NOT NULL ,
 [SectionID]         int NOT NULL ,
 [SubmittedDateTime] datetimeoffset(7) ,


 CONSTRAINT [PK_table_268] PRIMARY KEY CLUSTERED ([JudgeUserID] ASC, [TeamID] ASC, [EventID] ASC, [SectionID] ASC),
 CONSTRAINT [FK_JudgeSectionTeamAssignment_JudgeSectionAssignment] FOREIGN KEY ([JudgeUserID], [SectionID], [EventID])  REFERENCES [JudgeSectionAssignment]([JudgeUserID], [SectionID], [EventID]),
 CONSTRAINT [FK_JudgeSectionTeamAssignment_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_269] ON [JudgeSectionTeamAssignment] 
 (
  [JudgeUserID] ASC, 
  [SectionID] ASC, 
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_452] ON [JudgeSectionTeamAssignment] 
 (
  [TeamID] ASC
 )
GO
CREATE TABLE [Score]
(
 [ID]              int IDENTITY (1, 1) NOT NULL ,
 [Score]           int NOT NULL ,
 [CreatedDateTime] datetimeoffset(7) NOT NULL ,
 [SubsectionID]    int NOT NULL ,
 [JudgeUserID]     nvarchar(128) NOT NULL ,
 [TeamID]          int NOT NULL ,
 [EventID]         int NOT NULL ,
 [SectionID]       int NOT NULL ,
 [Comments] 	   nvarchar(max) not null,
 [Photo] 		   varbinary(max),


 CONSTRAINT [PK_point] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_Score_JudgeSectionTeamAssignment] FOREIGN KEY ([JudgeUserID], [TeamID], [EventID], [SectionID])  REFERENCES [JudgeSectionTeamAssignment]([JudgeUserID], [TeamID], [EventID], [SectionID]),
 CONSTRAINT [FK_Score_Subsection_SubsectionID] FOREIGN KEY ([SubsectionID])  REFERENCES [Subsection]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_296] ON [Score] 
 (
  [JudgeUserID] ASC, 
  [TeamID] ASC, 
  [EventID] ASC, 
  [SectionID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_437] ON [Score] 
 (
  [SubsectionID] ASC
 )
GO
CREATE TABLE [EventCategories]
(
 [EventID]    int NOT NULL ,
 [CategoryID] smallint NOT NULL ,


 CONSTRAINT [PK_eventcategories] PRIMARY KEY CLUSTERED ([EventID] ASC, [CategoryID] ASC),
 CONSTRAINT [FK_EventCategories_Category_CategoryID] FOREIGN KEY ([CategoryID])  REFERENCES [Category]([ID]),
 CONSTRAINT [FK_EventCategories_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_425] ON [EventCategories] 
 (
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_430] ON [EventCategories] 
 (
  [CategoryID] ASC
 )



GO
CREATE TABLE [EventSectionDisqualification]
(
 [DisqualificationID] int NOT NULL ,
 [SectionID]          int NOT NULL ,
 [EventID]            int NOT NULL ,


 CONSTRAINT [PK_eventsectiondisqualification] PRIMARY KEY CLUSTERED ([DisqualificationID] ASC, [SectionID] ASC, [EventID] ASC),
 CONSTRAINT [FK_EventSectionDisqualification_Disqualification_DisqualificationID] FOREIGN KEY ([DisqualificationID])  REFERENCES [Disqualification]([ID]),
 CONSTRAINT [FK_EventSectionDisqualification_EventSection] FOREIGN KEY ([SectionID], [EventID])  REFERENCES [EventSection]([SectionID], [EventID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_344] ON [EventSectionDisqualification] 
 (
  [SectionID] ASC, 
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_348] ON [EventSectionDisqualification] 
 (
  [DisqualificationID] ASC
 )

GO
CREATE TABLE [EventSectionPenalty]
(
 [PenaltyID] int NOT NULL ,
 [SectionID] int NOT NULL ,
 [EventID]   int NOT NULL ,


 CONSTRAINT [PK_eventsectionpenalty] PRIMARY KEY CLUSTERED ([PenaltyID] ASC, [SectionID] ASC, [EventID] ASC),
 CONSTRAINT [FK_EventSectionPenalty_EventSection] FOREIGN KEY ([SectionID], [EventID])  REFERENCES [EventSection]([SectionID], [EventID]),
 CONSTRAINT [FK_EventSectionPenalty_Penalty_PenaltyID] FOREIGN KEY ([PenaltyID])  REFERENCES [Penalty]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_377] ON [EventSectionPenalty] 
 (
  [PenaltyID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_380] ON [EventSectionPenalty] 
 (
  [SectionID] ASC, 
  [EventID] ASC
 )

GO
CREATE TABLE [EventSectionSubsection]
(
 [SubsectionID] int NOT NULL ,
 [SectionID]    int NOT NULL ,
 [EventID]      int NOT NULL ,


 CONSTRAINT [PK_eventsectionsubsection] PRIMARY KEY CLUSTERED ([SubsectionID] ASC, [SectionID] ASC, [EventID] ASC),
 CONSTRAINT [FK_EventSectionSubsection_EventSection] FOREIGN KEY ([SectionID], [EventID])  REFERENCES [EventSection]([SectionID], [EventID]),
 CONSTRAINT [FK_EventSectionSubsection_Subsection_SubsectionID] FOREIGN KEY ([SubsectionID])  REFERENCES [Subsection]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_363] ON [EventSectionSubsection] 
 (
  [SectionID] ASC, 
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_366] ON [EventSectionSubsection] 
 (
  [SubsectionID] ASC
 )

 GO
CREATE TABLE [EventStatus]
(
 [ID]         smallint NOT NULL ,
 [StatusName] nvarchar(50) NOT NULL ,
 [StatusCode] nvarchar(50) NOT NULL ,


 CONSTRAINT [PK_eventstatus] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO
CREATE TABLE [EventStatusLog]
(
 [ID]             int IDENTITY (1, 1) NOT NULL ,
 [LoggedDateTime] datetimeoffset(7) NOT NULL ,
 [EventStatusID]  smallint NOT NULL ,
 [EventID]        int NOT NULL ,
 [LoggedBy]       nvarchar(128) NOT NULL ,


 CONSTRAINT [PK_eventstatuslog] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_EventStatusLog_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_EventStatusLog_EventStatus_EventStatusID] FOREIGN KEY ([EventStatusID])  REFERENCES [EventStatus]([ID]),
 CONSTRAINT [FK_EventStatusLog_User_LoggedBy] FOREIGN KEY ([LoggedBy])  REFERENCES [AspNetUsers]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_141] ON [EventStatusLog] 
 (
  [EventStatusID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_147] ON [EventStatusLog] 
 (
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_221] ON [EventStatusLog] 
 (
  [LoggedBy] ASC
 )

GO
CREATE TABLE [EventTeam]
(
 [TeamID]  int NOT NULL ,
 [EventID] int NOT NULL ,


 CONSTRAINT [PK_eventcategoryschool] PRIMARY KEY CLUSTERED ([TeamID] ASC, [EventID] ASC),
 CONSTRAINT [FK_EventTeam_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_EventTeam_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_312] ON [EventTeam] 
 (
  [TeamID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_330] ON [EventTeam] 
 (
  [EventID] ASC
 )

GO


CREATE NONCLUSTERED INDEX [fkIdx_157] ON [JudgeSectionAssignment] 
 (
  [JudgeUserID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_161] ON [JudgeSectionAssignment] 
 (
  [SectionID] ASC, 
  [EventID] ASC
 )



GO
CREATE TABLE [SectionDisqualification]
(
 [SectionID]          int NOT NULL ,
 [DisqualificationID] int NOT NULL ,


 CONSTRAINT [PK_sectiondisqualification] PRIMARY KEY CLUSTERED ([SectionID] ASC, [DisqualificationID] ASC),
 CONSTRAINT [FK_SectionDisqualification_Disqualification_DisqualificationID] FOREIGN KEY ([DisqualificationID])  REFERENCES [Disqualification]([ID]),
 CONSTRAINT [FK_SectionDisqualification_Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_90] ON [SectionDisqualification] 
 (
  [SectionID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_94] ON [SectionDisqualification] 
 (
  [DisqualificationID] ASC
 )

GO
CREATE TABLE [SectionPenalty]
(
 [SectionID] int NOT NULL ,
 [PenaltyID] int NOT NULL ,


 CONSTRAINT [PK_sectionpenalty] PRIMARY KEY CLUSTERED ([SectionID] ASC, [PenaltyID] ASC),
 CONSTRAINT [FK_SectionPenalty_Penalty_PenaltyID] FOREIGN KEY ([PenaltyID])  REFERENCES [Penalty]([ID]),
 CONSTRAINT [FK_SectionPenalty_Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_82] ON [SectionPenalty] 
 (
  [PenaltyID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_86] ON [SectionPenalty] 
 (
  [SectionID] ASC
 )

GO
CREATE TABLE [SectionSubsection]
(
 [SectionID]    int NOT NULL ,
 [SubsectionID] int NOT NULL ,


 CONSTRAINT [PK_sectionsubsection] PRIMARY KEY CLUSTERED ([SectionID] ASC, [SubsectionID] ASC),
 CONSTRAINT [FK_SectionSubsection_Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID]),
 CONSTRAINT [FK_SectionSubsection_Subsection_SubsectionID] FOREIGN KEY ([SubsectionID])  REFERENCES [Subsection]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_300] ON [SectionSubsection] 
 (
  [SectionID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_303] ON [SectionSubsection] 
 (
  [SubsectionID] ASC
 )

GO

CREATE TABLE [TeamSectionDisqualification]
(
 [ID]                 int IDENTITY (1, 1) NOT NULL ,
 [CreatedDateTime]    datetimeoffset(7) NOT NULL ,
 [DisqualificationID] int NOT NULL ,
 [JudgeUserID]        nvarchar(128) NOT NULL ,
 [TeamID]             int NOT NULL ,
 [EventID]            int NOT NULL ,
 [SectionID]          int NOT NULL ,
 [Comments] 	   nvarchar(max) not null,
 [Photo] 		   varbinary(max),


 CONSTRAINT [PK_sectionstudentdisqualification] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_TeamSectionDisqualification_Disqualification_DisqualificationID] FOREIGN KEY ([DisqualificationID])  REFERENCES [Disqualification]([ID]),
 CONSTRAINT [FK_TeamSectionDisqualification_JudgeSectionTeamAssignment] FOREIGN KEY ([JudgeUserID], [TeamID], [EventID], [SectionID])  REFERENCES [JudgeSectionTeamAssignment]([JudgeUserID], [TeamID], [EventID], [SectionID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_290] ON [TeamSectionDisqualification] 
 (
  [JudgeUserID] ASC, 
  [TeamID] ASC, 
  [EventID] ASC, 
  [SectionID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_440] ON [TeamSectionDisqualification] 
 (
  [DisqualificationID] ASC
 )

GO

CREATE TABLE [TeamSectionPenalty]
(
 [ID]              int IDENTITY (1, 1) NOT NULL ,
 [CreatedDateTime] datetimeoffset(7) NOT NULL ,
 [PenaltyID]       int NOT NULL ,
 [JudgeUserID]     nvarchar(128) NOT NULL ,
 [TeamID]          int NOT NULL ,
 [EventID]         int NOT NULL ,
 [SectionID]       int NOT NULL ,
 [Comments] 	   nvarchar(max) not null,
 [Photo] 		   varbinary(max),


 CONSTRAINT [PK_sectionstudentpenalty] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_TeamSectionPenalty_JudgeSectionTeamAssignment] FOREIGN KEY ([JudgeUserID], [TeamID], [EventID], [SectionID])  REFERENCES [JudgeSectionTeamAssignment]([JudgeUserID], [TeamID], [EventID], [SectionID]),
 CONSTRAINT [FK_TeamSectionPenalty_Penalty_PenaltyID] FOREIGN KEY ([PenaltyID])  REFERENCES [Penalty]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_402] ON [TeamSectionPenalty] 
 (
  [JudgeUserID] ASC, 
  [TeamID] ASC, 
  [EventID] ASC, 
  [SectionID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_443] ON [TeamSectionPenalty] 
 (
  [PenaltyID] ASC
 )

GO
CREATE TABLE [UserEventRole]
(
 [UserID]     nvarchar(128) NOT NULL ,
 [RoleID]     nvarchar(128) NOT NULL ,
 [EventID]    int NOT NULL ,
 [CategoryID] smallint NOT NULL ,


 CONSTRAINT [PK_table_48] PRIMARY KEY CLUSTERED ([UserID] ASC, [RoleID] ASC, [EventID] ASC, [CategoryID] ASC),
 CONSTRAINT [FK_UserEventRole_Category] FOREIGN KEY ([CategoryID])  REFERENCES [Category]([ID]),
 CONSTRAINT [FK_UserEventRole_Event] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_UserRole_AspNetRoles_RoleID] FOREIGN KEY ([RoleID])  REFERENCES [AspNetRoles]([ID]),
 CONSTRAINT [FK_UserRole_User_UserID] FOREIGN KEY ([UserID])  REFERENCES [AspNetUsers]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_263] ON [UserEventRole] 
 (
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_49] ON [UserEventRole] 
 (
  [UserID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_52] ON [UserEventRole] 
 (
  [RoleID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_520] ON [UserEventRole] 
 (
  [CategoryID] ASC
 )

GO