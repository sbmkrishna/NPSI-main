alter table Score
alter column Comments nvarchar(max) null