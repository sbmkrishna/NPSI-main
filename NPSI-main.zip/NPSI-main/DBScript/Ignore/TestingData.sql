--INSERT EVENTS
INSERT INTO [EVENT] VALUES ('Management Testing Event 1', '2021-04-13', '2021-04-16', '2021-04-13', '9f15bdd0fcd5423190c2e877ba0228ee')
INSERT INTO [EVENT] VALUES ('Culinary Testing Event 2', '2021-04-14', '2021-04-17', '2021-04-13', '9f15bdd0fcd5423190c2e877ba0228ee')

--INSERT EVENT CATEGORIES
INSERT INTO [EventCategories] VALUES (23, 1)
INSERT INTO [EventCategories] VALUES (24, 2)

--INSERT EVENT STATUS LOGS
INSERT INTO [EventStatusLog] VALUES ('2021-04-13', 1, 23, '9f15bdd0fcd5423190c2e877ba0228ee')
INSERT INTO [EventStatusLog] VALUES ('2021-04-13', 2, 23, '9f15bdd0fcd5423190c2e877ba0228ee')
INSERT INTO [EventStatusLog] VALUES ('2021-04-13', 1, 24, '9f15bdd0fcd5423190c2e877ba0228ee')
INSERT INTO [EventStatusLog] VALUES ('2021-04-13', 2, 24, '9f15bdd0fcd5423190c2e877ba0228ee')

--INSERT SECTIONS 
--MANAGEMENT SECTIONS
INSERT INTO [Section] VALUES ('Management Testing Section 1', 'Management Testing Section 1 Description', 1, 1, 1)
INSERT INTO [Section] VALUES ('Management Testing Section 2', 'Management Testing Section 2 Description', 1, 1, 2)
INSERT INTO [Section] VALUES ('Management Testing Section 3', 'Management Testing Section 3 Description', 1, 1, 3)

--CULINARY SECTIONS
INSERT INTO [Section] VALUES ('Culinary Testing Section 1', 'Culinary Testing Section 1 Description', 1, 2, 1)
INSERT INTO [Section] VALUES ('Culinary Testing Section 2', 'Culinary Testing Section 2 Description', 1, 2, 2)
INSERT INTO [Section] VALUES ('Culinary Testing Section 3', 'Culinary Testing Section 3 Description', 1, 2, 3)

--INSERT SUBSECTIONS
--MANAGEMENT SUBSECTIONS
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 1A', 'Management Testing Subsection 1A Description', 10, 1, 1, 71, 1)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 1B', 'Management Testing Subsection 1B Description', 10, 1, 1, 71, 2)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 1C', 'Management Testing Subsection 1C Description', 10, 1, 1, 71, 3)

INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 2A', 'Management Testing Subsection 2A Description', 10, 1, 1, 72, 1)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 2B', 'Management Testing Subsection 2B Description', 10, 1, 1, 72, 2)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 2C', 'Management Testing Subsection 2C Description', 10, 1, 1, 72, 3)

INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 3A', 'Management Testing Subsection 3A Description', 10, 1, 1, 73, 1)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 3B', 'Management Testing Subsection 3B Description', 10, 1, 1, 73, 2)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Management Testing Subsection 3C', 'Management Testing Subsection 3C Description', 10, 1, 1, 73, 3)

--CULINARY SUBSECTIONS
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 1A', 'Culinary Testing Subsection 1A Description', 10, 1, 1, 74, 1)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 1B', 'Culinary Testing Subsection 1B Description', 10, 1, 1, 74, 2)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 1C', 'Culinary Testing Subsection 1C Description', 10, 1, 1, 74, 3)

INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 2A', 'Culinary Testing Subsection 2A Description', 10, 1, 1, 75, 1)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 2B', 'Culinary Testing Subsection 2B Description', 10, 1, 1, 75, 2)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 2C', 'Culinary Testing Subsection 2C Description', 10, 1, 1, 75, 3)

INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 3A', 'Culinary Testing Subsection 3A Description', 10, 1, 1, 76, 1)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 3B', 'Culinary Testing Subsection 3B Description', 10, 1, 1, 76, 2)
INSERT INTO [Subsection] (Name, Description, MaxScore, MinScore, Active, SectionID, SortIndex) 
VALUES ('Culinary Testing Subsection 3C', 'Culinary Testing Subsection 3C Description', 10, 1, 1, 76, 3)

--INSERT EVENT SECTIONS
INSERT INTO [EventSection] VALUES (71, 23, '2021-04-13 09:00:00', '2021-04-13 11:00:00')
INSERT INTO [EventSection] VALUES (72, 23, '2021-04-14 09:00:00', '2021-04-14 11:00:00')
INSERT INTO [EventSection] VALUES (73, 23, '2021-04-15 09:00:00', '2021-04-15 11:00:00')

INSERT INTO [EventSection] VALUES (74, 24, '2021-04-14 09:00:00', '2021-04-14 11:00:00')
INSERT INTO [EventSection] VALUES (75, 24, '2021-04-15 09:00:00', '2021-04-15 11:00:00')
INSERT INTO [EventSection] VALUES (76, 24, '2021-04-16 09:00:00', '2021-04-16 11:00:00')

--INSERT JUDGES
--LUCY - JUDGE - Management Testing Event 1
INSERT INTO [UserEventRole] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', '18DB3725-9E77-4FB4-AE01-24E0D1271DB9', 23, 1)
--MACY - JUDGE - Management Testing Event 1
INSERT INTO [UserEventRole] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', '18DB3725-9E77-4FB4-AE01-24E0D1271DB9', 23, 1)
--Tuan - LEAD-JUDGE - Management Testing Event 1
INSERT INTO [UserEventRole] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', '1FAF9833-C52F-4326-8328-D20E9703982A', 23, 1)

--Tuan - JUDGE - Management Testing Event 1
INSERT INTO [UserEventRole] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', '18DB3725-9E77-4FB4-AE01-24E0D1271DB9', 24, 2)
--MACY - JUDGE - Management Testing Event 1
INSERT INTO [UserEventRole] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', '18DB3725-9E77-4FB4-AE01-24E0D1271DB9', 24, 2)
--LUCY - LEADJUDGE - Culinary Testing Event 2
INSERT INTO [UserEventRole] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', '1FAF9833-C52F-4326-8328-D20E9703982A', 24, 2)

--INSERT EVENT TEAMS
INSERT INTO [EventTeam] VALUES (1, 23)
INSERT INTO [EventTeam] VALUES (3, 23)

INSERT INTO [EventTeam] VALUES (2, 24)
INSERT INTO [EventTeam] VALUES (4, 24)

--ASSIGN JUDGES TO SECTIONS
--LUCY - Section 1, 2 - EVENT 1
INSERT INTO [JudgeSectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 71, 23, NULL)
INSERT INTO [JudgeSectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 72, 23, NULL)
--MACY - Section 2, 3 - EVENT 1
INSERT INTO [JudgeSectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 72, 23, NULL)
INSERT INTO [JudgeSectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 73, 23, NULL)

--Tuan Nguyen - Section 1, 2 - EVENT 2
INSERT INTO [JudgeSectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 74, 24, NULL)
INSERT INTO [JudgeSectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 75, 24, NULL)
--MACY - Section 2, 3 - EVENT 2
INSERT INTO [JudgeSectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 75, 24, NULL)
INSERT INTO [JudgeSectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 76, 24, NULL)

--ASSIGN JUDGES TO SUBSECTIONS
--LUCY - Subsection 1A, 1B, 1C, 2A, 2B - EVENT 1
INSERT INTO [JudgeSubsectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 23, 39)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 23, 40)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 23, 41)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 23, 42)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('1f15bdd0fcd5423190c2e877ba0228ee', 23, 43)
--MACY - Subsection 2C, 3A, 3B, 3C - EVENT 1
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 23, 44)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 23, 45)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 23, 46)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 23, 47)

--Tuan Nguyen - Subsection 1A, 1B, 1C, 2A, 2B - EVENT 2
INSERT INTO [JudgeSubsectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 24, 48)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 24, 49)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 24, 50)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 24, 51)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('8f15bdd0fcd5423190c2e877ba0228ee', 24, 52)
--MACY - Subsection 2C, 3A, 3B, 3C - EVENT 2
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 24, 53)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 24, 54)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 24, 55)
INSERT INTO [JudgeSubsectionAssignment] VALUES ('2f15bdd0fcd5423190c2e877ba0228ee', 24, 56)

--INSERT SCORES


--INSERT DISQUALIFICATIONS


--INSERT PENALTIES


select * from section
update section set CategoryID = 2 where ID >= 74