use NPSI
go

-- change number eventID to delete event
declare @eventID int = 38
IF exists (select * from [Event] where ID = @eventID)
BEGIN
	IF exists (select * from JudgeSectionAssignment where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table JudgeSectionAssignment')
		DELETE FROM JudgeSectionAssignment WHERE EventID = @eventID;
	END

	IF exists (select * from EventSection where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table EventSection')
		DELETE FROM EventSection WHERE EventID = @eventID;
	END

	IF exists (select * from EventCategories where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table EventCategories')
		DELETE FROM EventCategories WHERE EventID = @eventID;
	END

	IF exists (select * from EventTeam where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table EventTeam')
		DELETE FROM EventTeam WHERE EventID = @eventID;
	END

	IF exists (select * from EventStatusLog where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table EventStatusLog')
		DELETE FROM EventStatusLog WHERE EventID = @eventID;
	END

	IF exists (select * from JudgeSubsectionAssignment where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table JudgeSubsectionAssignment')
		DELETE FROM JudgeSubsectionAssignment WHERE EventID = @eventID;
	END

	IF exists (select * from Score where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table Score')
		DELETE FROM Score WHERE EventID = @eventID;
	END

	IF exists (select * from TeamSectionPenalty where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table TeamSectionPenalty')
		DELETE FROM TeamSectionPenalty WHERE EventID = @eventID;
	END

	IF exists (select * from TeamSectionDisqualification where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table TeamSectionDisqualification')
		DELETE FROM TeamSectionDisqualification WHERE EventID = @eventID;
	END

	IF exists (select * from UserEventRole where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table UserEventRole')
		DELETE FROM UserEventRole WHERE EventID = @eventID;
	END
	
	IF exists (select * from JudgeSectionTeamInOut where eventID = @eventID) 
	BEGIN
		PRINT ('******Remove data table JudgeSectionTeamInOut')
		DELETE FROM JudgeSectionTeamInOut WHERE EventID = @eventID;
	END

	DELETE FROM [Event] WHERE ID = @eventID
END