/****** Script for SelectTopNRows command from SSMS  
SELECT TOP (1000) [ID]
      ,[Name]
      ,[Description]
      ,[Active]
      ,[CategoryID]
      ,[SortOrder]
      ,[TimeInOutNeeded]
  FROM [NPSI].[dbo].[Section]
	order by CategoryID, SortOrder
******/
GO

update [dbo].[Section]
set Active = 0
where ID = 10;

update [dbo].[Section]
set SortOrder = SortOrder+1
where CategoryID = 2 and Active = 1 and SortOrder > 1;

insert into [dbo].[Section] (
	[Name]
	,[Description]
	,Active
	,CategoryID
	,SortOrder
	,TimeInOutNeeded
) values (
	'Work Skills / Organization'
	,'<p>Work Skills / Organization<br></p>'
	,1
	,2
	,2
	,0
), (
	'Team Presentation / Knife Skills'
	,'<p>Team Presentation / Knife Skills</p>'
	,1
	,2
	,3
	,0
);

insert into [dbo].[Subsection] (
	[Name]
	,[Description]
	,[MaxScore]
	,[MinScore]
	,[Active]
	,[SectionID]
	,[SortIndex]
)
SELECT 
	ss.[Name]
	,ss.[Description]
	,ss.[MaxScore]
	,ss.[MinScore]
	,ss.[Active]
	,s.ID as [SectionID] 
	,ROW_NUMBER() over(order by ss.sortIndex) as [SortIndex]
FROM 
	[NPSI].[dbo].[Subsection] ss, Section s
where 
	ss.SectionID = 10 
and ss.SortIndex in (2,3,5)
and s.[Name] = 'Work Skills / Organization';

insert into [dbo].[Subsection] (
	[Name]
	,[Description]
	,[MaxScore]
	,[MinScore]
	,[Active]
	,[SectionID]
	,[SortIndex]
)
SELECT 
	ss.[Name]
	,ss.[Description]
	,ss.[MaxScore]
	,ss.[MinScore]
	,ss.[Active]
	,s.ID as [SectionID] 
	,ROW_NUMBER() over(order by ss.sortIndex) as [SortIndex]
FROM 
	[NPSI].[dbo].[Subsection] ss, Section s
where 
	ss.SectionID = 10 
and ss.SortIndex in (1,4)
and s.[Name] = 'Team Presentation / Knife Skills';

insert into [dbo].[SectionDisqualification] (
	SectionID
	,DisqualificationID
) SELECT 
	s.Id as [SectionID]
	,sd.[DisqualificationID]
FROM
	[dbo].[SectionDisqualification] sd, Section s
where 
	sd.SectionID = 10
and s.[Name] = 'Work Skills / Organization';

insert into [dbo].[SectionDisqualification] (
	SectionID
	,DisqualificationID
) SELECT 
	s.Id as [SectionID]
	,sd.[DisqualificationID]
FROM
	[dbo].[SectionDisqualification] sd, Section s
where 
	sd.SectionID = 10
and s.[Name] = 'Team Presentation / Knife Skills';

insert into [dbo].[SectionPenalty] (
	SectionID
	,PenaltyID
) SELECT
	s.ID as [SectionID]
	,[PenaltyID]
FROM 
	[dbo].[SectionPenalty] sp, Section s
where 
	sp.SectionID = 10
and s.[Name] = 'Work Skills / Organization';

insert into [dbo].[SectionPenalty] (
	SectionID
	,PenaltyID
) SELECT
	s.ID as [SectionID]
	,[PenaltyID]
FROM 
	[dbo].[SectionPenalty] sp, Section s
where 
	sp.SectionID = 10
and s.[Name] = 'Team Presentation / Knife Skills';


