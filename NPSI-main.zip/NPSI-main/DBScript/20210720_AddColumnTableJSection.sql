alter table Section
add TimeInOutNeeded bit 

update Section
set TimeInOutNeeded = 0

alter table Section
alter column TimeInOutNeeded bit not null