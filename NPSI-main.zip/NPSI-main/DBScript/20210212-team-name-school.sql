
update T set T.[Name] = isnull(T.SchoolName,'')+' - '+C.[Name]
from dbo.Team T
join dbo.Category C on T.CategoryID = C.ID;
go

alter table dbo.Team drop column Entity;
go


