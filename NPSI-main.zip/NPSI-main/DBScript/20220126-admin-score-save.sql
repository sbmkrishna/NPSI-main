﻿alter table dbo.Score add UpdatedUserID nvarchar(128);
GO
alter table dbo.TeamSectionDisqualification add UpdatedUserID nvarchar(128);
GO
alter table dbo.TeamSectionPenalty add UpdatedUserID nvarchar(128);
GO

update dbo.Score set UpdatedUserID = JudgeUserID where Not (Score is null and Comments is null);
update dbo.TeamSectionDisqualification set UpdatedUserID = JudgeUserID;
update dbo.TeamSectionPenalty set UpdatedUserID = JudgeUserID where NOT (Deduction is null and Comments is null);
GO

