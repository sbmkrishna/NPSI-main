ALTER TABLE TeamSectionPenalty
ADD Deduction decimal(4,2)
GO

UPDATE TeamSectionPenalty
SET Deduction = (SELECT DeductionMin FROM Penalty WHERE ID = PenaltyID)
GO

ALTER TABLE TeamSectionPenalty
ALTER COLUMN Deduction decimal(4,2) not null

