﻿create table dbo.PenaltyQuestion (
ID int identity not null constraint PK_PenaltyQuestion primary key 
,PenaltyID int not null constraint FK_PenaltyQuestion_Penalty foreign key references dbo.Penalty
,QuestionNbr smallint not null
,QuestionText nvarchar(255) not null
,AnswerType nchar(1) not null);
GO

create table dbo.TeamSectionPenaltyQuestion (
TeamSectionPenaltyID int not null constraint FK_TeamSectionPenaltyQuestion_TeamSectionPenalty foreign key references dbo.TeamSectionPenalty
,PenaltyQuestionID int not null constraint FK_TeamSectionPenaltyQuestion_PenaltyQuestion foreign key references dbo.PenaltyQuestion
,AnswerText nvarchar(255)
,constraint PK_TeamSectionPenaltyQuestion primary key (TeamSectionPenaltyID,PenaltyQuestionID)
);
GO

insert into dbo.PenaltyQuestion (
PenaltyID
,QuestionNbr
,QuestionText
,AnswerType
)
select p.ID, T.QuestionNbr, T.QuestionText, T.AnswerType
from dbo.Penalty p,
(values (1,'Equipment','B'), (2,'Pre-prepared ingredients','B')) as T(QuestionNbr,QuestionText,AnswerType)
where p.Name = 'Use of pre-prepared ingredients or prohibited equipment– 5 pts'
union
select p.ID, T.QuestionNbr, T.QuestionText, T.AnswerType
from dbo.Penalty p,
(values (1,'Number of items submitted','N')) as T(QuestionNbr,QuestionText,AnswerType)
where p.Name = 'Team submits more or fewer than 12 menu items – 5 points'
union
select p.ID, T.QuestionNbr, T.QuestionText, T.AnswerType
from dbo.Penalty p,
(values (1,'Number of recipes submitted','N')) as T(QuestionNbr,QuestionText,AnswerType)
where p.Name = 'Team submits recipes for more or fewer than 1 menu item – 5 points'
union
select p.ID, T.QuestionNbr, T.QuestionText, T.AnswerType
from dbo.Penalty p,
(values (1,'Number of costing worksheets submitted','N')) as T(QuestionNbr,QuestionText,AnswerType)
where p.Name = 'Team submits food costing worksheets for more or fewer than 1 menu item – 5 points'
union
select p.ID, T.QuestionNbr, T.QuestionText, T.AnswerType
from dbo.Penalty p,
(values (1,'Number of menu pricing worksheets submitted','N')) as T(QuestionNbr,QuestionText,AnswerType)
where p.Name = 'Team submits more or fewer than 1 menu pricing worksheet – 5 points'
;


