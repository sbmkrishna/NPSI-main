GO
ALTER TABLE Team
ADD Entity nvarchar(255)

GO
update Team
set Entity = SchoolName 

GO
ALTER TABLE Team
ALTER COLUMN Entity nvarchar(255) not null

GO
ALTER TABLE Team
ALTER COLUMN SchoolName nvarchar(255)

GO
update Team
set Name = 'Team Test'
where Name is null 

GO
ALTER TABLE Team
ALTER COLUMN Name nvarchar(255) not null