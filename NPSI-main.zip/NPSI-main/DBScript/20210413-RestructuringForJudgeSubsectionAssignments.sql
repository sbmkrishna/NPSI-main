--DROP TABLES BEFORE RECREATE
DROP TABLE Score
GO
DROP TABLE TeamSectionDisqualification
GO
DROP TABLE TeamSectionPenalty
GO
DROP Table JudgeSectionTeamAssignment 
GO

--CREATE NEW JudgeSubsectionAssignment table
CREATE TABLE [JudgeSubsectionAssignment]
(
 [JudgeUserID]  nvarchar(128) NOT NULL ,
 [EventID]      int NOT NULL ,
 [SubsectionID] int NOT NULL ,

 CONSTRAINT [PK_judgesubsectionassignment] PRIMARY KEY CLUSTERED ([JudgeUserID] ASC, [EventID] ASC, [SubsectionID] ASC),
 CONSTRAINT [FK_JudgeSubsectionAssignment_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_JudgeSubsectionAssignment_Subsection_SubsectionID] FOREIGN KEY ([SubsectionID])  REFERENCES [Subsection]([ID]),
 CONSTRAINT [FK_User_JudgeSubsectionAssignment_JudgeUserID] FOREIGN KEY ([JudgeUserID])  REFERENCES [AspNetUsers]([ID])
);
GO

CREATE NONCLUSTERED INDEX [fkIdx_533] ON [JudgeSubsectionAssignment] 
 (
  [JudgeUserID] ASC
 )
GO

CREATE NONCLUSTERED INDEX [fkIdx_536] ON [JudgeSubsectionAssignment] 
 (
  [EventID] ASC
 )
GO

CREATE NONCLUSTERED INDEX [fkIdx_541] ON [JudgeSubsectionAssignment] 
 (
  [SubsectionID] ASC
 )
GO

--GENERATE DATA FOR JudgeSubsectionAssignment
INSERT INTO JudgeSubsectionAssignment (JudgeUserID, EventID, SubsectionID)
Select JSA.JudgeUserID, JSA.EventID, SS.ID as SubsectionID
from JudgeSectionAssignment as JSA 
inner join Subsection as SS on JSA.SectionID = SS.SectionID
GO

-- RECREATE TABLE SCORE
CREATE TABLE [Score]
(
 [ID]              int IDENTITY (1, 1) NOT NULL ,
 [Score]           decimal (4,2) NOT NULL ,
 [CreatedDateTime] datetimeoffset(7) NOT NULL ,
 [Comments]        nvarchar(max) NOT NULL ,
 [Photo]           varbinary(max) NULL ,
 [JudgeUserID]     nvarchar(128) NOT NULL ,
 [TeamID]          int NOT NULL ,
 [EventID]         int NOT NULL ,
 [SubsectionID]    int NOT NULL ,


 CONSTRAINT [PK_point] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_Score_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_Score_Subsection_SubsectionID] FOREIGN KEY ([SubsectionID])  REFERENCES [Subsection]([ID]),
 CONSTRAINT [FK_Score_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID]),
 CONSTRAINT [FK_Score_User_JudgeUserID] FOREIGN KEY ([JudgeUserID])  REFERENCES [AspNetUsers]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_558] ON [Score] 
 (
  [JudgeUserID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_561] ON [Score] 
 (
  [TeamID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_564] ON [Score] 
 (
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_567] ON [Score] 
 (
  [SubsectionID] ASC
 )

GO

-- RECREATE TABLE TeamSectionDisqualification
CREATE TABLE [TeamSectionDisqualification]
(
 [ID]                 int IDENTITY (1, 1) NOT NULL ,
 [CreatedDateTime]    datetimeoffset(7) NOT NULL ,
 [DisqualificationID] int NOT NULL ,
 [Comments]           nvarchar(max) NOT NULL ,
 [Photo]              varbinary(max) NULL ,
 [TeamID]             int NOT NULL ,
 [EventID]            int NOT NULL ,
 [JudgeUserID]             nvarchar(128) NOT NULL ,
 [SectionID]          int NOT NULL ,


 CONSTRAINT [PK_sectionstudentdisqualification] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_TeamSectionDisqualification_Disqualification_DisqualificationID] FOREIGN KEY ([DisqualificationID])  REFERENCES [Disqualification]([ID]),
 CONSTRAINT [FK_TeamSectionDisqualification_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_TeamSectionDisqualification_Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID]),
 CONSTRAINT [FK_TeamSectionDisqualification_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID]),
 CONSTRAINT [FK_TeamSectionDisqualification_User_JudgeUserID] FOREIGN KEY ([JudgeUserID])  REFERENCES [AspNetUsers]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_440] ON [TeamSectionDisqualification] 
 (
  [DisqualificationID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_573] ON [TeamSectionDisqualification] 
 (
  [TeamID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_576] ON [TeamSectionDisqualification] 
 (
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_592] ON [TeamSectionDisqualification] 
 (
  [JudgeUserID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_595] ON [TeamSectionDisqualification] 
 (
  [SectionID] ASC
 )

GO


-- RECREATE TABLE TeamSectionPenalty
CREATE TABLE [TeamSectionPenalty]
(
 [ID]              int IDENTITY (1, 1) NOT NULL ,
 [CreatedDateTime] datetimeoffset(7) NOT NULL ,
 [PenaltyID]       int NOT NULL ,
 [Comments]        nvarchar(max) NOT NULL ,
 [Photo]           varbinary(max) NULL ,
 [EventID]         int NOT NULL ,
 [TeamID]          int NOT NULL ,
 [JudgeUserID]     nvarchar(128) NOT NULL ,
 [SectionID]       int NOT NULL ,
 [Deduction]	   decimal(4,2) NOT NULL,

 CONSTRAINT [PK_sectionstudentpenalty] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_TeamSectionPenalty_Event_EventID] FOREIGN KEY ([EventID])  REFERENCES [Event]([ID]),
 CONSTRAINT [FK_TeamSectionPenalty_Penalty_PenaltyID] FOREIGN KEY ([PenaltyID])  REFERENCES [Penalty]([ID]),
 CONSTRAINT [FK_TeamSectionPenalty_Section_SectionID] FOREIGN KEY ([SectionID])  REFERENCES [Section]([ID]),
 CONSTRAINT [FK_TeamSectionPenalty_Team_TeamID] FOREIGN KEY ([TeamID])  REFERENCES [Team]([ID]),
 CONSTRAINT [FK_TeamSectionPenalty_User_JudgeUserID] FOREIGN KEY ([JudgeUserID])  REFERENCES [AspNetUsers]([ID])
);
GO


CREATE NONCLUSTERED INDEX [fkIdx_443] ON [TeamSectionPenalty] 
 (
  [PenaltyID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_582] ON [TeamSectionPenalty] 
 (
  [EventID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_585] ON [TeamSectionPenalty] 
 (
  [TeamID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_589] ON [TeamSectionPenalty] 
 (
  [JudgeUserID] ASC
 )

GO

CREATE NONCLUSTERED INDEX [fkIdx_601] ON [TeamSectionPenalty] 
 (
  [SectionID] ASC
 )

GO




