export const environment = {
  production: true,
  apiUrl: "https://prostartinvitational-prod.azurewebsites.net/api",
  api_Url: "https://prostartinvitational-prod.azurewebsites.net/api/api",
};
