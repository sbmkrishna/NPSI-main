export const environment = {
  production: false,
  apiUrl: "http://dcpsc.softekdc.com:9500/api/",
  api_Url: "http://dcpsc.softekdc.com:9500/api/api/",
};
