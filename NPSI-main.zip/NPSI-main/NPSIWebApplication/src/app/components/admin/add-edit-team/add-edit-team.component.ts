import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NotificationService } from 'src/app/service/notification.service';
import *as _ from 'lodash';
import { TeamService } from 'src/app/service/team.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-edit-team',
  templateUrl: './add-edit-team.component.html',
  styleUrls: ['./add-edit-team.component.css']
})
export class AddEditTeamComponent implements OnInit {
  @Input("team") team: any;
  @Input("arrMembers") arrMembers: any;
  @Input("categories") categories: any;
  @Input("disableCategory") disableCategory: boolean;
  @Output("onSaveAddEditSuccess") onSaveAddEditSuccess = new EventEmitter();
  @Output("onCancelAddEditSuccess") onCancelAddEditSuccess = new EventEmitter();
  @ViewChild('formAddEditTeam') formAddEditTeam: NgForm;
  @ViewChild('formAddEditMember') formAddEditMember: NgForm;
  // pattern
  mask = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  phonePattern = /^\d{3}-\d{3}-\d{4}$/;
  emailPattern = "[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?";
  // letiables
  objectMember: any = {};
  objectTeam: any;
  members: any;
  indexMember: any;
  isLoading: boolean = false;
  isMemberAddEditing: any = false;

  constructor(private teamService: TeamService) { }

  ngOnInit(): void {
    this.members = JSON.parse(JSON.stringify(this.arrMembers));
    this.objectTeam = JSON.parse(JSON.stringify(this.team));
  }

  ngOnChanges() {
    this.members = JSON.parse(JSON.stringify(this.arrMembers));
    this.objectTeam = JSON.parse(JSON.stringify(this.team));
  }

  checkMemberInfo() {
    let isExistMember = {};
    let isValid = true;
    if (this.objectMember && this.objectMember.name) {
      if (this.members && this.members.length > 0) {
        isExistMember = _.find(this.members, (this.objectMember && this.objectMember.id) ? 'id' : this.objectMember);
        if (isExistMember) {
          isValid = this.saveEditMember(1);
        }
        else {
          isValid = this.addMember(1);
        }
      } else {
        isValid = this.addMember(1);
      }
    }
    return isValid;
  }
  save(mode) {
    let object = JSON.parse(JSON.stringify(this.objectTeam));
    let isValid = this.checkMemberInfo()
    if (mode == 0) { this.onSaveAddOrEdit(object, isValid) } else { return isValid; }
  }
  saveAddAnother() {
    let object = JSON.parse(JSON.stringify(this.objectTeam));
    let isValid = this.save(1);
    if (!isValid) {
      NotificationService.error("Member info is invalid.");
      return false;
    } else {
      this.createTeam(object).then((res) => {
        NotificationService.success("Add Team Successfully.");
        this.onSaveAddEditSuccess.emit(true);
        this.indexMember = null;
        this.formAddEditTeam.reset();
        this.formAddEditMember.reset();
        this.members = [];
      }, (err) => {
        NotificationService.error("An unknown server error occurred.");
      })
    }
  }
  onSaveAddOrEdit(object, isValid) {
    if (!isValid) {
      NotificationService.error("Member info is invalid.");
      return false;
    }
    object.members = JSON.parse(JSON.stringify(this.members));
    if (object.id) {
      this.teamService.editTeam(object).subscribe((res) => {
        NotificationService.success("Edit Team Successfully.");
        this.onSaveAddEditSuccess.emit();
        this.cancel();
      }, (err) => {
        NotificationService.error("An unknown server error occurred.");
      })
    } else {
      this.createTeam(object).then((res) => {
        NotificationService.success("Add Team Successfully.");
        this.onSaveAddEditSuccess.emit();
        this.cancel();
      }, (err) => {
        NotificationService.error("An unknown server error occurred.");
      });
    }
  }
  cancel() {
    this.indexMember = null;
    this.formAddEditTeam.reset();
    this.formAddEditMember.reset();
    this.members = [];
    this.onCancelAddEditSuccess.emit();
  }
  createTeam(object) {
    let promise = new Promise<void>((resolve, reject) => {
      this.isLoading = true;
      object.members = JSON.parse(JSON.stringify(this.members));
      this.teamService.createTeam(object).subscribe((res) => {
        this.members = [];
        this.formAddEditTeam.reset();
        this.isLoading = false;
        resolve();
      }, (err) => {
        this.isLoading = false;
        reject();
      })
    })
    return promise;
  }
  addMember(mode) {
    if (this.checkInValidAddEditMember()) {
      if (mode == 0) {
        return;
      } else {
        return false;
      }
    }
    let object = JSON.parse(JSON.stringify(this.objectMember));
    this.members.push(object);
    setTimeout(() => {
      this.objectMember = {};
      this.formAddEditMember.reset();
    })
    return true;
  }
  editMember(i) {
    this.indexMember = i;
    this.objectMember = JSON.parse(JSON.stringify(this.members[i]));
  }
  deleteMember(i) {
    this.members.splice(i, 1);
  }
  cancelEditMember() {
    this.indexMember = null;
    this.objectMember = {};
  }

  saveEditMember(mode) {
    if (this.checkInValidAddEditMember()) {
      if (mode == 0) {
        return;
      } else {
        return false;
      }
    }
    this.members[this.indexMember] = JSON.parse(JSON.stringify(this.objectMember));
    this.cancelEditMember();
    return true;
  }

  checkInValidAddEditMember() {
    if (this.isMemberAddEditing || this.formAddEditMember.invalid) {
      return true;
    } else {
      return false;
    }
  }
}
