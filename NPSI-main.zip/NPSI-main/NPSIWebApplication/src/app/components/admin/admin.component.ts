import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../../service/category.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  categories: any;
  active: any = 0;
  constructor(private categoryService: CategoryService, private router: Router, private activatedRouter: ActivatedRoute) { }

  ngOnInit(): void {
  }
}
