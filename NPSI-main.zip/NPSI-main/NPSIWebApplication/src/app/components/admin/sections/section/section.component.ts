import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { SectionService } from '../../../../service/section.service';
import * as _ from 'lodash';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { NgForm } from '@angular/forms';
import Swal from 'sweetalert2';
import { CategoryService } from '../../../../service/category.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  //@ViewChild('formAddEditSection') formAddEditSection: NgForm;
  @Input('categories') categories: any;
  keyword: any;
  sections: any;
  isAddEdit: any = false;
  //Pagination
  startItemSection: any;
  endItemSection: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  returnArray: any = [];
  //Sort
  sortBy: any = 'sortOrder';
  sortDescending: any = false;
  filterActive: any = true;

  //Add Edit Section
  objectSection: any = {
    categoryID: 1,
  };
  isLoading: any = false;
  constructor(private sectionService: SectionService,
    private categoryService: CategoryService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getSection();
    this.getCategory();
  }
  getCategory() {
    this.categoryService.getCategory().subscribe((res) => {
      this.categories = res;
    })
  }
  getSection() {
    let promise = new Promise<void>((resolve, reject) => {
      this.returnArray = [];
      this.sectionService.getSection().subscribe((res) => {
        this.sections = res;
        this.firstFilterActive();
        this.returnArray = _.orderBy(this.returnArray, [task => task['sortOrder']], ['asc']);
        this.firstSearchSettings();
        resolve();
      }, (err) => {
        reject(err);
      })
    })
    return promise;
  }
  firstFilterActive() {
    this.sections.forEach((item) => {
      if (item.active == this.filterActive) {
        this.returnArray.push(item);
      }
    });
  }
  firstSearchSettings() {
    this.sortBy = 'sortOrder';
    this.sortDescending = false;
    this.currentPage = 1;
    this.startItemSection = 0;
    this.endItemSection = 10;
  }
  onEnter() {
    this.search();
  }
  search(getAgainAfterDelete = null) {
    setTimeout(() => {
      this.returnArray = [];
      if (this.filterActive) {
        if (this.keyword) {
          this.sections.forEach((item) => {
            if (((item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1) || (item.categoryName && item.categoryName.toString().toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1)) && item.active == this.filterActive) {
              this.returnArray.push(item);
            }
          })
        } else {
          this.firstFilterActive();
        }
      } else {
        if (this.keyword) {
          this.sections.forEach((item) => {
            if (((item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1) || (item.categoryName && item.categoryName.toString().toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
              this.returnArray.push(item);
            }
          })
        } else {
          this.returnArray = JSON.parse(JSON.stringify(this.sections));
        }
      }

      this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
      if (!getAgainAfterDelete) {
        this.firstSearchSettings();
      }
    })
  }
  sort(sortBy, sortAgainAfterDelete = null) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    let orderBy = "";
    if (!sortAgainAfterDelete) {
      this.sortBy = sortBy;
      orderBy = this.sortDescending ? "desc" : "asc";
    } else {
      orderBy = this.sortDescending;
    }

    this.returnArray = _.orderBy(this.returnArray, [task => task[sortBy] && typeof task[sortBy] === 'string' ? task[sortBy].toLowerCase() : task[sortBy]], [orderBy]);
  }
  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.startItemSection = (event.page - 1) * event.itemsPerPage;
    this.endItemSection = event.page * event.itemsPerPage;
  }
  showChildModal(): void {
    this.isAddEdit = true;
    this.lgModal.show();
  }
  hideChildModal(): void {
    this.isAddEdit = false;
    this.lgModal.hide();
  }

  edit(s) {
    this.router.navigate(["admin/sections/", s.id], {queryParams: {mode: "Edit"}})
    // //var object = JSON.parse(JSON.stringify(s));
    // this.objectSection = null;
    // setTimeout(() => {
    //   this.objectSection = JSON.parse(JSON.stringify(s));
    // })
    // setTimeout(() => {
    //   this.showChildModal();
    // })
  }
  delete(id) {
    this.sectionService.checkSectionBeforDeleting(id).subscribe((res) => {
      if (res == "true") {
        Swal.fire({
          title: 'Are you sure?',
          text: 'Are you sure you want to delete Section ?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Confirm'
        }).then((result) => {
          if (result.value) {
            this.sectionService.deleteSection(id).subscribe((res) => {
              for (let i = 0; i < this.sections.length; i++) {
                let s = this.sections[i];
                if (s.id == id) {
                  this.sections.splice(i, 1);
                  break;
                }
              }
              this.search(true);
              this.sort(this.sortBy)
            }, (err) => {
              Swal.fire({
                position: 'top-end',
                icon: 'error',
                title: 'An unknown server error occurred.',
                showConfirmButton: false,
                timer: 3000,
                toast: true
              })
            })
          }
        })
      } else {
        Swal.fire({
          position: 'top-end',
          icon: 'warning',
          title: 'Section is in use !',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      }
    }, (err) => {

    })
  }
  addEditSuccess(object) {
    var bkStart = this.startItemSection;
    var bkEnd = this.endItemSection;
    var bkPage = this.currentPage;
    if (object.isSaveAnother == true) {
      this.getSection().then(() => {
        this.startItemSection = bkStart;
        this.endItemSection = bkEnd;
        this.currentPage = bkPage;
      });
    } else {
      this.getSection().then(() => {
        this.startItemSection = bkStart;
        this.endItemSection = bkEnd;
        this.currentPage = bkPage;
      });
      this.cancel();
    }
  }
  cancel() {
    this.objectSection = null;
    this.hideChildModal();
  }
}
