import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SectionService } from '../../../../service/section.service';
import { CategoryService } from '../../../../service/category.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-add-edit-section',
  templateUrl: './add-edit-section.component.html',
  styleUrls: ['./add-edit-section.component.css']
})
export class AddEditSectionComponent implements OnInit {
  @Input("section") section;
  @Input("isAddEdit") isAddEdit;
  @ViewChild('formAddEditSection') formAddEditSection: NgForm;
  @Output("cancel") cancel = new EventEmitter<any>();
  @Output("addEditSuccess") addEditSuccess = new EventEmitter<any>();
  objectSection: any;
  isLoading: any = false;
  categories: any;
  config = {
    placeholder: '',
    tabsize: 2,
    height: '200px',
  }
  constructor(
    private sectionService: SectionService,
    private categoryService: CategoryService,
    private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.objectSection = JSON.parse(JSON.stringify(this.section));
    this.getCategory();
  }
  getCategory() {
    this.categoryService.getCategory().subscribe((res) => {
      this.categories = res;
    })
  }
  createSection() {
    let promise = new Promise((resolve, reject) => {
      this.sectionService.createSection(this.objectSection).subscribe((res) => {
        resolve();
      }, (err) => {
        reject(err);
      })
    })
    return promise;
  }
  saveAddAnother() {
    this.createSection().then((res) => {
      setTimeout(() => {
        this.objectSection = {
          categoryID: 1,
        }
      })
      var object = {
        id: res,
        isSaveAnother: true,
      };
      this.formAddEditSection.reset();
      this.isAddEdit = false;
      setTimeout(() => {
        this.isAddEdit = true;
      })
      //this.objectSection = {
      //  description: " ",
      //}
      this.addEditSuccess.emit(object);
    }, (err) => {
      this.isLoading = false;
    })
  }
  save() {
    this.isLoading = true;
    if (this.objectSection.id) {
      this.sectionService.editSection(this.objectSection).subscribe((res) => {
        var object = {
          id: res,
          isSaveAnother: false
        };
        this.addEditSuccess.emit(object);
        this.isLoading = false;
        //});
      }, (err) => {
        this.isLoading = false;
      })
    } else {
      this.createSection().then((res) => {
        var object = {
          id: res,
          isSaveAnother: false
        };
        this.addEditSuccess.emit(object);
        this.isLoading = false;
      }, (err) => {
        this.isLoading = false;
      })
    }
  }
  cancelAddEdit() {
    this.formAddEditSection.reset();
    this.cancel.emit();
  }
}
