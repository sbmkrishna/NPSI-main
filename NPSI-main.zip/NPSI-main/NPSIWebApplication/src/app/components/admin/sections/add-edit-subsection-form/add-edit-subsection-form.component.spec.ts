import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditSubsectionFormComponent } from './add-edit-subsection-form.component';

describe('AddEditSubsectionFormComponent', () => {
  let component: AddEditSubsectionFormComponent;
  let fixture: ComponentFixture<AddEditSubsectionFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditSubsectionFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditSubsectionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
