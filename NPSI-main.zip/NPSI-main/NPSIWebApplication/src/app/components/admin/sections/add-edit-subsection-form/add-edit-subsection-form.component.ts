import { Component, Input, OnInit, Output, ViewChild, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { NotificationService } from 'src/app/service/notification.service';
import { SubsectionService } from 'src/app/service/subsection.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-add-edit-subsection-form',
  templateUrl: './add-edit-subsection-form.component.html',
  styleUrls: ['./add-edit-subsection-form.component.css']
})
export class AddEditSubsectionFormComponent implements OnInit {
  @Input("sectionId") sectionId?: number;
  @Input("subsection") subsection?: any;
  @Output("onCanceled") onCanceled = new EventEmitter();
  @Output("onSaved") onSaved = new EventEmitter<number>();
  @Output("onAdded") onAdded = new EventEmitter<any>();
  @ViewChild('criteriaModal') criteriaModal: ModalDirective;
  @ViewChild('formAddEditCriteria') formAddEditCriteria: NgForm;
  @ViewChild('formAddEditSubsection') formAddEditSubsection: NgForm;

  objectSubsection: any = {};
  rating: any = ["Poor", "Fair", "Good", "Very Good", "Excellent"];
  isLoading: any = false;
  isLoadingAddEditSubsection: any = false;
  keyword: any;
  isAddEditing: any = false;
  //pagination
  startItemSubsection: any;
  endItemSubsection: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  returnArray: any = [];
  //sort
  sortBy: any = 'name';
  sortDescending: any = false;
  filterActive: any = true;
  //Criteria
  criteria: any = [];
  objectCriteria: any = {};
  indexCriteria: any;
  config = {
    placeholder: '',
    tabsize: 2,
    height: '200px',
  }
  minimumMaxScore: any;
  constructor(private subsectionService: SubsectionService
  ) { }

  ngOnInit(): void {
  }

  ngOnChanges(): void {
    if (this.subsection) {
      this.objectSubsection = JSON.parse(JSON.stringify(this.subsection));
      this.criteria = (this.subsection && this.subsection.criteria) ? JSON.parse(JSON.stringify(this.subsection.criteria)) : [];
    }
    else {
      this.initialSubsection();

    }
  }

  initialSubsection() {
    this.objectSubsection.sectionID = this.sectionId; 
  }

  firstSearchSettings() {
    this.sortBy = 'name';
    this.sortDescending = false;
    this.currentPage = 1;
    this.startItemSubsection = 0;
    this.endItemSubsection = 10;
  }

  sort(sortBy) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    this.sortBy = sortBy;
    let orderBy = this.sortDescending ? "desc" : "asc";
    this.returnArray = _.orderBy(this.returnArray, [task => task[sortBy] && typeof task[sortBy] === 'string' ? task[sortBy].toLowerCase() : task[sortBy]], [orderBy]);
  }

  add() {
    this.isAddEditing = true;
    this.initialSubsection();
  }
  edit(s) {
    this.subsectionService.getSubsectionDetail(s.id).subscribe((res: any) => {
      this.isAddEditing = true;
      this.objectSubsection = res;
      this.criteria = JSON.parse(JSON.stringify(res.criteria));
    })
  }
  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.startItemSubsection = (event.page - 1) * event.itemsPerPage;
    this.endItemSubsection = event.page * event.itemsPerPage;
  }
  showChildModal(): void {
    this.criteriaModal.show();
  }
  hideChildModal(): void {
    this.indexCriteria = null;
    this.formAddEditCriteria.reset();
    this.criteriaModal.hide();
  }
  addCriteria() {
    this.showChildModal();
  }
  saveCriteria() {
    var object = JSON.parse(JSON.stringify(this.objectCriteria));
    if (this.indexCriteria != null) {
      this.criteria[this.indexCriteria] = object;
      this.indexCriteria = null;
    } else {
      this.criteria.push(object);
      this.indexCriteria = null;
    }
    setTimeout(() => {
      this.hideChildModal();
    })

  }
  saveCriteriaAddAnother() {
    var object = JSON.parse(JSON.stringify(this.objectCriteria));
    this.criteria.push(object);
    this.indexCriteria = null;
    setTimeout(() => {
      this.formAddEditCriteria.reset();
    })
  }

  editCriteria(c, i) {
    this.indexCriteria = i;
    this.objectCriteria = JSON.parse(JSON.stringify(c));
    this.showChildModal();
  }

  deleteCriteria(i) {
    this.criteria.splice(i, 1);
  }

  saveSubsectionAddAnother() {
    this.isLoadingAddEditSubsection = true;
    this.createSubection().then((res) => {
      this.onAdded.emit(true);
      this.isLoadingAddEditSubsection = false;
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
      this.isLoadingAddEditSubsection = false;
    })
  }

  saveSubsection() {
    this.isLoadingAddEditSubsection = true;
    if (this.objectSubsection.id) {
      var object = JSON.parse(JSON.stringify(this.objectSubsection));
      object.criteria = this.criteria;
      this.subsectionService.editSubsection(object).subscribe((res) => {
        this.isLoadingAddEditSubsection = false;
        this.formAddEditSubsection.reset();
        this.onSaved.emit();
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
        this.isLoadingAddEditSubsection = false;
        this.isAddEditing = false;
      })
    } else {
      this.createSubection().then((res) => {
        this.isLoadingAddEditSubsection = false;
        this.isAddEditing = false;
        this.onAdded.emit(false);
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
        this.isLoadingAddEditSubsection = false;
        this.isAddEditing = false;
      })
    }

  }

  createSubection() {
    this.objectSubsection.sectionID = this.sectionId;
    let promise = new Promise<void>((resolve, reject) => {
      var object = JSON.parse(JSON.stringify(this.objectSubsection));
      object.criteria = this.criteria;
      this.subsectionService.createSubsection(object).subscribe((res) => {
        this.criteria = [];
        this.initialSubsection();
        this.formAddEditSubsection.reset();
        resolve();
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
        reject();
      })
    })
    return promise;
  }

  cancel() {
    this.isAddEditing = false;
    this.criteria = [];
    this.objectSubsection = {}
    this.formAddEditSubsection.reset();
    this.onCanceled.emit();
  }

}
