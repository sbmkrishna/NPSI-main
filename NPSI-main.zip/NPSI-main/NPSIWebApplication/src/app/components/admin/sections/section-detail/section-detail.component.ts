import { Component, OnInit, ViewChild } from '@angular/core';
import { SectionService } from '../../../../service/section.service';
import { ActivatedRoute } from '@angular/router';
import { SubsectionService } from '../../../../service/subsection.service';
import { PenaltyService } from '../../../../service/penalty.service';
import { DisqualificationService } from '../../../../service/disqualification.service';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import { NotificationService } from '../../../../service/notification.service';
import * as _ from 'lodash';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-section-detail',
  templateUrl: './section-detail.component.html',
  styleUrls: ['./section-detail.component.css']
})
export class SectionDetailComponent implements OnInit {

  @ViewChild('lgModal') lgModal: ModalDirective;
  @ViewChild('editSection') editSection: ModalDirective;
  @ViewChild('mainModal') mainModal: ModalDirective;
  sectionID: any;
  section: any;
  sectionSubsections: any = [];
  sectionPenalties: any = [];
  sectionDisqualifications: any = [];
  penalties: any = [];
  subsections: any = [];
  disqualifications: any = [];
  bkPens: any = [];
  bkSubs: any = [];
  bkDis: any = [];
  listId: any = [];
  selectName: any;
  //Pagination
  startItem: any;
  endItem: any;
  itemsPerPage: any = 5;
  currentPage: any = 1;
  returnArray: any = [];
  keyword: any;
  objectAdd: any = {};
  isLoading: any = false;
  objectSection: any;
  listSortNumber: any = [];
  isEditing: boolean = false;
  openingSubsectionForm: boolean = false;
  editedSubsection: any = {};

  constructor(private sectionService: SectionService,
    private subsectionService: SubsectionService,
    private penaltyService: PenaltyService,
    private disqualificationService: DisqualificationService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.sectionID = params.sectionID;
    })

    this.activatedRoute.queryParams.subscribe(params => {
      const mode = params['mode'];
      if (mode == "Edit") {
        this.isEditing = true;
      }
    });

    if (this.sectionID) {
      this.getSectionDetail().then((res) => {
        this.section = res;
        this.getSubsectionBySectionID();
      })

      this.getPenaltiesBySectionID();
      this.getDisqualificationsBySectionID();
    }
    this.getPenaltiesActive();
    this.getDisqualificationActive();

  }
  getSectionDetail() {
    let promise = new Promise((resolve, reject) => {
      this.sectionService.getSectionDetail(this.sectionID).subscribe((res) => {
      console.log('res :', res);
        resolve(res);
      }, (err) => {
        reject(err);
      })
    })
    return promise;
  }

  onCanceledEditing() {
    this.isEditing = false;
  }

  onSavedEditing($event) {
    this.isEditing = false;
    this.getSectionDetail().then((res) => {
      this.section = res;
    })
  }


  getSubsectionBySectionID() {
    let promise = new Promise<void>((resolve, reject) => {
      this.sectionService.getSubsectionBySectionID(this.sectionID).subscribe((res: any) => {
        this.listSortNumber = [];
        this.sectionSubsections = res;
        this.sectionSubsections = _.orderBy(this.sectionSubsections, [function (resultItem) { return (resultItem.sortIndex == 0 || resultItem.sortIndex == null) ? 999 : resultItem.sortIndex; }, 'sortIndex'], ['asc']);
        var totalItem = this.sectionSubsections.length;
        for (var i = 0; i < totalItem; i++) {
          this.listSortNumber.push(i + 1);
        }
        resolve();
      }, (err) => {
        reject(err);
        NotificationService.error('An unknown server error occurred.');
      })
    })
    return promise;
  }
  getDisqualificationsBySectionID() {
    let promise = new Promise<void>((resolve, reject) => {
      this.sectionService.getDisqualificationsBySectionID(this.sectionID).subscribe((res) => {
        this.sectionDisqualifications = res;
        resolve();
      }, (err) => {
        reject(err);
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    })
    return promise;
  }
  getPenaltiesBySectionID() {
    let promise = new Promise<void>((resolve, reject) => {
      this.sectionService.getPenaltiesBySectionID(this.sectionID).subscribe((res) => {
        this.sectionPenalties = res;
        resolve();
      }, (err) => {
        reject(err);
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    })
    return promise;
  }
  getPenaltiesActive() {
    let promise = new Promise<void>((resolve, reject) => {
      this.penaltyService.getPenaltiesActive().subscribe((res) => {
        this.penalties = res;
        resolve();
      }, (err) => {
        reject(err);
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    })
    return promise;
  }
  getDisqualificationActive() {
    let promise = new Promise<void>((resolve, reject) => {
      this.disqualificationService.getDisqualificationActive().subscribe((res) => {
        this.disqualifications = res;
        resolve();
      }, (err) => {
        reject(err);
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    })
    return promise;
  }
  getSubsectionByCategory(id) {
    let promise = new Promise<void>((resolve, reject) => {
      this.subsectionService.getSubsectionByCategory(id).subscribe((res) => {
        this.subsections = res;
        resolve();
      }, (err) => {
        reject(err);
        NotificationService.error('An unknown server error occurred.');
      })
    })
    return promise;
  }
  openPopup(selectName) {
    this.returnArray = [];
    this.keyword = "";
    this.selectName = selectName;
    if (this.selectName == 'Subsections') {
      this.bkSubs = JSON.parse(JSON.stringify(this.subsections));
      this.hanldeOpenPopup(this.subsections, this.sectionSubsections);
    }
    else if (this.selectName == 'Penalties') {
      this.bkPens = JSON.parse(JSON.stringify(this.penalties));
      this.hanldeOpenPopup(this.penalties, this.sectionPenalties);
    } else {
      this.bkDis = JSON.parse(JSON.stringify(this.disqualifications));
      this.hanldeOpenPopup(this.disqualifications, this.sectionDisqualifications);
    }
    this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
    //this.firstSearchSettings();
    this.showChildModal();

  }
  hanldeOpenPopup(listActive: any, listBySection: any) {
    var list = JSON.parse(JSON.stringify(listActive));
    for (let i = 0; i < list.length; i++) {
      for (let j = 0; j < listBySection.length; j++) {
        if (list[i].id == listBySection[j].id) {
          list.splice(i, 1);
          i--;
          break;
        }
      }
    }
    this.returnArray = JSON.parse(JSON.stringify(list));
  }
  showChildModal(): void {
    this.lgModal.show();
  }
  hideChildModal(): void {
    this.lgModal.hide();
  }

  showEditSectionModal(): void {
    this.editSection.show();
  }
  hideEditSectionModal(): void {
    this.editSection.hide();
  }
  editSectionDetail() {
    this.objectSection = JSON.parse(JSON.stringify(this.section));
    setTimeout(() => {
      this.showEditSectionModal();
    })
  }
  cancel() {
    if (this.selectName == 'Subsections') {
      this.subsections = JSON.parse(JSON.stringify(this.bkSubs));
    }
    else if (this.selectName == 'Penalties') {
      this.penalties = JSON.parse(JSON.stringify(this.bkPens));
    } else {
      this.disqualifications = JSON.parse(JSON.stringify(this.bkDis));
    }
    this.returnArray = [];
    this.hideChildModal();
  }
  search() {
    if (this.selectName == 'Subsections') {
      this.handleSearch(this.subsections, this.sectionSubsections);
    }
    else if (this.selectName == 'Penalties') {
      this.handleSearch(this.penalties, this.sectionPenalties);
    }
    else {
      this.handleSearch(this.disqualifications, this.sectionDisqualifications);
    }
  }

  changeChecked(value) {
    if (this.selectName == 'Subsections') {
      this.handleChangeChecked(value, this.subsections);
    }
    else if (this.selectName == 'Penalties') {
      this.handleChangeChecked(value, this.penalties);
    }
    else {
      this.handleChangeChecked(value, this.disqualifications);
    }
  }
  changeSortIndex(item) {
    setTimeout(() => {
      for (var i = 0; i < this.subsections.length; i++) {
        var sub = this.subsections[i]
        if (sub.id == item.id) {
          sub.sortIndex = item.sortIndex;
          break;
        }
      }
    })
  }

  handleChangeChecked(value, arr) {
    for (var i = 0; i < arr.length; i++) {
      if (value.id == arr[i].id) {
        arr[i].checked = value.checked;
        if (this.selectName == 'Subsections') {
          arr[i].sortIndex = value.checked ? this.listSortNumber.length + 1 : null;
        }
        break;
      }
    }
    if (this.selectName == 'Subsections') {
      //remove/add sort index
      if (!value.checked) {
        this.listSortNumber.splice(this.listSortNumber.length - 1, 1);
      }
      else {
        this.listSortNumber.push(this.listSortNumber.length + 1);
      }

      for (var i = 0; this.returnArray.length; i++) {
        if (value.id == this.returnArray[i].id) {
          this.returnArray[i].sortIndex = value.checked ? this.listSortNumber[this.listSortNumber.length - 1] : null
          break;
        }
      }
    }
    if (!value.checked) {
      for (var i = 0; i < this.listId.length; i++) {
        if (value.id == this.listId[i]) {
          this.listId.splice(i, 1);
          break;
        }
      }
    } else {
      this.listId.push(value.id);
    }
  }
  handleSearch(listValue: any, listBySection: any) {
    setTimeout(() => {
      this.returnArray = [];
      if (this.keyword) {
        listValue.forEach((item) => {
          if (((item && item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
            this.returnArray.push(item);
          }
        })
      } else {
        this.returnArray = JSON.parse(JSON.stringify(listValue))
        //this.firstSearchSettings();
      }
      for (var i = 0; i < this.returnArray.length; i++) {
        for (var j = 0; j < listBySection.length; j++) {
          if (this.returnArray[i].id == listBySection[j].id) {
            this.returnArray.splice(i, 1);
            i--;
          }
        }
      }
      this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
      //this.firstSearchSettings();
    })
  }
  changeSubSortIndexOnTable(sub) {
    let object = {
      sectionID: null,
      subsectionID: null,
      sortIndex: null
    };
    setTimeout(() => {
      object.sectionID = this.sectionID;
      object.subsectionID = sub.id;
      object.sortIndex = sub.sortIndex;
      this.sectionService.changeSortIndex(object).subscribe((res) => {
        this.getSubsectionBySectionID();
        NotificationService.success('Updated subsection order successfully.');
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
      })
    })
  }

  onSavedSubsection() {
    this.openingSubsectionForm = false;
    this.editedSubsection = {};
    this.mainModal.hide();
    this.getSubsectionBySectionID();
  }

  addPenalties() {
    this.isLoading = true;
    this.handleBeforeAdd(this.sectionPenalties);
    this.sectionService.addPenalty(this.objectAdd).subscribe((res) => {
      this.getPenaltiesBySectionID();
      this.handleAfterAdd();
      this.isLoading = false;
    }, (err) => {
      this.isLoading = false;
      NotificationService.error('An unknown server error occurred.');
    })
  }
  addDisqualifications() {
    this.isLoading = true;
    this.handleBeforeAdd(this.sectionDisqualifications);
    this.sectionService.addDisqualifications(this.objectAdd).subscribe((res) => {
      this.getDisqualificationsBySectionID();
      this.handleAfterAdd();
      this.isLoading = false;
    }, (err) => {
      this.isLoading = false;
      NotificationService.error('An unknown server error occurred.');
    })
  }
  handleAfterAdd() {
    this.cancel();
    this.returnArray = [];
    this.keyword = "";
    this.listId = [];
    this.objectAdd = {};
    NotificationService.success('Add ' + this.selectName + ' Successfully.');
  }
  handleBeforeAdd(listSelected: any) {
    for (let i = 0; i < this.listId.length; i++) {
      listSelected.forEach((item) => {
        if (item.id == this.listId[i]) {
          this.listId.splice(i, 1);
          i--;
        }
      })
    }

    if (this.selectName == "Subsections") {
      var arrObject = [];
      this.listId.forEach((item) => {
        this.subsections.forEach((sub) => {
          if (item == sub.id) {
            arrObject.push({
              id: item,
              sortIndex: sub.sortIndex,
            })
          }
        })
      })
      this.objectAdd = {
        sectionID: this.sectionID,
        subSorts: arrObject
      }
    } else {
      this.objectAdd = {
        sectionID: this.sectionID,
        ids: this.listId
      }
    }

  }
  deleteDisqualifications(id) {
    NotificationService.confirm('Are you sure you want to delete Disqualifications ?').then((res) => {
      if (res.value) {
        this.sectionService.deleteDisqualifications(this.section.id, id).subscribe((res) => {
          this.getDisqualificationsBySectionID();
        }, (err) => {
          NotificationService.error('An unknown server error occurred.');
        })
      }
    })

  }
  deleteSubsection(id) {
    NotificationService.confirm('Are you sure you want to delete Subsection ?').then((res) => {
      if (res.value) {
        this.sectionService.deleteSubsection(this.section.id, id).subscribe((res) => {
          this.getSubsectionBySectionID();
        }, (err) => {
          if (err.status == 400 && err.error.message == "Scores existed") {
            NotificationService.error('At least a score has been recorded for this subsection, you cannot delete it.');
          }
          else {
            NotificationService.error('An unknown server error occurred.');
          }
        })
      }
    })
  }
  deletePenalty(id) {
    NotificationService.confirm('Are you sure you want to delete Penalty ?').then((res) => {
      if (res.value) {
        this.sectionService.deletePenalty(this.section.id, id).subscribe((res) => {
          this.getPenaltiesBySectionID();
        }, (err) => {
          NotificationService.error('An unknown server error occurred.');
        })
      }
    })
  }
  addEditSuccess(value) {
    this.getSectionDetail().then((res) => {
      this.section = res;
    });
    this.cancelEdit();
  }
  cancelEdit() {
    this.objectSection = null;
    this.hideEditSectionModal();
  }

  openSubsection(sub) {
    this.openingSubsectionForm = true;
    this.editedSubsection = sub ? sub : null;
    this.mainModal.show();
  }

  onCanceledSubsection() {
    this.openingSubsectionForm = false; 
    this.editedSubsection = null;
    this.mainModal.hide();
  }
  onAddedSubsection(value){
    this.openingSubsectionForm = false;
    this.editedSubsection = null;
    this.getSubsectionBySectionID();
    if(!value){
      this.mainModal.hide();
    }
  }
}
