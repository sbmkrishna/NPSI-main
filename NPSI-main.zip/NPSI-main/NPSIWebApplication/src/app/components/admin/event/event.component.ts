import { Component, OnInit, ViewChild } from '@angular/core';
import { EventService } from '../../../service/event.service';
import { CategoryService } from '../../../service/category.service';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { NgForm } from '@angular/forms';
import Swal from 'sweetalert2';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/service/notification.service';
@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  categories: any;
  status: any;
  objectSearch: any = {
    categoryID: null,
    statusID: null,
    returnTotalCount: true,
    sortedBy: "StartDateTime asc",
  }
  count: any;
  events: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  bkObjectFilter: any;
  sortBy: string = 'StartDateTime';
  sortDescending: boolean = false;
  objectEvent: any = null;
  isLoading: any = false;
  minDate: Date = new Date();
  maxDate: Date;
  bkStatus: any;
  listStatusID: any;
  user: any;
  constructor(private eventService: EventService,
    private categoryService: CategoryService,
    private router: Router) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));
    this.getEventStatus().then((res) => {
      this.bkStatus = JSON.parse(JSON.stringify(this.status));
      this.listStatusID = [];
      this.status.forEach((item) => {
        if (item.checked) {
          this.listStatusID.push(item.id);
        }
      })
      this.objectSearch.listStatusID = JSON.parse(JSON.stringify(this.listStatusID));
      this.bkObjectFilter = JSON.parse(JSON.stringify(this.objectSearch));
      this.getEvent(this.bkObjectFilter);
    });
    this.getCategory();
  }

  getCategory() {
    this.categoryService.getCategory().subscribe((res) => {
      this.categories = res;
    })
  }

  getEventStatus() {
    let promise = new Promise<void>((resolve, reject) => {
      this.eventService.getEventStatus().subscribe((res) => {
        this.status = res;
        this.status.forEach((item) => {
          if (item.statusName == "Opened" || item.statusName == "Started") {
            item.checked = true;
          }
        })
        resolve();
      }, (err) => {
        reject();
      })
    })
    return promise;
  }

  handleDate(date){
    //set Hours, minutes, seconds = 0, and adjust timezone
    let newDate = new Date(date)
    newDate.setHours(0, 0, 0, 0);
    return this.adjustForTimezone(newDate);
  }

  getEvent(object) {
    var obj = { ...object };
    if (obj.startDateFrom) {
      obj.startDateFrom = this.handleDate(obj.startDateFrom);
    }
    if (obj.startDateTo) {
      obj.startDateTo = this.handleDate(obj.startDateTo);
    }
    if (obj.endDateFrom) {
      obj.endDateFrom = this.handleDate(obj.endDateFrom);
    }
    if (obj.endDateTo) {
      obj.endDateTo = this.handleDate(obj.endDateTo);
    }
    this.eventService.searchEvent(obj).subscribe((res: any) => {
      if (res.count) {
        this.count = res.count
      }
      this.events = res.data;
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  pageChanged(event: PageChangedEvent): void {
    this.bkObjectFilter.itemsPerPage = event.itemsPerPage;
    this.bkObjectFilter.pageNumber = this.currentPage = event.page;
    this.bkObjectFilter.returnTotalCount = false;
    this.getEvent(this.bkObjectFilter);
  }

  searchEvent() {
     this.sortBy = 'StartDateTime';
    this.sortDescending = false;
    this.currentPage = 1;
    this.listStatusID = [];
    this.status.forEach((item) => {
      if (item.checked) {
        this.listStatusID.push(item.id);
      }
    });
    this.objectSearch.listStatusID = JSON.parse(JSON.stringify(this.listStatusID));
    this.bkObjectFilter = JSON.parse(JSON.stringify(this.objectSearch));
    this.getEvent(this.bkObjectFilter);
  }

  reset() {
    this.objectSearch = {
      categoryID: null,
      statusID: null,
      returnTotalCount: true,
      sortedBy: "StartDateTime asc",
    };
    this.status = JSON.parse(JSON.stringify(this.bkStatus));
    this.searchEvent();
  }

  sort(sortBy) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    this.sortBy = sortBy;
    let orderBy = this.sortDescending ? "descending" : "asc"
    this.bkObjectFilter.SortedBy = sortBy + " " + orderBy;
    this.getEvent(this.bkObjectFilter);
  }

  add() {
    this.objectEvent = {};
    setTimeout(() => {
      this.lgModal.show();
    })
  }

  cancel() {
    this.objectEvent = null;
    this.lgModal.hide();
  }

  startEvent(id) {
    this.eventService.startEvent(id).subscribe((res) => {
      this.getEvent(this.bkObjectFilter);
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Start Event Successfully.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      if (err.error == "The event has been started.") {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'The event has been started.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      } else {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      }

    })
  }

  adjustForTimezone(date: Date): Date {
    var timeOffsetInMS: number = date.getTimezoneOffset() * 60000;
    date.setTime(date.getTime() - timeOffsetInMS);
    return date;
  }

  addEditSuccess(object) {
    if (object.isSaveAnother == true) {
      this.getEvent(this.bkObjectFilter);
    } else {
      this.getEvent(this.bkObjectFilter);
      this.cancel();
      if (object.id) {
        this.router.navigate(['/admin/events/', object.id]);
      }
    }
  }

  gotoDetail(e) {
    if (this.user && this.user.isSuperAdmin) {
      setTimeout(() => {
        this.router.navigate(['/admin/events/', e.id]);
      })
    } else {
      setTimeout(() => {
        this.router.navigate(['/event-admin-dashboard/events/', e.id]);
      })
    }
  }

  openEditEvent(e){
    this.objectEvent = JSON.parse(JSON.stringify(e));
    setTimeout(() => {
      this.lgModal.show();
    })
  }
  
  gotoEventRun(e) {
    if (this.user && this.user.isSuperAdmin) {
      setTimeout(() => {
        this.router.navigate(['/admin/events/', e.id, 'run']);
      })
    } else {
      setTimeout(() => {
        this.router.navigate(['/event-admin-dashboard/events/', e.id, 'run']);
      })
    }
  }
  startEndEventSuccess(value) {
    this.getEvent(this.bkObjectFilter);
    this.lgModal.hide();
  }
}
