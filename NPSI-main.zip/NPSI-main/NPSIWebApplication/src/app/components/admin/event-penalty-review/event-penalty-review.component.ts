import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NotificationService } from 'src/app/service/notification.service';
import { EventService } from '../../../service/event.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-event-penalty-review',
  templateUrl: './event-penalty-review.component.html',
  styleUrls: ['./event-penalty-review.component.css']
})
export class EventPenaltyReviewComponent implements OnInit {
  @Input("categoryID") categoryID;
  eventID: any;
  penalties: any;
  sortBy: any = 'createdDateTime';
  sortDescending: any = false;

  constructor(
    private eventService: EventService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
    })
    if (this.eventID) {
      this.eventService.getEventCategoryPenalties(this.eventID, this.categoryID).subscribe((res) => {
        this.penalties = _.orderBy(res, ['createdDateTime'], ['asc']);
        console.log(this.penalties);
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
      })
    }
  }

  sort(sortBy, sortAgainAfterDelete = null) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    let orderBy = "";
    if (!sortAgainAfterDelete) {
      this.sortBy = sortBy;
      orderBy = this.sortDescending ? "desc" : "asc";
    } else {
      orderBy = this.sortDescending;
    }

    this.penalties = _.orderBy(this.penalties, [task => task[sortBy] && typeof task[sortBy] === 'string' ? task[sortBy].toLowerCase() : task[sortBy]], [orderBy]);
  }

  approve(penalty) {
    const penaltyStatus = {
      id: penalty.id,
      penaltyStatusID: 1
    };

    NotificationService.confirm("This will approve the selected penalty and include it in the team's score. This operation cannot be undone.").then((res) => {
      if (res.value) {
        this.eventService.editTeamSectionPenaltyStatus(penaltyStatus).subscribe((res) => {
          NotificationService.success('Penalty status updated successfully.');
          penalty.penaltyStatusID = penaltyStatus.penaltyStatusID;
          penalty.statusCode = 'A';
          penalty.statusName = 'Approved';
        }, (err) => {
          if ((err.error) && (err.error.message))
            NotificationService.error(err.error.message);
          else
            NotificationService.error(err.message);
        })
      }
    })
  }

  deny(penalty) {
    const penaltyStatus = {
      id: penalty.id,
      penaltyStatusID: -1
    };

    NotificationService.confirm("This will deny the selected penalty and it will not be counted in the the team's score. This operation cannot be undone.").then((res) => {
      if (res.value) {
        this.eventService.editTeamSectionPenaltyStatus(penaltyStatus).subscribe((res) => {
          NotificationService.success('Penalty status updated successfully.');
          penalty.penaltyStatusID = penaltyStatus.penaltyStatusID;
          penalty.statusCode = 'D';
          penalty.statusName = 'Denied';
        }, (err) => {
          if ((err.error) && (err.error.message))
            NotificationService.error(err.error.message);
          else
            NotificationService.error(err.message);
        })
      }
    })    
  }
}
