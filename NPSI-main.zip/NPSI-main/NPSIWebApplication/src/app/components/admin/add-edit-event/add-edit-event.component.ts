import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EventService } from '../../../service/event.service';
import Swal from 'sweetalert2';
import { NotificationService } from 'src/app/service/notification.service';

@Component({
  selector: 'app-add-edit-event',
  templateUrl: './add-edit-event.component.html',
  styleUrls: ['./add-edit-event.component.css']
})
export class AddEditEventComponent implements OnInit {
  @Input("event") event;
  @ViewChild('formAddEditEvent') formAddEditEvent: NgForm;
  @Output("cancel") cancel = new EventEmitter<any>();
  @Output("addEditSuccess") addEditSuccess = new EventEmitter<any>();
  @Output("startEndEventSuccess") startEndEventSuccess = new EventEmitter<any>();
  objectEvent: any;
  isLoading: any = false;
  minDate: any;
  constructor(private eventService: EventService,) { }

  ngOnInit(): void {
    this.objectEvent = JSON.parse(JSON.stringify(this.event));
    if (this.objectEvent.id) {
      this.objectEvent.isEdit = true;
      this.objectEvent.startDateTime = new Date(this.objectEvent.startDateTime);
      this.objectEvent.endDateTime = new Date(this.objectEvent.endDateTime);
      for (let i = 0; i < this.objectEvent.categories.length; i++) {
        var category = this.objectEvent.categories[i];
        if (category.name == 'Management') {
          this.objectEvent.categoryManagement = true;
        } else {
          this.objectEvent.categoryCulinary = true;
        }
      }
    } else {
      this.objectEvent = {
        isEdit: false
      };
    }
  }
  ngOnChanges(): void {
    this.objectEvent = JSON.parse(JSON.stringify(this.event));
    if (this.objectEvent.id) {
      this.objectEvent.isEdit = true;
      this.objectEvent.startDateTime = new Date(this.objectEvent.startDateTime);
      this.objectEvent.endDateTime = new Date(this.objectEvent.endDateTime);
      for (let i = 0; i < this.objectEvent.categories.length; i++) {
        var category = this.objectEvent.categories[i];
        if (category.name == 'Management') {
          this.objectEvent.categoryManagement = true;
        } else {
          this.objectEvent.categoryCulinary = true;
        }
      }
    } else {
      this.objectEvent = {
        isEdit: false
      };
    }
  }
  createEvent() {
    let promise = new Promise((resolve, reject) => {
      this.isLoading = true;
      var object = JSON.parse(JSON.stringify(this.objectEvent));
      this.handleBeforeSave(object);
      this.eventService.createEvent(object).subscribe((res) => {
        this.formAddEditEvent.reset();
        this.isLoading = false;
        resolve(res);
      }, (err) => {
        this.isLoading = false;
        reject();
      })
    })
    return promise;
  }
  handleBeforeSave(object) {
    //format time and group categoryID to array
    object.categoryIDs = [];
    if (object.categoryManagement) {
      object.categoryIDs.push(1);
    }
    if (object.categoryCulinary) {
      object.categoryIDs.push(2);
    }

    object.startDateTime = new Date(object.startDateTime)
    object.startDateTime.setHours(0, 0, 0, 0);
    object.startDateTime = this.adjustForTimezone(object.startDateTime);


    object.endDateTime = new Date(object.endDateTime)
    object.endDateTime.setHours(0, 0, 0, 0);
    object.endDateTime = this.adjustForTimezone(object.endDateTime);
  }
  adjustForTimezone(date: Date): Date {
    var timeOffsetInMS: number = date.getTimezoneOffset() * 60000;
    date.setTime(date.getTime() - timeOffsetInMS);
    return date
  }
  saveAddAnother() {
    this.createEvent().then((res) => {
      this.objectEvent = {};
      var object = {
        id: res,
        isSaveAnother: true,
      };
      this.addEditSuccess.emit(object);
    }, (err) => {
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: 'An unknown server error occurred.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    })
  }
  save() {
    if (this.objectEvent.id) {
      this.isLoading = true;
      var object = JSON.parse(JSON.stringify(this.objectEvent));
      this.handleBeforeSave(object);
      this.eventService.editEvent(object).subscribe((res) => {
        var object = {
          id: res,
          isSaveAnother: false
        };
        this.addEditSuccess.emit(object);
        this.isLoading = false;
      }, (err) => {
        this.isLoading = false;
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    } else {
      this.createEvent().then((res) => {
        var object = {
          id: res,
          isSaveAnother: false
        };
        this.addEditSuccess.emit(object);
      }, (err) => {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      });
    }
  }
  cancelAddEdit() {
    this.formAddEditEvent.reset();
    this.cancel.emit();
  }
  startEvent(id) {
    this.eventService.startEvent(id).subscribe((res) => {
      this.startEndEventSuccess.emit(true);
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Start Event Successfully.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      if (err.error == "The event has been started.") {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'The event has been started.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      } else {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      }

    })
  }
  endEvent(id) {
    Swal.fire({
      title: "Are you sure you want to end this event?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Confirm'
    }).then((result) => {
      if (result.value) {
        this.eventService.endEvent(id).subscribe((res) => {
          this.startEndEventSuccess.emit(true);
          NotificationService.success("End event successfully.");
        })
      }
    })

  }
}
