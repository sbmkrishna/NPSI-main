import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventRunComponent } from './event-run.component';

describe('EventRunComponent', () => {
  let component: EventRunComponent;
  let fixture: ComponentFixture<EventRunComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventRunComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventRunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
