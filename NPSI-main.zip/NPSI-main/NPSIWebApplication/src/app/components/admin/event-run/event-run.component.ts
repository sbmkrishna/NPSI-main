import { Component, OnInit } from '@angular/core';
import { EventService } from '../../../service/event.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../../service/notification.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-event-run',
  templateUrl: './event-run.component.html',
  styleUrls: ['./event-run.component.css']
})
export class EventRunComponent implements OnInit {
  eventID: any;
  event: any;
  categoryManagementID: any;
  categoryCulinaryID: any;
  listCategoryNameByEventAdmin: any;
  user: any;
  currentCategoryID: any;

  constructor(private eventService: EventService,
    private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
    })
    if (this.eventID) {
      this.getEventDetail();
    }
    if (this.eventID && this.user && !this.user.isSuperAdmin && this.user.roles && this.user.roles.indexOf("Event - Admin") != -1) {
      this.getCategoryByEventAdmin();
    }
  }
  getCategoryByEventAdmin() {
    this.eventService.getCategoryByEventAdmin(this.eventID).subscribe((res) => {
      this.listCategoryNameByEventAdmin = res;
    })
  }
  getEventDetail() {
    this.eventService.getEventDetail(this.eventID).subscribe((res) => {
      this.event = res;
      this.event.categoriesName = [];
      this.event.categories.forEach((item) => {
        this.event.categoriesName.push(item.name);
        if (item.name == 'Management') {
          this.categoryManagementID = item.id;
        } else {
          this.categoryCulinaryID = item.id
        }
      })
    }, (err) => {

    })
  }
  endEvent() {
    Swal.fire({
      title: "Are you sure you want to end this event?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Confirm'
    }).then((result) => {
      if (result.value) {
        this.eventService.endEvent(this.eventID).subscribe((res) => {
          this.getEventDetail();
          NotificationService.success("End event successfully.");
        })
      }
    })

  }
  startEvent() {
    this.eventService.startEvent(this.eventID).subscribe((res) => {
      this.getEventDetail();
      NotificationService.success("Start Event Successfully.");
    }, (err) => {
      if (err.error == "The event has been started.") {
        NotificationService.error("The event has been started.");
      } else {
        NotificationService.error("An unknown server error occurred.");
      }
    })
  }
  goToReports() {
    setTimeout(() => {
      this.router.navigate(['/admin/report'], { queryParams: { eventID: this.eventID }},);
    })
  }
}
