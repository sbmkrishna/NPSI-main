import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/service/notification.service';
import { EventService } from '../../../service/event.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-event-run-general',
  templateUrl: './event-run-general.component.html',
  styleUrls: ['./event-run-general.component.css']
})
export class EventRunGeneralComponent implements OnInit {
  @Input("categoryID") categoryID;
  @Input("isLeadJudge") isLeadJudge;
  eventID: any;
  sections: any;
  expandedIndex = 0;
  judgeUserId: any;
  listCategoryJudges: any;

  constructor(
    private eventService: EventService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
    })
    if (this.eventID) {
      this.getEventUsers();
      this.getEventRun();
    }
  }
  
  getEventRun(){
    this.eventService.getEventRun(this.eventID,this.categoryID).subscribe((res) => {
      res = _.orderBy(res, ['sortOrder'], ['asc']);
      for (var sec in res) {
        for (var tm in res[sec].teams) {
          res[sec].teams[tm].toggleOn = false;
        }
      }
      this.sections = res;
      console.log(res);
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  getEventUsers() {
    if (this.eventID && this.categoryID) {
      this.eventService.getEventJudges(this.eventID, this.categoryID).subscribe((res) => {
        res = _.filter(res, (user) => { return user.rolename === 'Judge'; });
        res = _.orderBy(res, [user => user.lastName.toLowerCase()], ['asc']);
        this.listCategoryJudges = res;
        //console.log(this.listCategoryJudges);
      })
    }
  }

  gotoJudgeView() {
    setTimeout(() => {
      this.router.navigate(['/events', this.eventID, 'judge', this.judgeUserId]);
    })
  }
}
