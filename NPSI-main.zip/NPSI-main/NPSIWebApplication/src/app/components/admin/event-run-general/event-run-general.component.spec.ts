import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventRunGeneralComponent } from './event-run-general.component';

describe('EventRunGeneralComponent', () => {
  let component: EventRunGeneralComponent;
  let fixture: ComponentFixture<EventRunGeneralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventRunGeneralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventRunGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
