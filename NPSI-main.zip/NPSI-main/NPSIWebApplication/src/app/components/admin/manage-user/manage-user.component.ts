import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { UserService } from '../../../service/user.service';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import Swal from 'sweetalert2';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.css']
})
export class ManageUserComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  @ViewChild('resetPasswordModal') resetPasswordModal: ModalDirective;
  @ViewChild('formAddEditUser') formAddEditUser: NgForm;
  @ViewChild('formResetPassword') formResetPassword: NgForm;
  mask = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  phonePattern = /^\d{3}-\d{3}-\d{4}$/;
  emailPattern = "[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?";
  passwordPartern = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@$!%*?&])([a-zA-Z0-9@$!%*?&]{8,32})$"
  intergerPartern = /(?=.*[0-9])/;
  uppperCasePartern = /(?=.*[A-Z])/;
  lowerCasePartern = /(?=.*[a-z])/;
  specialCharacterPartern = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  objectSearch: any = {
    isSuperAdmin: null,
    active: null,
    returnTotalCount: true,
    sortedBy: "UserName asc",
  }
  objectResetPassword: any = {};
  count: any;
  users: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  bkObjectFilter: any;
  sortBy: string = 'UserName';
  sortDescending: boolean = false;
  objectUser: any = {};
  isLoading: any = false;
  isTrue: any = true;
  imageSrc: any;
  invalidPassword: any = false;
  constructor(private userService: UserService,
    private sanitizer: DomSanitizer,
    private router: Router) { }

  ngOnInit(): void {
    this.bkObjectFilter = JSON.parse(JSON.stringify(this.objectSearch));
    this.getUser(this.objectSearch);
  }
  formatPhoneNumber(phoneNumberString) {
    var pattern = /^\d{3}-\d{3}-\d{4}$/;
    if (pattern.test(phoneNumberString)) {
      return phoneNumberString;
    } else {
      if (phoneNumberString.length > 10) {
        phoneNumberString = phoneNumberString.slice(0, 10);
      }
      let match = phoneNumberString.replace(/\D/g, '').replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
      return match;
    }
  }
  add() {
    this.imageSrc = null;
    this.isTrue = true;
    this.invalidPassword = false;
    this.objectUser = {};
    this.showChildModal();
  }
  edit(user) {
    this.invalidPassword = false;
    this.objectUser = JSON.parse(JSON.stringify(user));
    this.objectUser.phoneNumber = this.objectUser.phoneNumber ? this.formatPhoneNumber(this.objectUser.phoneNumber) : ''
    this.imageSrc = this.transform('data:image/jpg;base64,' + this.objectUser.photo)
    this.showChildModal();
  }
  transform(base64Image) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(base64Image);
  }
  showChildModal(): void {
    this.lgModal.show();
  }
  hideChildModal(): void {
    this.lgModal.hide();
  }
  showResetPasswordPopup(): void {
    this.resetPasswordModal.show();
  }
  hideResetPasswordPopup(): void {
    this.resetPasswordModal.hide();
  }
  openPopupResetPassword(u) {
    this.isTrue = true;
    this.invalidPassword = false;
    this.formResetPassword.reset();
    setTimeout(() => {
      this.objectResetPassword = JSON.parse(JSON.stringify(u));
    })

    this.showResetPasswordPopup();
  }
  cancelPopupResetPassword() {
    this.isTrue = true;
    this.invalidPassword = false;
    this.objectResetPassword = {};
    this.formResetPassword.reset();
    this.hideResetPasswordPopup();
  }
  getUser(object) {
    var obj = JSON.parse(JSON.stringify(object));
    this.userService.searchUser(obj).subscribe((res: any) => {
      if (res.count) {
        this.count = res.count
      }
      this.users = res.data;
      console.log(this.users);
    }, (err) => {
      console.log(err);
    })
  }
  pageChanged(event: PageChangedEvent): void {
    this.bkObjectFilter.itemsPerPage = event.itemsPerPage;
    this.bkObjectFilter.pageNumber = this.currentPage = event.page;
    this.bkObjectFilter.returnTotalCount = false;
    this.getUser(this.bkObjectFilter);
  }
  firstSearchSettings() {
    this.sortBy = 'UserName';
    this.sortDescending = false;
    this.currentPage = 1;
    this.bkObjectFilter = JSON.parse(JSON.stringify(this.objectSearch));
    console.log(this.bkObjectFilter);
    this.getUser(this.bkObjectFilter);
  }
  reset() {
    this.objectSearch = {
      isSuperAdmin: null,
      active: null,
      returnTotalCount: true,
      sortedBy: "UserName asc",
    };
    this.firstSearchSettings();
  }
  search() {
    this.firstSearchSettings();
  }
  sort(sortBy) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    this.sortBy = sortBy;
    let orderBy = this.sortDescending ? "descending" : "asc"
    this.bkObjectFilter.SortedBy = sortBy + " " + orderBy;
    this.getUser(this.bkObjectFilter);
  }
  cancel() {
    this.imageSrc = null;
    this.isTrue = true;
    this.invalidPassword = false;
    this.formAddEditUser.reset();
    this.hideChildModal();
  }
  save() {
    this.isLoading = true;
    if (this.objectUser.id) {
      var object = JSON.parse(JSON.stringify(this.objectUser));
      object.phoneNumber = object.phoneNumber ? object.phoneNumber.replace(/-/g, '') : '';
      this.userService.editUser(object).subscribe((res) => {
        this.getUser(this.bkObjectFilter);
        this.isLoading = false;
        this.cancel();
      }, (err) => {
        this.isLoading = false;
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: err.error = 'Email Existed.' ? 'Email Existed.' : 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    } else {
      if (this.objectUser.password != this.objectUser.confirmPassword) {
        this.isTrue = false;
        this.isLoading = false;
        return;
      }
      this.createUser().then((res) => {
        this.isLoading = false;
        this.getUser(this.bkObjectFilter);
        this.cancel();
      }, (err) => {
        this.isLoading = false;
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: err.error == 'Username or Email Existed.' ? 'Username or Email Existed.' : 'An unknown server error occurred.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      });
    }
  }
  saveAddAnother() {
    this.isLoading = true;
    if (this.objectUser.password != this.objectUser.confirmPassword) {
      this.isTrue = false;
      this.isLoading = false;
      return;
    }
    this.createUser().then((res) => {
      this.isLoading = false;
      this.getUser(this.bkObjectFilter);
    }, (err) => {
      this.isLoading = false;
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: err.error == 'Username or Email Existed.' ? 'Username or Email Existed.' : 'An unknown server error occurred.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    })
  }
  createUser() {
    let promise = new Promise<void>((resolve, reject) => {
      this.isLoading = true;
      var object = JSON.parse(JSON.stringify(this.objectUser));
      object.phoneNumber = object.phoneNumber ? object.phoneNumber.replace(/-/g, '') : '';
      console.log('object :', object);
      this.handleBeforeAddEditUser(object);
      this.userService.createUser(object).subscribe((res) => {
        this.formAddEditUser.reset();
        this.isLoading = false;
        resolve();
      }, (err) => {
        this.isLoading = false;
        reject(err);
      })
    })
    return promise;
  }
  handleBeforeAddEditUser(object) {
    object.active = object.active != null ? object.active : false;
    object.isSuperAdmin = object.isSuperAdmin != null ? object.isSuperAdmin : false;
  }
  unlockUser(id) {
    this.userService.unlockUser(id).subscribe((res) => {
      this.getUser(this.bkObjectFilter);
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Unlock user successfully.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: 'An unknown server error occurred.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    })
  }
  saveReset() {
    this.isLoading = true;
    if (this.objectResetPassword.password != this.objectResetPassword.confirmPassword) {
      this.isTrue = false;
      this.isLoading = false;
      return;
    }
    var object = {
      userID: this.objectResetPassword.id,
      username: this.objectResetPassword.username,
      password: this.objectResetPassword.password,
      token: localStorage.getItem('authorizationToken'),
    }
    this.userService.resetPassword(object).subscribe((res) => {
      this.isLoading = false;
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Reset Password Successfully.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
      this.cancelPopupResetPassword()
    }, (err) => {
      this.isLoading = false;
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: 'An unknown server error occurred.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    })
  }
  onSelectFile(event) {
    var files = event.target.files;
    var file = files[0];
    if (files && file) {

      var mimeType = file.type;
      if (mimeType.match(/image\/*/) == null) {
        Swal.fire({
          position: 'top-end',
          icon: 'warning',
          title: 'Only images are supported.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
        return;
      }
      if (mimeType.indexOf('png') == -1 && mimeType.indexOf('jpeg') == -1) {
        Swal.fire({
          position: 'top-end',
          icon: 'warning',
          title: 'Only PNG and JPG are supported.',
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
        return;
      }
      var reader = new FileReader();

      reader.onload = this._handleReaderLoaded.bind(this);

      reader.readAsBinaryString(file);

    }
  }
  _handleReaderLoaded(readerEvt) {
    var binaryString = readerEvt.target.result;
    this.objectUser.photo = btoa(binaryString);
    this.imageSrc = this.transform('data:image/jpg;base64,' + this.objectUser.photo);
  }
  regexPassword(password) {
    //check password is valid
    this.invalidPassword = false;
    var i = 0;
    if (this.intergerPartern.test(password)) {
      i = i + 1;
    }
    if (this.lowerCasePartern.test(password)) {
      i = i + 1;
    }
    if (this.uppperCasePartern.test(password)) {
      i = i + 1;
    }
    if (this.specialCharacterPartern.test(password)) {
      i = i + 1;
    }
    if (i >= 3) {
      this.invalidPassword = false;
    } else {
      this.invalidPassword = true;
    }
  }
  gotoJudgeHistory(judgeId) {
    setTimeout(() => {
      this.router.navigate(['/admin/judgehistory/', judgeId]);
    })
  }
}
