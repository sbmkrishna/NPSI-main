import { Component, OnInit, ViewChild } from '@angular/core';
import { PenaltyService } from '../../../service/penalty.service';
import { NgForm } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import * as _ from 'lodash';
import { NotificationService } from 'src/app/service/notification.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-penalty',
  templateUrl: './penalty.component.html',
  styleUrls: ['./penalty.component.css']
})
export class PenaltyComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  @ViewChild('formAddEditPenalty') formAddEditPenalty: NgForm;
  penalties: any;
  objectPenalty: any = {};
  isLoading: any = false;
  isDeleting: any = false;
  keyword: any;
  //pagination
  startItemPenalty: any;
  endItemPenalty: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  returnArray: any = [];
  //sort
  sortBy: any = 'name';
  sortDescending: any = false;
  filterActive: any = true;
  constructor(private penaltyService: PenaltyService) { }

  ngOnInit(): void {
    this.getPenalties();
  }

  firstFilterActive() {
    this.penalties.forEach((item) => {
      if (item.active == this.filterActive) {
        this.returnArray.push(item);
      }
    });
  }
  getPenalties() {
    let promise = new Promise<void>((resovle, reject) => {
      this.returnArray = [];
      this.penaltyService.getPenalty().subscribe((res) => {
        this.penalties = res;
        this.firstFilterActive();
        this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
        this.firstSearchSettings();
        resovle();
      }, (err) => {
        reject();
      })
    })
    return promise;
  }
  sort(sortBy) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    this.sortBy = sortBy;
    let orderBy = this.sortDescending ? "desc" : "asc";
    this.returnArray = _.orderBy(this.returnArray, [task => task[sortBy] && typeof task[sortBy] === 'string' ? task[sortBy].toLowerCase() : task[sortBy]], [orderBy]);
  }
  firstSearchSettings() {
    this.sortBy = 'name';
    this.sortDescending = false;
    this.currentPage = 1;
    this.startItemPenalty = 0;
    this.endItemPenalty = 10;
  }
  add() {
    this.objectPenalty = {};
    this.showChildModal();
  }
  showChildModal(): void {
    this.lgModal.show();
  }
  hideChildModal(): void {
    this.formAddEditPenalty.reset();
    this.lgModal.hide();
  }
  edit(pen) {
    var object = JSON.parse(JSON.stringify(pen));
    this.objectPenalty = object;
    this.showChildModal();
  }
  save() {
    var bkStart = this.startItemPenalty;
    var bkEnd = this.endItemPenalty;
    var bkPage = this.currentPage;
    this.isLoading = true;
    if (this.objectPenalty.id) {
      this.penaltyService.editPenalty(this.objectPenalty).subscribe((res) => {
        this.getPenalties().then((res) => {
          this.startItemPenalty = bkStart;
          this.endItemPenalty = bkEnd;
          this.currentPage = bkPage;
          this.hideChildModal();
          this.isLoading = false;
        });

      }, (err) => {
        this.isLoading = false;
      })
    } else {
      this.createPenalty().then((res) => {
        this.startItemPenalty = bkStart;
        this.endItemPenalty = bkEnd;
        this.currentPage = bkPage;
        this.hideChildModal();
        this.isLoading = false;
      }, (err) => {
        this.isLoading = false;
      })
    }
  }
  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.startItemPenalty = (event.page - 1) * event.itemsPerPage;
    this.endItemPenalty = event.page * event.itemsPerPage;
  }
  search() {
    setTimeout(() => {
      this.returnArray = [];
      if (this.filterActive) {
        if (this.keyword) {
          this.penalties.forEach((item) => {
            if (((item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1) || (item.deduction && item.deduction.toString().toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1)) && item.active == this.filterActive) {
              this.returnArray.push(item);
            }
          })
        } else {
          this.firstFilterActive();
        }
      } else {
        if (this.keyword) {
          this.penalties.forEach((item) => {
            if (((item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1) || (item.deduction && item.deduction.toString().toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
              this.returnArray.push(item);
            }
          })
        } else {
          this.returnArray = JSON.parse(JSON.stringify(this.penalties))
        }
      }
      this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
      this.firstSearchSettings();
    });
  }
  saveAddAnother() {
    var bkStart = this.startItemPenalty;
    var bkEnd = this.endItemPenalty;
    var bkPage = this.currentPage;
    this.createPenalty().then((res) => {
      this.startItemPenalty = bkStart;
      this.endItemPenalty = bkEnd;
      this.currentPage = bkPage;
      this.isLoading = false;
      this.formAddEditPenalty.reset();
    }, (err) => {
      this.isLoading = false;
    })
  }
  createPenalty() {
    let promise = new Promise<void>((resolve, reject) => {
      this.penaltyService.createPenalty(this.objectPenalty).subscribe((res) => {
        this.getPenalties().then((res) => {
          resolve();
        });
      }, (err) => {
        reject(err);
      })
    })
    return promise;
  }

  delete(penaltyID) {
    this.isDeleting = true;
    NotificationService.confirm('Are you sure you want to delete this penalty?').then((res) => {
      if (res.value) {
        this.penaltyService.deletePenalty(penaltyID).subscribe((res) => {
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Delete Penalty Successfully.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.getPenalties().then((results: any) => {
            this.isDeleting = false;
          }, (err) => {
            NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
          })
        }, (err) => {
          this.isDeleting = false;
          NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
        })
      }
    })
  }
}
