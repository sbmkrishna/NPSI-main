import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css']
})
export class TabsComponent implements OnInit {
  @Input("active") active: any;
  @Input("eventID") eventID:any;
  constructor(private router: Router) { }
  user: any;
  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));
  }
  goToSections() {
    setTimeout(() => {
      this.router.navigate(['/admin/sections']);
    })
  }
  goToSubsections() {
    setTimeout(() => {
      this.router.navigate(['/admin/subsections']);
    })
  }
  goToPenalties() {
    setTimeout(() => {
      this.router.navigate(['/admin/penalties']);
    })
  }
  goToDisqualifications() {
    setTimeout(() => {
      this.router.navigate(['/admin/disqualifications']);
    })
  }
  goToTeams() {
    setTimeout(() => {
      if (this.user && this.user.isSuperAdmin) {
        this.router.navigate(['/admin/teams']);
      }
      else if (this.user && this.user.roles && this.user.roles.indexOf("Event - Admin") != -1) {
        this.router.navigate(['/event-admin-dashboard/teams']);
      }

    })
  }
  goToEvents() {
    setTimeout(() => {
      if (this.user && this.user.isSuperAdmin) {
        this.router.navigate(['/admin/events']);
      }
      else if (this.user && this.user.roles && this.user.roles.indexOf("Event - Admin") != -1) {
        this.router.navigate(['/event-admin-dashboard/events']);
      }

    })
  }
  goToUsers() {
    setTimeout(() => {
      if (this.user && this.user.isSuperAdmin) {
        this.router.navigate(['/admin/users']);
      }
      else if (this.user && this.user.roles && this.user.roles.indexOf("Event - Admin") != -1) {
        this.router.navigate(['/event-admin-dashboard/users']);
      }
    })
  }
  goToReports() {
    setTimeout(() => {
      if(this.eventID){
        this.router.navigate(['/admin/report'], { queryParams: { eventID: this.eventID } },);
      }else{
        this.router.navigate(['/admin/report']);
      }
    })
  }

}
