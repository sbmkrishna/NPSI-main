import { Component, OnInit, Input } from '@angular/core';
import { SectionService } from '../../../service/section.service';
import { EventService } from '../../../service/event.service';
import { ActivatedRoute } from '@angular/router';
import { TeamService } from '../../../service/team.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-event-category-management',
  templateUrl: './event-category-management.component.html',
  styleUrls: ['./event-category-management.component.css']
})
export class EventCategoryManagementComponent implements OnInit {
  @Input("categoryID") categoryID;
  @Input("statusName") statusName;
  @Input("startDate") startDate;
  @Input("endDate") endDate;
  selectedSections: any;
  selectedUsers: any;
  selectedTeams: any;
  listJudges: any;
  listSection: any;
  listTeam: any;
  eventID: any;
  constructor(private sectionService: SectionService,
    private eventService: EventService,
    private activatedRoute: ActivatedRoute,
    private teamService: TeamService
  ) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
    })
    if (this.categoryID) {
      this.getSection(this.categoryID);
      this.getTeam(this.categoryID);
    }
    if (this.eventID && this.categoryID) {
      this.getEventSection(this.eventID, this.categoryID);
      this.getEventUser(this.eventID, this.categoryID);
      this.getEventTeam(this.eventID, this.categoryID);
    }
  }
  getSection(id) {
    this.sectionService.getSectionByCategory(id).subscribe((res) => {
      res = _.orderBy(res, ['sortOrder'], ['asc']);
      this.listSection = res;
    })
  }
  getTeam(id) {
    this.teamService.getTeamsByCategory(id).subscribe((res) => {
      this.listTeam = res;
    })

  }
  getEventSection(id, categoryId) {
    this.eventService.getEventSection(id, categoryId).subscribe((res) => {
      res = _.orderBy(res, ['sortOrder'], ['asc']);
      this.selectedSections = res;
    })
  }
  getEventUser(id, categoryId) {
    this.eventService.getEventUser(id, categoryId).subscribe((res) => {
      res = _.orderBy(res, [user => user.lastName.toLowerCase()], ['asc']);
      this.selectedUsers = res;
    })
  }
  getEventTeam(id, categoryId) {
    this.eventService.getEventTeam(id, categoryId).subscribe((res) => {
      this.selectedTeams = res;
    })
  }
  addDeleteSectionsSuccess() {
    this.getEventSection(this.eventID, this.categoryID);
  }
  addDeleteTeamSuccess() {
    this.getEventTeam(this.eventID, this.categoryID);
  }
  addDeleteUserSuccess() {
    this.getEventSection(this.eventID, this.categoryID);
    this.getEventUser(this.eventID, this.categoryID);
  }
  cancelEditEventSection(value) {
    for (let i = 0; i < this.selectedSections.length; i++) {
      if (this.selectedSections[i].id == value.id) {
        this.selectedSections[i] = value;
      }
    }
  }
  cancelEditEventTeam(value) {
    for (let i = 0; i < this.selectedTeams.length; i++) {
      if (this.selectedTeams[i].teamID == value.teamID) {
        this.selectedTeams[i] = value;
      }
    }
  }
  editTeamMembersSuccess() {
    this.getEventTeam(this.eventID, this.categoryID);
  }
}
