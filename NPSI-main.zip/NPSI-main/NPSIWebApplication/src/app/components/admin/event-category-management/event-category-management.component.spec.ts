import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventCategoryManagementComponent } from './event-category-management.component';

describe('EventCategoryManagementComponent', () => {
  let component: EventCategoryManagementComponent;
  let fixture: ComponentFixture<EventCategoryManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventCategoryManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventCategoryManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
