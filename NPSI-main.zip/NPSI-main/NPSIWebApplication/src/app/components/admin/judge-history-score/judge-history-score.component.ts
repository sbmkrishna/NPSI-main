import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../../../service/user.service';
import { Router } from '@angular/router';
import * as LD from 'lodash';
import { NotificationService } from 'src/app/service/notification.service';

@Component({
  selector: 'app-judge-history-score',
  templateUrl: './judge-history-score.component.html',
  styleUrls: ['./judge-history-score.component.css']
})
export class JudgeHistoryScoreComponent implements OnInit {

  judgeID: any;
  eventID: any;
  sectionID: any;
  user: any;
  scores: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
  ) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));
    this.activatedRoute.params.subscribe(params => {
      this.judgeID = params.judgeID;
      this.eventID = params.eventID;
      this.sectionID = (params.sectionID == "null" ? null : params.sectionID);
    })
    if (this.judgeID) {
      this.getJudgeScores();
    }
  }

  getJudgeScores() {
    const model: any = { JudgeUserID: this.judgeID, EventID: this.eventID, SectionID: this.sectionID };
   this.userService.searchScoreHistory(model).subscribe((res: any) => {
      if (res) {
        this.scores = LD.orderBy(res, ['eventID','sectionID','teamID'], ['asc','asc','asc']);
      }
    }, (err) => {
     NotificationService.error('An unknown server error occurred.');
    })
  }

}
