import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JudgeHistoryScoreComponent } from './judge-history-score.component';

describe('JudgeHistoryScoreComponent', () => {
  let component: JudgeHistoryScoreComponent;
  let fixture: ComponentFixture<JudgeHistoryScoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JudgeHistoryScoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JudgeHistoryScoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
