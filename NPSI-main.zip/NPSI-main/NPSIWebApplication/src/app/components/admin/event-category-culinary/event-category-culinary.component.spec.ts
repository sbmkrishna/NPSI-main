import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventCategoryCulinaryComponent } from './event-category-culinary.component';

describe('EventCategoryCulinaryComponent', () => {
  let component: EventCategoryCulinaryComponent;
  let fixture: ComponentFixture<EventCategoryCulinaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventCategoryCulinaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventCategoryCulinaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
