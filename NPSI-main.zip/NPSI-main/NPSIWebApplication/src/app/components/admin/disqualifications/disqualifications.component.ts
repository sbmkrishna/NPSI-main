import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { DisqualificationService } from '../../../service/disqualification.service';
import * as _ from 'lodash';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import { NotificationService } from 'src/app/service/notification.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-disqualifications',
  templateUrl: './disqualifications.component.html',
  styleUrls: ['./disqualifications.component.css']
})
export class DisqualificationsComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  @ViewChild('formAddEditDisqualification') formAddEditDisqualification: NgForm;
  disqualifications: any;
  objectDisqualification: any = {};
  isLoading: any = false;
  keyword: any;
  //pagination
  startItemDisqualification: any;
  endItemDisqualification: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  returnArray: any = [];
  //sort
  sortBy: any = 'name';
  sortDescending: any = false;
  filterActive: any = true;
  isDeleting: any = false;
  constructor(private disqualificationService: DisqualificationService) { }

  ngOnInit(): void {
    this.getDisqualification();
  }
  filterByActive() {
    this.disqualifications.forEach((item) => {
      if (item.active == this.filterActive) {
        this.returnArray.push(item);
      }
    });
  }
  getDisqualification() {
    let promise = new Promise<void>((resovle, reject) => {
      this.returnArray = [];
      this.disqualificationService.getDisqualification().subscribe((res) => {
        this.disqualifications = res;
        this.filterByActive();
        this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
        this.searchSettings();
        resovle();
      }, (err) => {
        reject();
      })
    })
    return promise;
  }
  searchSettings() {
    this.sortBy = 'name';
    this.sortDescending = false;
    this.currentPage = 1;
    this.startItemDisqualification = 0;
    this.endItemDisqualification = 10;
  }
  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.startItemDisqualification = (event.page - 1) * event.itemsPerPage;
    this.endItemDisqualification = event.page * event.itemsPerPage;
  }
 
  searchByKeyword() {
    setTimeout(() => {
      this.returnArray = [];
      if (this.filterActive) {
        if (this.keyword) {
          this.disqualifications.forEach((item) => {
            if ((item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1) && item.active == this.filterActive) {
              this.returnArray.push(item);
            }
          })
        } else {
          this.filterByActive();
        }
      } else {
        if (this.keyword) {
          this.disqualifications.forEach((item) => {
            if (item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1) {
              this.returnArray.push(item);
            }
          })
        } else {
          this.returnArray = JSON.parse(JSON.stringify(this.disqualifications));
        }
      }
      this.returnArray = _.orderBy(this.returnArray, [task => task['name'].toLowerCase()], ['asc']);
      this.searchSettings();
    })

  }
  add() {
    this.objectDisqualification = {};
    this.lgModal.show();
  }
  hideChildModal(): void {
    this.formAddEditDisqualification.reset();
    this.lgModal.hide();
  }
  edit(d) {
    var object = JSON.parse(JSON.stringify(d));
    this.objectDisqualification = object;
    this.lgModal.show();
  }
  save() {
    var bkStart = this.startItemDisqualification;
    var bkEnd = this.endItemDisqualification;
    var bkPage = this.currentPage;
    this.isLoading = true;
    if (this.objectDisqualification.id) {
      this.disqualificationService.editDisqualification(this.objectDisqualification).subscribe((res) => {
        this.getDisqualification().then((res) => {
          this.startItemDisqualification = bkStart;
          this.endItemDisqualification = bkEnd;
          this.currentPage = bkPage;
          this.hideChildModal();
          this.isLoading = false;
        });

      }, (err) => {
        this.isLoading = false;
        NotificationService.error('An unknown server error occurred.');
      })
    } else {
      this.createDisqualification().then((res) => {
        this.startItemDisqualification = bkStart;
        this.endItemDisqualification = bkEnd;
        this.currentPage = bkPage;
        this.hideChildModal();
        this.isLoading = false;
      }, (err) => {
        this.isLoading = false;
        NotificationService.error('An unknown server error occurred.');
      })
    }
  }

  saveAddAnother() {
    var bkStart = this.startItemDisqualification;
    var bkEnd = this.endItemDisqualification;
    var bkPage = this.currentPage;
    this.createDisqualification().then((res) => {
      this.startItemDisqualification = bkStart;
      this.endItemDisqualification = bkEnd;
      this.currentPage = bkPage;
      this.isLoading = false;
      this.formAddEditDisqualification.reset();
    }, (err) => {
      this.isLoading = false;
    })
  }
  createDisqualification() {
    let promise = new Promise<void>((resolve, reject) => {
      this.disqualificationService.createDisqualification(this.objectDisqualification).subscribe((res) => {
        this.getDisqualification().then((res) => {
          resolve();
        });
      }, (err) => {
        reject(err);
      })
    })
    return promise;
  }
  sort(sortBy) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    this.sortBy = sortBy;
    let orderBy = this.sortDescending ? "desc" : "asc";
    this.returnArray = _.orderBy(this.returnArray, [task => task[sortBy] && typeof task[sortBy] === 'string' ? task[sortBy].toLowerCase() : task[sortBy]], [orderBy]);
  }
  delete(disqualificationID){
    this.isDeleting = true;
    NotificationService.confirm('Are you sure you want to delete this disqualification?').then((res) => {
      if (res.value) {
        this.disqualificationService.deleteDisqualification(disqualificationID).subscribe((res) => {
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Delete Disqualification Successfully.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.getDisqualification().then((results: any) => {
            this.isDeleting = false;
          }, (err) => {
            NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
          })
        }, (err) => {
          this.isDeleting = false;
          NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
        })
      }
    })
  }
}
