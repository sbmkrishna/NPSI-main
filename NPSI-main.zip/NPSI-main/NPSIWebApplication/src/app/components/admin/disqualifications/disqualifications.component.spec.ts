import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisqualificationsComponent } from './disqualifications.component';

describe('DisqualificationsComponent', () => {
  let component: DisqualificationsComponent;
  let fixture: ComponentFixture<DisqualificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisqualificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisqualificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
