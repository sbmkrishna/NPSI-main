import { Component, OnInit, ViewChild } from '@angular/core';
import { TeamService } from '../../../service/team.service';
import { CategoryService } from '../../../service/category.service';
import { PageChangedEvent } from 'ngx-bootstrap/pagination/public_api';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { NotificationService } from '../../../service/notification.service';
import { NgForm } from '@angular/forms';
import Swal from 'sweetalert2';
import * as _ from 'lodash';
import { invalid } from '@angular/compiler/src/render3/view/util';
@Component({
  selector: 'app-manage-team',
  templateUrl: './manage-team.component.html',
  styleUrls: ['./manage-team.component.css']
})
export class ManageTeamComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;


  objectSearch: any = {
    categoryID: null,
    returnTotalCount: true,
    sortedBy: "SchoolName asc",
    active: true,
  }
  count: any;
  teams: any;
  itemsPerPage: any = 10;
  currentPage: any = 1;
  bkObjectFilter: any;
  sortBy: string = 'SchoolName';
  sortDescending: boolean = false;
  categories: any = [];
  objectTeam: any = {
    categoryID: null
  };
  isLoading: any = false;
  members: any = [];
  isDeleting: any = false;
  isActive: boolean = true;
  isDeactive: boolean = false;
  constructor(private teamService: TeamService,
    private categoryService: CategoryService
  ) { }

  ngOnInit(): void {
    this.bkObjectFilter = JSON.parse(JSON.stringify(this.objectSearch));
    this.getTeam(this.objectSearch);
    this.getCategory();

  }
  getCategory() {
    this.categoryService.getCategory().subscribe((res) => {
      this.categories = res;
    })
  }
  getTeam(object) {
    return new Promise<void>((resolve) => {
      var obj = JSON.parse(JSON.stringify(object));
      this.teamService.searchTeam(obj).subscribe((res: any) => {
        if (res.count) {
          this.count = res.count
        }
        this.teams = res.data;
        resolve();
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
      })
    })
  }
  pageChanged(event: PageChangedEvent): void {
    this.bkObjectFilter.itemsPerPage = event.itemsPerPage;
    this.bkObjectFilter.pageNumber = this.currentPage = event.page;
    this.bkObjectFilter.returnTotalCount = false;
    this.getTeam(this.bkObjectFilter);
  }
  settingSearch() {
    this.sortBy = 'SchoolName';
    this.sortDescending = false;
    this.currentPage = 1;
    this.bkObjectFilter = JSON.parse(JSON.stringify(this.objectSearch));
    this.getTeam(this.bkObjectFilter);
  }
  reset() {
    this.objectSearch = {
      categoryID: null,
      returnTotalCount: true,
      sortedBy: "SchoolName asc",
      active: null,
    };
    this.settingSearch();
  }
  search() {
    this.settingSearch();
  }

  sort(sortBy) {
    if (this.sortBy != sortBy) {
      this.sortDescending = false;
    } else {
      this.sortDescending = !this.sortDescending
    }
    this.sortBy = sortBy;
    let orderBy = this.sortDescending ? "descending" : "asc"
    this.bkObjectFilter.SortedBy = sortBy + " " + orderBy;
    this.getTeam(this.bkObjectFilter);
  }
  add() {
    this.objectTeam = { categoryID: 1 };
    this.members = [];
    this.lgModal.show();
  }
  edit(m) {
    this.objectTeam = JSON.parse(JSON.stringify(m));
    this.members = JSON.parse(JSON.stringify(m.members));
    this.lgModal.show();
  }

  delete(teamID) {
    this.isDeleting = true;
    NotificationService.confirm('Are you sure you want to delete this disqualification?').then((res) => {
      if (res.value) {
        this.teamService.deleteTeam(teamID).subscribe((res) => {
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Delete Team Successfully.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.getTeam(this.objectSearch).then((results: any) => {
            this.isDeleting = false;
          }, (err) => {
            NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
          })
        }, (err) => {
          this.isDeleting = false;
          NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
        })
      }
    })
  }

  onSaveAddEditSuccess(value) {
    if (!value) {
      this.lgModal.hide();
    }
    this.getTeam(this.bkObjectFilter);
  }

  onCancelAddEditSuccess() {
    this.lgModal.hide();
    let active = _.find(this.teams, { 'active': true });
    let deactive = _.find(this.teams, { 'active': false });
    if (!active || !deactive) {
      if (!active && deactive && deactive.length > 0) {
        this.isActive = true;
      }
      if (!deactive && active && active.length > 0) {
        this.isDeactive = true;
      }
    }
  }

  activateDeactiveAllTeams(status) {
    //type = true active
    //type = false deactive
    this.teamService.getAllTeamByActive(status).subscribe((resutls: any) => {
      let contentNotify = status == 0 ? `You are about to deactivate ${resutls.length} teams, are you sure?` : `You are about to activate all the teams, are you sure?`;
      NotificationService.confirm(contentNotify).then((res) => {
        if (res.value) {
          let typeobject = { type: status, ids: resutls };

          this.teamService.activateDeactiveAllTeams(typeobject).subscribe(result => {
            Swal.fire({
              position: 'top-end',
              icon: 'success',
              title: 'Update All Team Successfully.',
              showConfirmButton: false,
              timer: 3000,
              toast: true
            });
            this.getTeam(this.objectSearch).then((r: any) => {
              this.isDeleting = false;
            }, (err) => {
              NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
            })
          }, (err) => {
            this.isDeleting = false;
            NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
          })
        }
      })
    })


  }
}
