import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JudgeHistoryComponent } from './judge-history.component';

describe('JudgeHistoryComponent', () => {
  let component: JudgeHistoryComponent;
  let fixture: ComponentFixture<JudgeHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JudgeHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JudgeHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
