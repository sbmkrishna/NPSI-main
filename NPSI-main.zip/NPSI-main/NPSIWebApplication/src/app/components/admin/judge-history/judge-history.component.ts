import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../../../service/user.service';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/service/notification.service';

@Component({
  selector: 'app-judge-history',
  templateUrl: './judge-history.component.html',
  styleUrls: ['./judge-history.component.css']
})
export class JudgeHistoryComponent implements OnInit {

  judge: any;
  judgeID: any;
  user: any;
  history: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));
    this.activatedRoute.params.subscribe(params => {
      this.judgeID = params.judgeID;
    })
    if (this.judgeID) {
      this.getJudgeDetail();
      this.getJudgeHistory();
    }
  }

  getJudgeDetail() {
    const model: any = { UserId: this.judgeID };
    this.userService.searchUser(model).subscribe((res: any) => {
      if (res.data) {
        this.judge = res.data[0];
      }
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  getJudgeHistory() {
    this.userService.getJudgeHistory(this.judgeID).subscribe((res: any) => {
      if (res) {
        this.history = res;
      }
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  gotoJudgeScore(eventId, sectionId) {
    setTimeout(() => {
      this.router.navigate([`/admin/judgescore/${this.judgeID}/event/${eventId}/section/${sectionId}`]);
    })
  }
}
