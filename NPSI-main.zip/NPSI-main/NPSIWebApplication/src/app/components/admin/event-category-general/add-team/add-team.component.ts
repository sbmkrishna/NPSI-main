import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { EventService } from 'src/app/service/event.service';
import { NotificationService } from 'src/app/service/notification.service';

@Component({
  selector: 'app-add-team',
  templateUrl: './add-team.component.html',
  styleUrls: ['./add-team.component.css']
})
export class AddTeamComponent implements OnInit {
  @Input("startDate") startDate;
  @Input("endDate") endDate;
  @Input("returnArray") returnArray; 
  @Input("eventID") eventID;
  @Output("addEventTeamSuccess") addEventTeamSuccess = new EventEmitter();
  @Output("cancelAddEventTeam") cancelAddEventTeam=new EventEmitter();
  minDate: Date;
  maxDate: Date;
  checkDateAndTime: any = false;
  isLoading: any = false;
  teamList: any = [];
  keyword: any;
  bkTeamList: any = [];

  constructor(
    private eventService: EventService,
  ) { }

  ngOnInit(): void {
    this.minDate = new Date(this.startDate);
    this.maxDate = new Date(this.endDate);
  }

  ngOnChanges() {
    if (this.returnArray) {
      this.teamList = this.returnArray;
      this.bkTeamList = JSON.parse(JSON.stringify(this.returnArray));
      console.log(' this.teamList :', this.teamList);
    }
  }
  search() {
    let teamArr = [];
    this.teamList = this.bkTeamList;
    this.bkTeamList = JSON.parse(JSON.stringify(this.teamList));
    this.teamList.forEach((item) => {
      if (((item && item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1)
        || (item && item.schoolName && item.schoolName.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
        teamArr.push(item);
      }
    })
    this.teamList = teamArr;
  }

  checkDateTime() {
    setTimeout(() => {
      if (this.teamList) {
        let copyReturnArray = JSON.parse(JSON.stringify(this.teamList));
        for (let i = 0; i < copyReturnArray.length; i++) {
          let select = copyReturnArray[i];
          if (select.checked) {
            let isFormat = this.doCheckDatetime(select.startTime, select.endTime, select.date);
            this.checkDateAndTime = isFormat;
            if (!isFormat) {
              return;
            }
          }
        }
      }
    })
  }

  // a and b are javascript Date objects
  dateDiffInDays(a, b) {
    // Discard the time and time-zone information.
    let utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    let utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.floor((utc2 - utc1) / (1000 * 60 * 60 * 24));
  }


  doCheckDatetime(startTime, endTime, date) {
    let start = new Date(startTime);
    let end = new Date(endTime);
    let startDate = this.minDate;
    startDate.setHours(0, 0, 0, 0);
    let endDate = this.maxDate;
    endDate.setHours(0, 0, 0, 0);
    let isSooner = this.dateDiffInDays(new Date(date), new Date(startDate));
    let isLater = this.dateDiffInDays(new Date(date), new Date(endDate));
    if (isLater < 0) {
      NotificationService.error("The section date cannot be later than the Event End Date.");
      return false;
    }
    if (isSooner > 0) {
      NotificationService.error("The section date cannot be sooner than the Event Start Date.");
      return false;
    }
    if (!date || !startTime || !endTime || start.getHours() > end.getHours() || (start.getHours() == end.getHours() && start.getMinutes() >= end.getMinutes())) {
      return false;
    } else {
      return true;
    }
  }

  checkValueDatetime(itemSection) {
    setTimeout(() => {
      itemSection.isDisabledSave = this.doCheckDatetime(itemSection.startTime, itemSection.endTime, itemSection.date)
    })
  }
  changeChecked(checked, item) {
    item.checked = checked;
  }
  addEventTeam() {
    this.isLoading =true;
    let listSelected = [];
    for (let i = 0; i < this.teamList.length; i++) {
      let itemSelected = this.teamList[i];
        if (itemSelected.checked) {
          listSelected.push(itemSelected);
        }
      }
    let arrTemp = JSON.parse(JSON.stringify(listSelected));

    arrTemp.forEach((item) => {
      item.teamID = item.id;
      item.startTime = this.handleDate(item.date, item.startTime);
      item.endTime = this.handleDate(item.date, item.endTime);
    })

    this.eventService.addEventTeam(this.eventID, arrTemp).subscribe((res) => {
      this.addEventTeamSuccess.emit();
      this.isLoading = false;
      NotificationService.success('Add Team Successful.')
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }
  handleDate(date, startTime) {
    let d = new Date();
    let date2 = new Date(date);
    let startTime2 = new Date(startTime);
    d.setFullYear(date2.getFullYear(), date2.getMonth(), date2.getDate());
    d.setHours(startTime2.getHours());
    d.setMinutes(startTime2.getMinutes());
    d.setSeconds(0);
    d.setMilliseconds(0);
    return this.adjustForTimezone(d);
  }

  adjustForTimezone(date: Date): Date {
    let timeOffsetInMS: number = date.getTimezoneOffset() * 60000;
    date.setTime(date.getTime() - timeOffsetInMS);
    return date;
  }
  cancel(){
    this.teamList = this.bkTeamList;
    this.cancelAddEventTeam.emit();
  }
}
