import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventCategoryGeneralComponent } from './event-category-general.component';

describe('EventCategoryGeneralComponent', () => {
  let component: EventCategoryGeneralComponent;
  let fixture: ComponentFixture<EventCategoryGeneralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventCategoryGeneralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventCategoryGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
