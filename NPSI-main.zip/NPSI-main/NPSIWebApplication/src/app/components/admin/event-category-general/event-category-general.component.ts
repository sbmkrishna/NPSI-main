import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import Swal from 'sweetalert2';
import { UserService } from '../../../service/user.service';
import { EventService } from '../../../service/event.service';
import { NotificationService } from '../../../service/notification.service';
import * as _ from 'lodash';
import { SectionService } from 'src/app/service/section.service';
import { CategoryService } from 'src/app/service/category.service';

@Component({
  selector: 'app-event-category-general',
  templateUrl: './event-category-general.component.html',
  styleUrls: ['./event-category-general.component.css']
})
export class EventCategoryGeneralComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  @ViewChild('addTeam') addTeam: ModalDirective;
  @ViewChild('editTeamModal') editTeamModal: ModalDirective;
  @ViewChild('subsectionAssignmentModal') subsectionAssignmentModal: ModalDirective;
  @Input("eventID") eventID;
  @Input("categoryID") categoryID;
  @Input("selectedSections") selectedSections;
  @Input("selectedUsers") selectedUsers;
  @Input("selectedTeams") selectedTeams;
  @Input("listSection") listSection;
  @Input("listTeam") listTeam;
  @Input("statusName") statusName;
  @Input("startDate") startDate;
  @Input("endDate") endDate;
  @Output("addDeleteSectionsSuccess") addDeleteSectionsSuccess = new EventEmitter<any>();
  @Output("addDeleteTeamSuccess") addDeleteTeamSuccess = new EventEmitter<any>();
  @Output("addDeleteUserSuccess") addDeleteUserSuccess = new EventEmitter<any>();
  @Output("cancelEditEventSection") cancelEditEventSection = new EventEmitter<any>();
  @Output("cancelEditEventTeam") cancelEditEventTeam = new EventEmitter<any>();
  @Output("editTeamMembersSuccess") editTeamMembersSuccess = new EventEmitter<any>();

  listUser: any;
  selectName: any;
  returnArray: any;
  bkListSection: any;
  bkListUsers: any;
  bkListTeams: any;
  listEditingEventSection: any = [];
  listEditingEventTeam: any = [];
  keyword: any;
  listSelected: any = [];
  isLoading: any = false;
  roles: any;
  isDeletingJudge: any = false;
  isDeletingSection: any = false;
  isDeletingUser: any = false;
  isDeletingTeam: any = false;
  leadJudgeID: any;
  judgeID: any;
  checkDateAndTime: any = false;
  isLoadingSubsections: any = false; x
  subsections: any = [];
  judgeSubsections: any = [];
  sectionObj: any = {};
  judgeObj: any = {};
  isDisabledSaveSubsection: any = false;
  isAddNewJudgeOrSection: any = false;
  objectTeam: any = {};
  members: any = [];
  categories: any = [];
  selectedJudges: any = [];
  minDate: Date;
  maxDate: Date;

  constructor(private userService: UserService,
    private eventService: EventService,
    private sectionService: SectionService,
    private categoryService: CategoryService) {
  }

  ngOnInit(): void {
    this.minDate = new Date(this.startDate);
    this.maxDate = new Date(this.endDate);
    this.getRolesJudgesLeadJudge();
    this.getAllUser();
    this.getCategory();
  }

  ngOnChanges() {
    if (this.selectedSections && this.selectedUsers) {
      let arrTemp = [];
      this.selectedSections.forEach(e => {
        if (e.judges && e.judges.length > 0) {
          e.judges.forEach(el => {
            arrTemp.push(el);
          })
        }
      })
      let arrUser = JSON.parse(JSON.stringify(this.selectedUsers));
      for (let i = 0; i < arrTemp.length; i++) {
        let e = arrTemp[i];
        let index = _.findIndex(arrUser, (item: any) => {
          if (item.userId) return item.userId == e.id;
          else return item.id == e.id;
        })
        if (index >= 0) arrUser.splice(index, 1);
      }
      this.selectedJudges = JSON.parse(JSON.stringify(arrUser));
    }
    if (this.listEditingEventSection && this.listEditingEventSection.length > 0) {
      this.selectedSections.forEach((el: any) => {
        this.listEditingEventSection.forEach((item: any) => {
          if (el.id == item.id) {
            this.editCancelEventSection(el, 0);
          }
        })
      })
    }
  }
  getAllUser() {
    this.userService.getAllUser().subscribe((res: any) => {
      res = _.orderBy(res, [user => user.lastName.toLowerCase()], ['asc']);
      this.listUser = res;
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  getCategory() {
    this.categoryService.getCategory().subscribe((res) => {
      this.categories = res;
    })
  }

  getRolesJudgesLeadJudge() {
    this.userService.getRolesJudgesLeadJudge().subscribe((res) => {
      this.roles = res;
      for (let i = 0; i < this.roles.length; i++) {
        if (this.roles[i].name == 'Lead Judge') {
          this.leadJudgeID = this.roles[i].id;
        }
        if (this.roles[i].name == 'Judge') {
          this.judgeID = this.roles[i].id;
        }
      }
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  showChildModal(selectName): void {
    if (this.selectName == 'Teams') {
      this.addTeam.show();
    } else {
      this.lgModal.show();

    }
  }

  hideChildModal(): void {
    this.lgModal.hide();
  }

  openPopup(selectName) {
    //open pop-up by name
    this.selectName = selectName;
    this.returnArray = [];
    this.keyword = "";
    this.listSelected = [];
    if (this.selectName == 'Sections') {
      this.bkListSection = JSON.parse(JSON.stringify(this.listSection));
      this.hanldeOpenPopup(this.listSection, this.selectedSections, "id");
    }
    if (this.selectName == 'Users') {
      this.bkListUsers = JSON.parse(JSON.stringify(this.listUser));
      this.hanldeOpenPopup(this.listUser, this.selectedUsers, "userId");
    }
    if (this.selectName == 'Teams') {
      this.bkListTeams = JSON.parse(JSON.stringify(this.listTeam));
      this.hanldeOpenPopup(this.listTeam, this.selectedTeams, "teamID");
    }
    this.showChildModal(this.selectName);
  }

  hanldeOpenPopup(listActive: any, listByEvent: any, property: string) {
    // remove sections have id existed in list event section 
    let list = JSON.parse(JSON.stringify(listActive));
    for (let i = 0; i < list.length; i++) {
      for (let j = 0; j < listByEvent.length; j++) {
        if (list[i].id == listByEvent[j][property]) {
          list.splice(i, 1);
          i--;
          break;
        }
      }
    }
    list = _.orderBy(list, ['sortOrder'], ['asc']);
    this.returnArray = JSON.parse(JSON.stringify(list));
  }

  cancel() {
    if (this.selectName == 'Sections') {
      this.listSection = JSON.parse(JSON.stringify(this.bkListSection));
    }
    if (this.selectName == 'Users') {
      this.listUser = JSON.parse(JSON.stringify(this.bkListUsers));
    }
    if (this.selectName == 'Teams') {
      this.listTeam = JSON.parse(JSON.stringify(this.bkListTeams));
    }
    this.returnArray = [];
    this.hideChildModal();
  }

  search() {
    if (this.selectName == 'Sections') {
      this.handleSearch(this.listSection, this.selectedSections, "id");
    }
    else if (this.selectName == 'Users') {
      this.handleSearch(this.listUser, this.selectedUsers, "userId");
    }
    else {
      this.handleSearch(this.listTeam, this.selectedTeams, "teamID");
    }
  }

  handleSearch(listValue: any, listByEvent: any, property: string) {
    setTimeout(() => {
      this.returnArray = [];
      if (this.keyword) {
        if (this.selectName == 'Sections') {
          listValue.forEach((item) => {
            if (((item && item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
              this.returnArray.push(item);
            }
          })
          for (let i = 0; i < this.returnArray.length; i++) {
            for (let j = 0; j < this.selectedSections.length; j++) {
              if (this.returnArray[i].id == this.selectedSections[j].id) {
                this.returnArray.splice(i, 1);
              }
            }
          }
        }
        else if (this.selectName == 'Users') {
          listValue.forEach((item) => {
            if (((item && item.username && item.username.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1)
              || (item && item.fullname && item.fullname.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
              this.returnArray.push(item);
            }
          })
        }
        else {
          listValue.forEach((item) => {
            if (((item && item.name && item.name.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1)
              || (item && item.schoolName && item.schoolName.toLowerCase().indexOf(this.keyword.trim().toLowerCase()) != -1))) {
              this.returnArray.push(item);
            }
          })
        }
      } else {
        this.returnArray = JSON.parse(JSON.stringify(listValue))
      }

      //remove id existed in list by property(id)
      for (let i = 0; i < this.returnArray.length; i++) {
        for (let j = 0; j < listByEvent.length; j++) {
          if (this.returnArray[i].id == listByEvent[j][property]) {
            this.returnArray.splice(i, 1);
            i--;
            break;
          }
        }
      }
    })
  }

  changeChecked(checked, item) {
    if (checked) {
      let obj = JSON.parse(JSON.stringify(item));
      this.listSelected.push(obj);
      this.returnArray.forEach((i) => {
        this.listSelected.forEach((s) => {
          if (i.id == s.id) {
            i.checked = checked;
          }
        })
      })
    } else {
      for (let i = 0; i < this.listSelected.length; i++) {
        let itemSelect = this.listSelected[i];
        if (itemSelect.id == item.id) {
          this.listSelected.splice(i, 1);
          break;
        }
      }
    }
  }

  addEventSection() {
    for (let i = 0; i < this.listSelected.length; i++) {
      let selected = this.listSelected[i];
      for (let j = 0; j < this.returnArray.length; j++) {
        let item = this.returnArray[j];
        if (selected.id == item.id) {
          selected.date = item.date;
          selected.startTime = item.startTime;
          selected.endTime = item.endTime;
          selected.judges = item.judges;
          break;
        }
      }
    }

    let listSection = [];
    this.listSelected.forEach((item) => {
      if (item.judges != null) {
        item.judges.forEach(el => {
          el.judgeUserID = el.userId;
        })
      }
      listSection.push({
        eventID: this.eventID,
        sectionID: item.id,
        judges: item.judges,
        startTime: this.handleDate(item.date, item.startTime),
        endTime: this.handleDate(item.date, item.endTime),
      });
    })
    if (listSection && listSection.length == 0) {
      NotificationService.warning('Options have been selected.');
      this.cancel();
      return;
    }

    let object = {
      eventID: this.eventID,
      eventSection: listSection,
    };

    this.eventService.addEventSection(object).subscribe((res) => {
      this.cancel();
      this.isAddNewJudgeOrSection = true;
      this.addDeleteSectionsSuccess.emit();
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Add Section Successful.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  handleDate(date, startTime) {
    let d = new Date();
    let date2 = new Date(date);
    let startTime2 = new Date(startTime);
    d.setFullYear(date2.getFullYear(), date2.getMonth(), date2.getDate());
    d.setHours(startTime2.getHours());
    d.setMinutes(startTime2.getMinutes());
    d.setSeconds(0);
    d.setMilliseconds(0);
    return this.adjustForTimezone(d);
  }

  adjustForTimezone(date: Date): Date {
    let timeOffsetInMS: number = date.getTimezoneOffset() * 60000;
    date.setTime(date.getTime() - timeOffsetInMS);
    return date;
  }

  deleteEventSection(sectionID) {
    NotificationService.confirm('Are you sure you want to delete Section ?').then((res) => {
      if (res.value) {
        this.isDeletingSection = true;
        this.eventService.deleteEventSection(this.eventID, sectionID).subscribe((res) => {
          this.isDeletingSection = false;
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Delete Section Successful.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.addDeleteSectionsSuccess.emit();
        }, (err) => {
          this.isDeletingSection = false;
          NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
        })
      }
    })
  }



  deleteEventTeam(teamID) {
    NotificationService.confirm('Are you sure you want to delete Team ?').then((res) => {
      if (res.value) {
        this.isDeletingTeam = true;
        this.eventService.deleteEventTeam(this.eventID, teamID).subscribe((res) => {
          this.isDeletingTeam = false;
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Delete Team Successful.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.addDeleteTeamSuccess.emit();
        }, (err) => {
          this.isDeletingTeam = false;
          NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
        })
      }
    })
  }

  addEventUser() {
    this.listSelected.forEach((item) => {
      if (!item.roleId) {
        item.roleId = this.judgeID;
      }
    })
    for (let i = 0; i < this.selectedUsers.length; i++) {
      let itemSelected = this.selectedUsers[i];
      for (let j = 0; j < this.listSelected.length; j++) {
        let item = this.listSelected[j];
        if (item.id == itemSelected.userId && item.roleId == itemSelected.roleID) {
          this.listSelected.splice(j, 1);
          break;
        }
      }
    }
    let listUser = [];
    this.listSelected.forEach((item) => {
      listUser.push(
        {
          userID: item.id,
          roleID: item.roleId
        });
    })
    if (listUser && listUser.length == 0) {
      NotificationService.warning('Options have been selected.');
      this.cancel();
      return;
    }
    let object = {
      eventID: this.eventID,
      categoryID: this.categoryID,
      listUser: listUser,
    };
    this.eventService.addEventUser(object).subscribe((res) => {
      this.cancel();
      this.addDeleteUserSuccess.emit();
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Add User Successful.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  deleteEventUser(userID) {
    NotificationService.confirm('Are you sure you want to delete User ?').then((res) => {
      if (res.value) {
        this.isDeletingUser = true;
        this.eventService.deleteUserEvent(this.eventID, userID, this.categoryID).subscribe((res) => {
          this.isDeletingUser = false;
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Delete User Successful.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.addDeleteUserSuccess.emit();
        }, (err) => {
          this.isDeletingUser = false;
          NotificationService.error(err.error ? err.error : 'An unknown server error occurred.')
        })
      }
    })
  }

  changeRole(role, user) {
    for (let i = 0; i < this.listSelected.length; i++) {
      let item = this.listSelected[i];
      if (user.id == item.id) {
        item.roleId = role;
        break
      }
    }
  }

  addJudgeEventSection(judgeID, itemSection, mode) {
    if (judgeID) {
      itemSection["judges"] = itemSection["judges"] ? itemSection["judges"] : [];
      let judgesItem = _.find(this.selectedUsers, (item: any) => {
        if (item.userId) return item.userId == judgeID;
        else return item.id == judgeID;
      })
      let checkJudgeID = _.find(itemSection["judges"], (item: any) => {
        if (item.userId) return item.userId == judgeID;
        else return item.id == judgeID;
      });
      if (!checkJudgeID) {
        itemSection["judges"].push(judgesItem);
        judgesItem.judgeUserID = judgeID;
        judgesItem.sectionID = itemSection.id;
        if (mode == 0) {
          this.eventService.addJudgeEventSection(judgesItem).subscribe(result => {
            this.isAddNewJudgeOrSection = true;
            NotificationService.success('Assign Judge Successful.');
            let judgeIndex = _.findIndex(this.selectedJudges, (item: any) => {
              if (item.userId) return item.userId == judgeID;
              else return item.id == judgeID;
            })
            let judgeArr = this.selectedJudges;
            if (judgeIndex) judgeArr = judgeArr.splice(judgeIndex, 1);
            this.selectedJudges = JSON.parse(JSON.stringify(judgeArr));
            this.addDeleteSectionsSuccess.emit();
          }, err => {
            NotificationService.error(err && err.error ? err.error : 'An unknown server error occurred.');
          })
        }
      } else {
        NotificationService.warning('Judge has been selected.');
        return false;
      }
    }
  }

  deleteJudgeEventSection(judgeID, itemSection, mode) {
    _.remove(itemSection.judges, (item: any) => {
      if (item.userId) return item.userId == judgeID;
      else return item.id == judgeID;
    });
    itemSection.judgeUserID = judgeID;
    itemSection.sectionID = itemSection.id;
    itemSection.eventID = this.eventID;
    if (mode == 0) {
      this.eventService.deleteJudgeEventSection(itemSection).subscribe(result => {
        this.addDeleteSectionsSuccess.emit();
      }, err => {
        this.addDeleteSectionsSuccess.emit();
        NotificationService.error(err && err.error ? err.error : 'An unknown server error occurred.');
      })
    }
  }

  editCancelEventSection(itemSection, mode) {
    // mode = 0: edit event section
    // mode = 1: cancel event section
    if (mode == 0) {
      itemSection.editable = true;
      let bkItemSection = JSON.parse(JSON.stringify(itemSection));
      this.listEditingEventSection.push(JSON.parse(JSON.stringify(bkItemSection)));
    }
    if (mode == 1) {
      let isExistSection = _.find(this.listEditingEventSection, (item: any) => {
        return item.id == itemSection.id;
      });
      if (isExistSection) {
        itemSection.editable = false;
        this.listEditingEventSection.forEach((element, index) => {
          if (element.id == itemSection.id) {
            element.editable = false;
            itemSection = JSON.parse(JSON.stringify(element));
            this.cancelEditEventSection.emit(element);
            this.listEditingEventSection.splice(index, 1);
          }
        });
      }
    }
  }

  saveEditEventSection(section) {
    let itemSection = JSON.parse(JSON.stringify(section));
    if (itemSection.judges && itemSection.judges.length > 0) {
      itemSection.judges.forEach((e: any) => {
        e.judgeUserID = e.id ? e.id : e.userId;
      })
    }
    this.eventService.updateEventSection(this.eventID, itemSection.id, itemSection).subscribe(res => {
      this.editCancelEventSection(itemSection, 1);
      this.addDeleteSectionsSuccess.emit();
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Update Section Successful.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      NotificationService.error(err.error ? err.error : 'An unknown server error occurred.');
    })
  }
  checkValueDatetime(itemSection) {
    setTimeout(() => {
      itemSection.isDisabledSave = this.doCheckDatetime(itemSection.startTime, itemSection.endTime, itemSection.date)
    })
  }

  // a and b are javascript Date objects
  dateDiffInDays(a, b) {
    // Discard the time and time-zone information.
    let utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    let utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.floor((utc2 - utc1) / (1000 * 60 * 60 * 24));
  }


  doCheckDatetime(startTime, endTime, date) {
    let start = new Date(startTime);
    let end = new Date(endTime);
    let startDate = this.minDate;
    startDate.setHours(0, 0, 0, 0);
    let endDate = this.maxDate;
    endDate.setHours(0, 0, 0, 0);
    let isSooner = this.dateDiffInDays(new Date(date), new Date(startDate));
    let isLater = this.dateDiffInDays(new Date(date), new Date(endDate));
    if (isLater < 0) {
      NotificationService.error("The section date cannot be later than the Event End Date.");
      return false;
    }
    if (isSooner > 0) {
      NotificationService.error("The section date cannot be sooner than the Event Start Date.");
      return false;
    }
    if (!date || !startTime || !endTime || start.getHours() > end.getHours() || (start.getHours() == end.getHours() && start.getMinutes() >= end.getMinutes())) {
      return false;
    } else {
      return true;
    }
  }
  hideSubsectionModal() {
    this.sectionObj = {};
    this.judgeObj = {};
    this.subsectionAssignmentModal.hide();
  }
  showSubsectionModal(section, judge) {
    this.subsections = [];
    this.judgeSubsections = [];
    this.sectionObj = JSON.parse(JSON.stringify(section));
    this.judgeObj = JSON.parse(JSON.stringify(judge));
    this.subsectionAssignmentModal.show();
    this.getSubsectionBySectionID(this.sectionObj.id).then((results: any) => {
      this.subsections = results;
    });
  }

  getSubsectionBySectionID(sectionID) {
    this.isLoadingSubsections = true;
    this.subsections = [];
    return new Promise<void>((resolve) => {
      this.sectionService.getSubsectionBySectionID(sectionID).subscribe((results: any) => {
        this.isLoadingSubsections = false;
        this.getSubsectionByJudgeAndSection(this.judgeObj.id, this.sectionObj.id).then((res: any) => {
          if (results && results.length > 0 && res) {
            results.forEach(e => {
              if (this.isAddNewJudgeOrSection) {
                e.checked = true;
              } else {
                res.forEach(el => {
                  if (e.id == el.id) {
                    e.checked = true;
                  }
                })
              }
            });
          }
          results.forEach((e: any) => {
            if (!e.checked) e.checked = false;
          });
          resolve(results);
        })
      }, err => {
        this.isLoadingSubsections = false;
        NotificationService.error('An unknown server error occurred.');
      })
    })
  }
  getSubsectionByJudgeAndSection(judgeID, sectionID) {
    return new Promise<void>((resolve) => {
      this.eventService.getSubsectionByJudgeAndSection(judgeID, sectionID, this.eventID).subscribe((results: any) => {
        results = _.uniqBy(results, 'id');
        if (results && results.length == 0) {
          this.isAddNewJudgeOrSection = true;
        } else {
          this.isAddNewJudgeOrSection = false;
        }
        this.judgeSubsections = results;
        resolve(results);
      }, err => {
        NotificationService.error('An unknown server error occurred.');
      })
    })
  }
  changeSelectedSubsection(value, subsection) {
    subsection.checked = value;
  }
  addSubsectionForJudge() {
    let isExistChecked = _.find(this.subsections, function (o) { return o.checked && o.checked == true });
    let arrSubsection = JSON.parse(JSON.stringify(this.subsections));
    _.remove(arrSubsection, (o) => {
      return o.checked == false;
    })
    if (!isExistChecked) {
      NotificationService.error("Please select at least 1 subsection.");
      return false;
    }
    if (arrSubsection && arrSubsection.length > 0) {
      arrSubsection.forEach((e: any) => {
        e.subsectionID = e.id;
      })
    }
    this.eventService.addSubsectionForJudge(this.judgeObj.id, this.eventID, this.categoryID, arrSubsection[0].sectionID, arrSubsection).subscribe(res => {
      NotificationService.success("Assign Judge Successful.");
      this.hideSubsectionModal();
    }, err => {
      NotificationService.error(err.error ? err.error : 'An unknown server error occurred.');
    });
  }
  editCancelEventTeam(itemTeam, mode) {
    // mode = 0: edit event team
    // mode = 1: cancel event team
    if (mode == 0) {
      itemTeam.editable = true;
      itemTeam.date = new Date(itemTeam.date);
      let bkItemTeam = JSON.parse(JSON.stringify(itemTeam));
      this.listEditingEventTeam.push(JSON.parse(JSON.stringify(bkItemTeam)));
      this.checkValueDatetime(itemTeam);
    }
    if (mode == 1) {
      let isExistTeam = _.find(this.listEditingEventTeam, (item: any) => {
        return item.teamID == itemTeam.teamID;
      });
      if (isExistTeam) {
        itemTeam.editable = false;
        this.listEditingEventTeam.forEach((element, index) => {
          if (element.teamID == itemTeam.teamID) {
            element.editable = false;
            itemTeam = JSON.parse(JSON.stringify(element));
            this.cancelEditEventTeam.emit(element);
            this.listEditingEventTeam.splice(index, 1);
          }
        });
      }
    }
  }
  saveEditEventTeam(team) {
    let itemTeam = JSON.parse(JSON.stringify(team));
    console.log('itemTeam :', itemTeam);
    itemTeam.startTime = this.handleDate(itemTeam.date, itemTeam.startTime);
    itemTeam.endTime = this.handleDate(itemTeam.date, itemTeam.endTime);
    this.eventService.updateEventTeam(this.eventID, itemTeam.teamID, itemTeam).subscribe(res => {
      this.editCancelEventTeam(itemTeam, 1);
      this.addDeleteTeamSuccess.emit();
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: 'Update Team Successful.',
        showConfirmButton: false,
        timer: 3000,
        toast: true
      })
    }, (err) => {
      NotificationService.error(err.error ? err.error : 'An unknown server error occurred.');
    })
  }

  openPopupEditTeam(team) {
    this.objectTeam = JSON.parse(JSON.stringify(team));
    this.objectTeam.id = this.objectTeam.teamID;
    this.objectTeam.name = this.objectTeam.teamName;
    this.members = JSON.parse(JSON.stringify(team.members))
    this.editTeamModal.show();
  }
  onSaveEditSuccess(value) {
    this.editTeamModal.hide();
    this.editTeamMembersSuccess.emit();
  }
  onCancelEditSuccess() {
    this.editTeamModal.hide();
  }
  addEventTeamSuccess() {
    this.addTeam.hide();
    this.addDeleteTeamSuccess.emit();
  }
  cancelAddEventTeam(){
    this.addTeam.hide();
  }
}
