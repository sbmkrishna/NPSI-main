import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { EventService } from 'src/app/service/event.service';
import { ReportService } from 'src/app/service/report.service';
import * as FileSaver from 'file-saver';
import * as _ from 'lodash';
import { NotificationService } from 'src/app/service/notification.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  objectSearch: any = {
    eventID: null,
    categoryID: null,
    teamID: null,
    judgeUserID: null,
    reportType: 1,
  };
  events: any = [];
  categories: any = [];
  teams: any = [];
  judges: any = [];
  isLoadingExport: any = false;
  eventID: any;
  isReportAllEvent: boolean;
  constructor(
    private eventService: EventService,
    private categoryService: CategoryService,
    private reportService: ReportService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    let href = JSON.parse(JSON.stringify(this.router.url));
    if (href.indexOf("eventID") == -1) {
      this.getEvent()
    } else {
      this.activatedRoute.queryParams.subscribe(params => {
        this.eventID = params.eventID;
        this.getEvent().then(results => {
          if (params && params.eventID) {
            this.objectSearch.eventID = params.eventID;
            this.getCategory(params.eventID);
          } else {
            this.objectSearch.eventID = null;
            this.objectSearch.categoryID = null;
            this.objectSearch.judgeUserID = null;
            this.objectSearch.teamID = null;
          }
        })
      });
    }
  }

  getEvent() {
    return new Promise<void>(resolve => {
      this.eventService.getEventsByReportType(this.objectSearch.reportType).subscribe((results: any) => {
        this.events = results;
        resolve(results);
      })
    })
  }

  getCategory(eventId) {
    this.categories = [];
    this.objectSearch.categoryID = null;
    this.objectSearch.judgeUserID = null;
    this.objectSearch.teamID = null;
    this.categoryService.getCategoryByEventId(eventId).subscribe((results: any) => {
      this.categories = results;
      if (results && results.length == 1) {
        this.objectSearch.categoryID = results[0].id;
        this.getTeam(this.objectSearch.categoryID, this.objectSearch.eventID);
        this.getJudge(this.objectSearch.categoryID, this.objectSearch.eventID);
      }
    })
  }

  getTeamAndJudge(categoryID, eventID) {
    this.objectSearch.judgeUserID = null;
    this.objectSearch.teamID = null;
    this.getJudge(categoryID, eventID);
    this.getTeam(categoryID, eventID);
  }

  getTeam(categoryID, eventID) {
    this.teams = [];
    this.eventService.getEventTeam(eventID, categoryID).subscribe((results) => {
      this.teams = results;
    })
  }

  getJudge(categoryID, eventID) {
    this.judges = [];
    this.eventService.getJudgesByEventAndCategory(eventID, categoryID).subscribe((results) => {
      this.judges = results;
    })
  }

  changeReportType(reportType) {
    this.objectSearch.reportType = reportType;
    this.objectSearch.eventID = null;
    this.objectSearch.categoryID = null;
    this.objectSearch.judgeUserID = null;
    this.objectSearch.teamID = null;
    this.getEvent().then((results: any) => {
      if (results && results.length > 0) {
        let isExist = _.find(results, (o) => { return o.id == this.eventID; })
        this.objectSearch.eventID = isExist ? this.eventID : null;
      }
      if (this.objectSearch.eventID) {
        this.getCategory(this.eventID);
      }
    });
  }

  changeTeam(teamID) {
    this.objectSearch.teamID = teamID;
    if(teamID == 'null' || !teamID){
      this.objectSearch.teamID = null
    }
  }

  changeJudge(judgeUserID) {
    this.objectSearch.judgeUserID = judgeUserID;
  }

  exportReport() {
    if (this.objectSearch.reportType == 1) {
      this.exportDetailedScoring();
    } else if (this.objectSearch.reportType == 2) {
      this.exportRankingReports();
    } else {
      this.exportOverallRankings();
    }
  }

  exportDetailedScoring() {
    if (this.objectSearch && !this.objectSearch.eventID) {
      NotificationService.error("Please select an event.");
      return false;
    }
    if (this.objectSearch && !this.objectSearch.categoryID) {
      NotificationService.error("Please select a category.");
      return false;
    }
    //if (this.objectSearch && !this.objectSearch.teamID) {
    //  NotificationService.error("Please select an team.");
    //  return false;
    //}
    //if (this.objectSearch && !this.objectSearch.judgeUserID) {
    //  NotificationService.error("Please select an judge.");
    //  return false;
    //}

    this.isLoadingExport = true;

    this.reportService.exportDetailedScoring(this.objectSearch).subscribe((result: any) => {
      let contentDisposition = result.headers.get('content-disposition')
      let fileName = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim();
      FileSaver.saveAs(result.body, fileName);
      this.isLoadingExport = false;
    }, err => {
      this.isLoadingExport = false;
      NotificationService.error('An unknown server error occurred.')
    })
  }

  exportRankingReports() {
    if (this.objectSearch && !this.objectSearch.eventID) {
      NotificationService.error("Please select an event.");
      return false;
    }
    if (this.objectSearch && !this.objectSearch.categoryID) {
      NotificationService.error("Please select a category.");
      return false;
    }
    // if (this.objectSearch && !this.objectSearch.teamID) {
    //   NotificationService.error("Please select an team.");
    //   return false;
    // }
    this.isLoadingExport = true;
    this.reportService.exportRankingReports(this.objectSearch).subscribe((result: any) => {
      let contentDisposition = result.headers.get('content-disposition')
      let fileName = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim();
      FileSaver.saveAs(result.body, fileName);
      this.isLoadingExport = false;
    }, err => {
      this.isLoadingExport = false;
      NotificationService.error('An unknown server error occurred.')
    })
  }

  exportOverallRankings() {
    if (this.objectSearch && !this.objectSearch.eventID) {
      NotificationService.error("Please select an event.");
      return false;
    }
    if (this.objectSearch && !this.objectSearch.categoryID) {
      NotificationService.error("Please select a category.");
      return false;
    }
    this.isLoadingExport = true;
    this.reportService.exportOverallRankings(this.objectSearch).subscribe((result: any) => {
      let contentDisposition = result.headers.get('content-disposition')
      let fileName = contentDisposition.split(';')[1].split('filename')[1].split('=')[1].trim();
      FileSaver.saveAs(result.body, fileName);
      this.isLoadingExport = false;
    }, err => {
      this.isLoadingExport = false;
      NotificationService.error('An unknown server error occurred.')
    });
  }
}
