import { Component, OnInit, ViewChild } from '@angular/core';
import { EventService } from '../../../service/event.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { NotificationService } from 'src/app/service/notification.service';

@Component({
  selector: 'app-event-detail',
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.css']
})
export class EventDetailComponent implements OnInit {
  @ViewChild('lgModal') lgModal: ModalDirective;
  eventID: any;
  event: any;
  objectEvent: any;
  categoryManagementID: any;
  categoryCulinaryID: any;
  user: any; 
  listCategoryNameByEventAdmin: any;
  isEdit: any

  constructor(private eventService: EventService,
    private activatedRoute: ActivatedRoute, 
    private router: Router) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
    })
    this.activatedRoute.queryParams.subscribe(params => {
      this.isEdit = params['isEdit']
    });
    if (this.eventID) {
      this.getEventDetail();
    }
    if (this.eventID && this.user && !this.user.isSuperAdmin && this.user.roles && this.user.roles.indexOf("Event - Admin") != -1) {
      this.getCategoryByEventAdmin();
    }
  }

  getCategoryByEventAdmin() {
    this.eventService.getCategoryByEventAdmin(this.eventID).subscribe((res) => {
      this.listCategoryNameByEventAdmin = res;
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  getEventDetail() {
    this.eventService.getEventDetail(this.eventID).subscribe((res) => {
      this.event = res;
      this.event.categoriesName = [];
      this.event.categories.forEach((item) => {
        this.event.categoriesName.push(item.name);
        if (item.name == 'Management') {
          this.categoryManagementID = item.id;
        } else {
          this.categoryCulinaryID = item.id
        }
        if(this.isEdit == "true"){
          this.editEvent();
        }
      })
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }

  editEvent() {
    this.objectEvent = JSON.parse(JSON.stringify(this.event));
    setTimeout(() => {
      this.showChildModal();
    })
  }

  showChildModal(): void {
    this.lgModal.show();
  }

  hideChildModal(): void {
    this.lgModal.hide();
  }

  addEditSuccess(value) {
    this.getEventDetail();
    this.cancel();
  }

  cancel() {
    this.objectEvent = null;
    this.hideChildModal();
  }
  startEndEventSuccess(value){
    this.getEventDetail();
    this.lgModal.hide();
  }
}
