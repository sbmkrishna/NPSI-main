import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventAdminDashboardComponent } from './event-admin-dashboard.component';

describe('EventAdminDashboardComponent', () => {
  let component: EventAdminDashboardComponent;
  let fixture: ComponentFixture<EventAdminDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventAdminDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventAdminDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
