import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-admin-dashboard',
  templateUrl: './event-admin-dashboard.component.html',
  styleUrls: ['./event-admin-dashboard.component.css']
})
export class EventAdminDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
