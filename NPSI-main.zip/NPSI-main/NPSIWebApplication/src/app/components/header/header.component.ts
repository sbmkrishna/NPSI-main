import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../service/account.service';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  user: any;
  constructor(private accountService: AccountService,
    private router: Router,
    private sanitizer: DomSanitizer) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem("userInfo"));

  }
  logOut() {
    this.accountService.logOut();
  }
  transform(base64Image) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(base64Image);
  }
  goToHome() {
    if (this.user && this.user.isSuperAdmin) {
      this.router.navigate(['/']);
    }
    else if (this.user && !this.user.isSuperAdmin && (!this.user.roles || (this.user.roles && this.user.roles.indexOf('Event - Admin') == -1))) {
      this.router.navigate(['/judge-dashboard']);
    }
    else if (this.user && !this.user.isSuperAdmin && this.user.roles && this.user.roles.indexOf('Event - Admin') != -1) {
      this.router.navigate(['/event-admin-dashboard']);
    }
  }
}
