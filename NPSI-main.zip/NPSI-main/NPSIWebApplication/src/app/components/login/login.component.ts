import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../../service/account.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginInfo: any = {};
  constructor(private accountService: AccountService, private router: Router) { }

  ngOnInit(): void {
  }
  login() {
    if (!this.loginInfo.username || !this.loginInfo.password) {
      Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: 'Username and password are required.',
        showConfirmButton: false,
        timer: 1500,
        toast: true
      })
    } else {
      this.accountService.login(this.loginInfo).then((res: any) => {
        //this.router.navigate(['/admin']);
      }, (err) => {
        Swal.fire({
          position: 'top-end',
          icon: 'error',
          title: "Username or password is incorrect.",
          showConfirmButton: false,
          timer: 3000,
          toast: true
        })
      })
    }
  }

}
