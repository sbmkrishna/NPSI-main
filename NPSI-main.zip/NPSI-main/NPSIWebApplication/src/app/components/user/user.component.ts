import { Component, OnInit } from '@angular/core';
import { EventService } from '../../service/event.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  eventsActive: any;
  eventsCompleted: any;
  eventsStarted: any;
  constructor(private eventService: EventService) { }

  ngOnInit(): void {
    this.getEventActiveByUserID();
    this.getEventCompletedByUserID();
    this.getEventStartedByUserID();
  }
  getEventActiveByUserID() {
    this.eventService.getEventActiveByUserID().subscribe((res) => {
      this.eventsActive = res;
    })
  }
  getEventCompletedByUserID() {
    this.eventService.getEventCompleteByUserID().subscribe((res) => {
      this.eventsCompleted = res;
    })
  }
  getEventStartedByUserID() {
    this.eventService.getEventStartedByUserID().subscribe((res) => {
      this.eventsStarted = res;
    })
  }
}
