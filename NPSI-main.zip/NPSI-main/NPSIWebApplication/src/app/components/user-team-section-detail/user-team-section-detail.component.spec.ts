import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTeamSectionDetailComponent } from './user-team-section-detail.component';

describe('UserTeamSectionDetailComponent', () => {
  let component: UserTeamSectionDetailComponent;
  let fixture: ComponentFixture<UserTeamSectionDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserTeamSectionDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTeamSectionDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
