import { Component, OnInit, ViewChild, OnDestroy, ElementRef, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SectionService } from '../../service/section.service';
import { EventService } from '../../service/event.service';
import { UserService } from '../../service/user.service';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { NotificationService } from '../../service/notification.service';
import { DomSanitizer } from '@angular/platform-browser';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';
import { PleaseWaitService } from '../../service/please-wait.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-user-team-section-detail',
  templateUrl: './user-team-section-detail.component.html',
  styleUrls: ['./user-team-section-detail.component.css']
})
export class UserTeamSectionDetailComponent implements OnInit, OnDestroy {
  @ViewChild('addEditPenOrDis') addEditPenOrDis: ModalDirective;
  @ViewChild('imageModal') imageModal: ModalDirective;
  @ViewChild('addEditSubSection') addEditSubSection: ModalDirective;
  @ViewChild('formAddEditPenOrDis') formAddEditPenOrDis: NgForm;
  @ViewChild('formAddEditSubSection') formAddEditSubSection: NgForm;
  @ViewChild('frmAddEditPenOrDis') frmAddEditPenOrDis: ElementRef;
  @ViewChild('frmAddEditSubSection') frmAddEditSubSection: ElementRef;
  @ViewChild('timeIn') timeIn: ElementRef;
  @ViewChild('timeOut') timeOut: ElementRef;
  @ViewChild('generalComments') generalComments: ElementRef;
  @ViewChild('cameraFileInput') imgType: ElementRef;
  eventID: any;
  sectionID: any;
  section: any;
  teamID: any;
  subSections: any;
  penalties: any;
  disqualifications: any;
  listPenalty: any;
  listDiquafications: any;
  objPenDis: any = {};
  selectedName: any;
  penID: any = null;
  disID: any = null;
  imageSrc: any;
  isLoading: any = false;
  photo: any;
  objSub: any;
  disableDone: any = true;
  isSubmited: any = true;
  isLocked: any = true;
  interval: any;
  isSavingCachedChanges: boolean = false;
  isAdmin: any;
  isLeadJudge: any;
  teamSectionDetail: any;
  bkTeamSectionDetail: any;
  userInfo: any;
  nextPreviousTeamID: any = {};
  judgeID: any;
  judge: any;
  meridians = ['AM', 'PM'];
  isMobile: boolean = false;
  pictureFromCamera: any;
  isEditable: boolean = false;
  role: any = 'U';  // U = user, A = admin/lead, I = impersonating

  constructor(private eventService: EventService,
    private userService: UserService,
    private sectionService: SectionService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private sanitizer: DomSanitizer,
    @Inject(DOCUMENT) private document: Document,
    private pleaseWaitService: PleaseWaitService,) { }

  ngOnInit(): void {
    if (!navigator.onLine) {
      NotificationService.warning("No internet connection.");
    }
    else {
      this.interval = setInterval(() => {
        if (navigator.onLine && !this.isSavingCachedChanges) {
          this.sendCachedRequests();
        }
      }, 5000)
      //      const routeParams = this.activatedRoute.snapshot.paramMap;
      this.activatedRoute.params.subscribe(routeParams => {
        this.eventID = routeParams.eventID;
        this.sectionID = routeParams.sectionID;
        this.teamID = routeParams.teamID;

        // judgeID and role from query string
        const urlParams = new URLSearchParams(window.location.search);
        this.judgeID = urlParams.get("judgeid");
        if (urlParams.has("role")) this.role = urlParams.get("role");

        // get user details from database, not query string or localStorage
        const localUser = JSON.parse(localStorage.getItem("userInfo"));
        this.getUserDetails(localUser.id).then(usr => {
          this.isAdmin = this.userInfo.isSuperAdmin;
          // section detail
          this.sectionService.getSectionDetail(this.sectionID).subscribe((sctn) => {
            this.section = sctn;
            this.eventService.checkLeadJudge(this.eventID, this.section.categoryID).subscribe((yn) => {
              this.isLeadJudge = yn;
              // admins and lead judges can load from the querystring
              if (this.isAdmin || this.isLeadJudge) {
                // lead judges can't edit
                this.isEditable = this.isAdmin;
                this.eventService.getJudgeSectionAssignmentByJudgeUserID(this.eventID, this.sectionID, this.judgeID).subscribe((res) => {
                  if (!res) {
                    NotificationService.error("That judge does not have access to this section.");
                  } else {
                    this.getJudgeDetails(this.judgeID).then(jdg => {
                      this.getTeamSectionDetail(this.eventID, this.sectionID, this.teamID, this.judgeID).then(res => {
                        this.doGetDataInit(res);
                      });
                    });
                  }
                });
              } else {
                // this is the logged-in judge, load only for him/her
                this.isEditable = true;
                this.eventService.getJudgeSectionAssignmentByUserID(this.eventID, this.sectionID).subscribe((res) => {
                  if (!res) {
                    NotificationService.error("You do not have access to this section.");
                  } else {
                    this.getTeamSectionDetail(this.eventID, this.sectionID, this.teamID, this.userInfo.id).then(res => {
                      this.doGetDataInit(res);
                    })
                  }
                });
              }
            });
          });
        });
      });
    }
    this.isMobile = this.checkScreen();
  }

  doGetDataInit(res) {
    if (this.eventID && this.sectionID && this.teamID) {
      if (!(this.role === 'A')) {
        this.getNextPreviousTeamID();
      }
      const currentJudgeId = (this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id;
      Promise.all([
        this.getSubsectionByEventSectionAndTeam(currentJudgeId),
        this.getTeamSectionPenalties(currentJudgeId),
        this.getTeamSectionDisqualification(currentJudgeId),
        this.getEventSectionDisqualification(),
        this.getEventSectionPenalty(),
        this.getJudgeSectionAssignments()
      ]).then(result => {
        setTimeout(() => {
          if (res && res.timeInOutNeeded == true) {
            if (!res.timeIn && !res.timeOut) {
              this.timeIn.nativeElement.firstChild.firstChild.firstChild.childNodes[1].childNodes[0].firstChild.focus();
            } else if (res.timeIn && !res.timeOut) {
              this.timeOut.nativeElement.firstChild.firstChild.firstChild.childNodes[1].childNodes[0].firstChild.focus();
            } else if (res.timeIn && res.timeOut) {
              this.timeIn.nativeElement.firstChild.firstChild.firstChild.childNodes[1].childNodes[0].firstChild.focus();
            }
          }
        })
      })
    }
  }

  checkScreen() {
    let check = false;
    ((a) => { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor);
    return check;
  }

  getTeamSectionDetail(eventID, sectionID, teamID, judgeID) {
    let promise = new Promise((resolve, reject) => {
        this.eventService.getTeamSectionDetail(eventID, sectionID, teamID, judgeID).subscribe((res: any) => {
          this.teamSectionDetail = res;
          //console.log("In teamSectionDetail:");
          //console.log(this.teamSectionDetail);
          this.bkTeamSectionDetail = JSON.parse(JSON.stringify(res));
          resolve(res);
        }, (err) => {
          reject();
        })
    })
    return promise;
  }
  getUserDetails(userID) {
    return new Promise((resolve, reject) => {
      this.userService.getUserDetail(userID).subscribe((res: any) => {
        this.userInfo = res[0];
        resolve(res[0]);
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
        reject();
      })
    })
  }
  getJudgeDetails(judgeID) {
    return new Promise<void>((resolve, reject) => {
      this.userService.getUserDetail(judgeID).subscribe((res) => {
        this.judge = res[0];
        resolve()
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
      })
    })
  }
  getSubsectionByEventSectionAndTeam(judgeID = null) {
    return new Promise<void>((resolve, reject) => {
      this.eventService.getSubsectionByEventSectionAndTeam(this.eventID, this.sectionID, this.teamID, judgeID, this.teamSectionDetail.categoryID).subscribe((res) => {
        this.subSections = res;
        this.subSections = _.orderBy(this.subSections, [function (resultItem) { return (resultItem.sortIndex == 0 || resultItem.sortIndex == null) ? 999 : resultItem.sortIndex; }, 'sortIndex'], ['asc']);
        let flag = false;
        for (let i = 0; i < this.subSections.length; i++) {
          this.subSections[i].prevSubSectionID = (i > 0 ? this.subSections[i - 1].subSectionID : null);
          this.subSections[i].prevSubSectionName = (i > 0 ? this.subSections[i - 1].subSectionName : null);
          this.subSections[i].nextSubSectionID = (i < (this.subSections.length-1) ? this.subSections[i + 1].subSectionID : null);
          this.subSections[i].nextSubSectionName = (i < (this.subSections.length - 1) ? this.subSections[i + 1].subSectionName : null);
          if (this.subSections[i].score == null) {
            flag = true;
            break;
          }
        }
        this.disableDone = flag;
        resolve()
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
      })
    })
  }
  getTeamSectionPenalties(judgeID = null) {
    return new Promise<void>((resolve, reject) => {
      this.eventService.getTeamSectionPenalties(this.eventID, this.sectionID, this.teamID, judgeID).subscribe((res) => {
        this.penalties = res;
        resolve()
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
      })
    })
  }
  getTeamSectionDisqualification(judgeID = null) {
    return new Promise<void>((resolve, reject) => {
      this.eventService.getTeamSectionDisqualification(this.eventID, this.sectionID, this.teamID, judgeID).subscribe((res) => {
        this.disqualifications = res;
        resolve()
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
      })
    })
  }
  getEventSectionPenalty() {
    return new Promise<void>((resolve, reject) => {
      this.eventService.getEventSectionPenalty(this.eventID, this.sectionID, this.teamID).subscribe((res) => {
        this.listPenalty = res;
        resolve()
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
      })
    })
  }
  getEventSectionDisqualification() {
    return new Promise<void>((resolve, reject) => {
      this.eventService.getEventSectionDisqualification(this.eventID, this.sectionID, this.teamID).subscribe((res) => {
        this.listDiquafications = res;
        resolve()
      }, (err) => {
        NotificationService.error('An unknown server error occurred.')
      })
    })
  }
  showFullBody(p) {
    p.statusFullBody = true;
  }
  formatBody(p) {
    p.statusFullBody = false;
  }
  addPen(penID) {
    if (penID) {
      this.selectedName = 'Penalty';
      this.handleOpenPopupAddPenDis(this.listPenalty, penID)
      setTimeout(() => {
        this.showAddEditPenOrDisModal();
      })
    }
  }
  addDis(disID) {
    if (disID) {

      this.selectedName = 'DQ';
      this.handleOpenPopupAddPenDis(this.listDiquafications, disID);
      setTimeout(() => {
        this.showAddEditPenOrDisModal();
      })
    }
  }
  handleOpenPopupAddPenDis(listItem, id) {
    this.imageSrc = null;
    this.objPenDis = {};
    this.formAddEditPenOrDis.reset();
    for (let i = 0; i < listItem.length; i++) {
      let item = listItem[i];
      if (item.id == id) {
        let object = JSON.parse(JSON.stringify(item));
        console.log(object);
        if (this.selectedName == 'Penalty') {
          this.objPenDis = {
            penaltyID: object.id,
            name: object.name,
            deduction: object.deduction,
            deductionRange: object.deductionRange,
            deductionMin: object.deductionMin,
            deductionMax: object.deductionMax,
            questions: object.questions,
            penaltyStatusID: 0
          }
        } else if (this.selectedName == 'DQ') {
          this.objPenDis = {
            disqualificationID: object.id,
            name: object.name,
          }
        }
        break;
      }
    }
  }
  showAddEditPenOrDisModal(): void {
    this.addEditPenOrDis.show()
    this.addEditPenOrDis.onShown.subscribe(() => {
      setTimeout(() => {
        if (this.objPenDis.deductionMax) {
          this.frmAddEditPenOrDis.nativeElement['deduction'].focus();
        } else {
          this.frmAddEditPenOrDis.nativeElement['comments'].focus();
        }
      });
    })

  }
  hideAddEditPenOrDisModal(): void {
    this.addEditPenOrDis.hide();
  }
  showImageModal(): void {
    this.imageModal.show();
  }
  hideImageModal(): void {
    this.imageModal.hide();
  }
  showAddEditSubModal(): void {
    this.addEditSubSection.show();
    this.addEditSubSection.onShown.subscribe(() => {
      this.frmAddEditSubSection.nativeElement['comments'].focus();
      console.log(this.frmAddEditSubSection.nativeElement['score'].dirty);
    })
  }
  hideAddEditSubModal(): void {
    this.addEditSubSection.hide();
  }
  cancel() {
    this.objPenDis = {};
    this.selectedName = null;
    this.penID = null;
    this.disID = null;
    this.imageSrc = null;
    this.formAddEditPenOrDis.reset();
    this.hideAddEditPenOrDisModal();
  }
  onSelectFile(event) {
    let files = event.target.files;
    let file = files[0];
    if (files && file) {

      let mimeType = file.type;
      if (mimeType.match(/image\/*/) == null) {
        NotificationService.warning('Only images are supported.');
        return;
      }
      if (mimeType.indexOf('png') == -1 && mimeType.indexOf('jpeg') == -1) {
        NotificationService.warning('Only PNG and JPG are supported.');
        return;
      }
      let reader = new FileReader();
      reader.onload = this._handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
    }
  }
  _handleReaderLoaded(readerEvt) {
    let binaryString = readerEvt.target.result;
    let base64 = 'data:image/jpg;base64,' + btoa(binaryString)
    this.resizeImage(base64, 400, 350).then(res => {
      if (this.selectedName) {
        this.objPenDis.photo = res;
        this.imageSrc = this.transform(this.objPenDis.photo);
      } else {
        this.objSub.score.photo = res;
        this.imageSrc = this.transform(this.objSub.score.photo);
      }
    })
  }
  resizeImage(base64Str, maxWidth = 400, maxHeight = 350) {
    return new Promise((resolve) => {
      let img = new Image()
      img.src = base64Str
      img.onload = () => {
        let canvas = document.createElement('canvas')
        const MAX_WIDTH = maxWidth
        const MAX_HEIGHT = maxHeight
        let width = img.width
        let height = img.height

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width
            width = MAX_WIDTH
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height
            height = MAX_HEIGHT
          }
        }
        canvas.width = width
        canvas.height = height
        let ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, width, height)
        resolve(canvas.toDataURL())
      }
    })
  }

  transform(base64Image) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(base64Image);
  }
  saveAddPenOrDis() {
    console.log(this.objPenDis);
    if (!this.objPenDis.id) {
      if (this.selectedName == 'Penalty') {
        this.addTeamSectionPenalty()
      } else {
        this.addTeamSectionDisqualification()
      }
    } else {
      if (this.selectedName == 'Penalty') {
        this.editTeamSectionPenalty()
      } else {
        this.editTeamSectionDisqualification()
      }
    }
  }
  addTeamSectionPenalty() {
    this.isLoading = true;
    this.objPenDis.eventID = this.eventID;
    this.objPenDis.teamID = this.teamID;
    this.objPenDis.sectionID = this.sectionID;
    this.objPenDis.deduction = !this.objPenDis.deduction ? this.objPenDis.deductionMin : this.objPenDis.deduction;
    let image = this.objPenDis.photo ? (this.objPenDis.photo.indexOf("base64,") == -1 ? this.objPenDis.photo : this.objPenDis.photo.split("base64,")[1]) : null
    this.objPenDis.photo = image ? image : null;
    if (this.isAdmin || this.isLeadJudge) this.objPenDis.judgeUserID = this.judgeID;

    this.eventService.addTeamSectionPenalty(this.objPenDis).subscribe((res) => {
      this.getEventSectionPenalty();
      this.getTeamSectionPenalties(this.isAdmin ? this.judgeID : this.userInfo.id);
      NotificationService.success('Added penalty successfully.');
      this.cancel();
      this.isLoading = false;
    }, (err) => {
      if (err.status === 0) {
        this.handleAffterAddPenDisErorr(this.objPenDis, 'penaltyID', this.penalties, this.listPenalty);
        this.handleFailRequest(err.status, this.objPenDis, "Penalty", 0);
      } else {
        if ((err.error) && (err.error.message))
          NotificationService.error(err.error.message);
        else
          NotificationService.error(err.message);
      }
      this.isLoading = false;
      this.cancel();
    })
  }
  addTeamSectionDisqualification() {
    this.isLoading = true;
    this.objPenDis.eventID = this.eventID;
    this.objPenDis.teamID = this.teamID;
    this.objPenDis.sectionID = this.sectionID;
    let image = this.objPenDis.photo ? (this.objPenDis.photo.indexOf("base64,") == -1 ? this.objPenDis.photo : this.objPenDis.photo.split("base64,")[1]) : null
    this.objPenDis.photo = image ? image : null;
    if (this.isAdmin || this.isLeadJudge) this.objPenDis.judgeUserID = this.judgeID;

    this.eventService.addTeamSectionDisqualification(this.objPenDis).subscribe((res) => {
      this.getEventSectionDisqualification();
      this.getTeamSectionDisqualification(this.isAdmin ? this.judgeID : this.userInfo.id);
      NotificationService.success('Added disqualification successfully.');
      this.cancel();
      this.isLoading = false;
    }, (err) => {
      if (err.status === 0) {
        this.handleAffterAddPenDisErorr(this.objPenDis, 'disqualificationID', this.disqualifications, this.listDiquafications);
        this.handleFailRequest(err.status, this.objPenDis, "Disqualification", 0);
      } else {
        if ((err.error) && (err.error.message))
          NotificationService.error(err.error.message);
        else
          NotificationService.error(err.message);
      }
      this.isLoading = false;
      this.cancel();
    })
  }
  editPen(pen) {
    this.selectedName = 'Penalty';
    this.checkScore(pen.deduction.toString(), pen);
    this.objPenDis = JSON.parse(JSON.stringify(pen));
    this.objPenDis.penaltyStatusID = 0;
    console.log(this.objPenDis);
    if (!navigator.onLine && !this.objPenDis.id) {
      this.objPenDis.id = -1;
    }
    if (this.objPenDis.photo) {
      this.imageSrc = this.transform('data:image/jpg;base64,' + this.objPenDis.photo)
    }
    setTimeout(() => {
      this.showAddEditPenOrDisModal();
    })
  }
  editDis(dis) {
    this.selectedName = 'DQ';
    this.objPenDis = JSON.parse(JSON.stringify(dis));
    if (!navigator.onLine && !this.objPenDis.id) {
      this.objPenDis.id = -1;
    }
    if (this.objPenDis.photo) {
      this.imageSrc = this.transform('data:image/jpg;base64,' + this.objPenDis.photo)
    }
    setTimeout(() => {
      this.showAddEditPenOrDisModal();
    })
  }
  editTeamSectionPenalty() {
    this.isLoading = true;
    let image = this.objPenDis.photo ? (this.objPenDis.photo.indexOf("base64,") == -1 ? this.objPenDis.photo : this.objPenDis.photo.split("base64,")[1]) : null
    this.objPenDis.photo = image ? image : null;
    if (this.isAdmin) this.objPenDis.judgeUserID = this.judgeID;
    this.eventService.editTeamSectionPenalty(this.objPenDis).subscribe((res) => {
      this.getTeamSectionPenalties((this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id);
      NotificationService.success('Edit penalty successfully.');
      this.cancel();
      this.isLoading = false;
    }, (err) => {
      if (err.status === 0) {
        this.handleAfterEditSubPenDisErorr(this.objPenDis, this.penalties, "penaltyID");
        this.handleFailRequest(err.status, this.objPenDis, "Penalty", 1);
      } else {
        if ((err.error) && (err.error.message))
          NotificationService.error(err.error.message);
        else
          NotificationService.error(err.message);
      }
      this.isLoading = false;
      this.cancel();
    })
  }
  editTeamSectionDisqualification() {
    this.isLoading = true;
    let image = this.objPenDis.photo ? (this.objPenDis.photo.indexOf("base64,") == -1 ? this.objPenDis.photo : this.objPenDis.photo.split("base64,")[1]) : null
    this.objPenDis.photo = image ? image : null;
    if (this.isAdmin) this.objPenDis.judgeUserID = this.judgeID;

    this.eventService.editTeamSectionDisqualification(this.objPenDis).subscribe((res) => {
      this.getTeamSectionDisqualification((this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id);
      NotificationService.success('Edit disqualification successfully.');
      this.cancel();
      this.isLoading = false;
    }, (err) => {
      if (err.status === 0) {
        this.handleAfterEditSubPenDisErorr(this.objPenDis, this.disqualifications, "disqualificationID");
        this.handleFailRequest(err.status, this.objPenDis, "Disqualification", 1);
      } else {
        if ((err.error) && (err.error.message))
          NotificationService.error(err.error.message);
        else
          NotificationService.error(err.message);
      }
      this.isLoading = false;
      this.cancel();
    })
  }
  deletePen(pen) {
    NotificationService.confirm('Are you sure you want to delete this penalty ?').then((result) => {
      if (result.value) {
        this.eventService.deleteTeamSectionPenalty(pen.id).subscribe((res) => {
          this.getEventSectionPenalty();
          this.getTeamSectionPenalties((this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id);
          NotificationService.success('Delete penalty successfully.');
        }, (err) => {
          if (err.status === 0) {
            this.handleAfterDeletePenDisError(pen, "penaltyID", this.penalties, this.listPenalty);
            this.handleFailRequest(err, pen, "Penalty", 2);
          } else {
            if ((err.error) && (err.error.message))
              NotificationService.error(err.error.message);
            else
              NotificationService.error(err.message);
          }
        })
      }
    })
  }
  deleteDis(dis) {
    NotificationService.confirm('Are you sure you want to delete this disqualification ?').then((result) => {
      if (result.value) {
        this.eventService.deleteTeamSectionDisqualification(dis.id).subscribe((res) => {
          this.getEventSectionDisqualification();
          this.getTeamSectionDisqualification((this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id);
          NotificationService.success('Delete disqualification successfully.');
        }, (err) => {
          if (err.status === 0) {
            this.handleAfterDeletePenDisError(dis, "disqualificationID", this.disqualifications, this.listDiquafications);
            this.handleFailRequest(err, dis, "Disqualification", 2);
          } else {
            if ((err.error) && (err.error.message))
              NotificationService.error(err.error.message);
            else
              NotificationService.error(err.message);
          }
        })
      }
    })
  }
  zoomPhoto(photo) {
    this.photo = photo;
    setTimeout(() => {
      this.showImageModal();
    })
  }
  score(subSection) {
    this.imageSrc = null;
    this.objSub = JSON.parse(JSON.stringify(subSection));
    if (this.objSub.score && this.objSub.score.photo) {
      this.imageSrc = this.transform('data:image/jpg;base64,' + this.objSub.score.photo)
    }
    if (!this.objSub.score) {
      this.objSub.score = {};
    }
    setTimeout(() => {
      this.showAddEditSubModal();
    })
  }
  cancelAddEditSub() {
    this.objSub = {
      score: {}
    };
    this.imageSrc = null;
    this.formAddEditSubSection.reset();
    this.hideAddEditSubModal();
    this.document.body.classList.remove('modal-open');
  }

  textChanged(isValid) {
    if (isValid) this.saveAddSubsection(false);
  }

  saveAddSubsection(closeDialog = true) {
    this.isLoading = true;
    this.objSub.eventID = this.eventID;
    this.objSub.teamID = this.teamID;
    this.objSub.sectionID = this.sectionID;
    this.objSub.categoryID = this.teamSectionDetail.categoryID;
    let image = this.objSub.score.photo ? (this.objSub.score.photo.indexOf("base64,") == -1 ? this.objSub.score.photo : this.objSub.score.photo.split("base64,")[1]) : null
    this.objSub.score.photo = image ? image : null;
    if (this.isAdmin || this.isLeadJudge) this.objSub.judgeUserID = this.judgeID;

    this.eventService.addEditScore(this.objSub).subscribe((res: any) => {
      this.isLoading = false;
      NotificationService.success((this.objSub.score.id ? 'Edit' : 'Add') + ' score successful.');
      this.objSub.score.id = res;
      this.getSubsectionByEventSectionAndTeam((this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id);
      if (closeDialog) this.cancelAddEditSub();
    }, (err) => {
      if (err.status === 0) {
        this.handleFailRequest(err.status, this.objSub, "Score", this.objSub.score.id ? 1 : 0);
        for (let i = 0; i < this.subSections.length; i++) {
          if (this.subSections[i].subSectionID == this.objSub.subSectionID) {
            this.subSections[i] = JSON.parse(JSON.stringify(this.objSub));
          }
        }
      } else {
        if ((err.error) && (err.error.message))
          NotificationService.error(err.error.message);
        else
          NotificationService.error(err.message);
      }
      this.isLoading = false;
      if (closeDialog) this.cancelAddEditSub();
    })
  }

  getJudgeSectionTeamAssignments() {
    this.isSubmited = true;
    this.eventService.getJudgeSectionTeamAssignments(this.eventID, this.sectionID, this.teamID).subscribe((res: any) => {
      if (!res.submittedDateTime) {
        this.isSubmited = false;
      }
    })
  }
  ngOnDestroy() {
    clearInterval(this.interval);
  }

  handleFailRequest(err, object, type, mode) {
    //mode 0: add, 1: edit, 2: delete
    //type: Score, Disqualification, Penalty
    this.warningMessage(err);
    let cachedJudgmentChanges = localStorage.getItem("judgmentChanges");
    let judgmentChanges = cachedJudgmentChanges ? JSON.parse(cachedJudgmentChanges) : [];
    let teamSectionEventChanges = _.find(judgmentChanges, (j) => {
      return j.sectionID == this.sectionID
        && j.eventID == this.eventID
        && j.teamID == this.teamID
    });
    if (!teamSectionEventChanges) {
      teamSectionEventChanges = {
        sectionID: this.sectionID,
        eventID: this.eventID,
        teamID: this.teamID,
        scores: [],
        disqualifications: [],
        penalties: []
      };
      judgmentChanges.push(teamSectionEventChanges);
    }

    if (type == "Score") {
      let cachedScore = _.find(teamSectionEventChanges.scores, (s) => {
        return s.object.subSectionID == object.subSectionID;
      });
      if (cachedScore) {
        cachedScore.object.score = object.score;
      }
      else {
        teamSectionEventChanges.scores.push({ mode: mode, object: object });
      }
    }
    else if (type == "Disqualification") {
      let cachedDis = _.find(teamSectionEventChanges.disqualifications, (s) => {
        return (s.mode == 0 || s.mode == 1) && s.object.disqualificationID == object.disqualificationID;
      });
      if (mode == 0) {
        teamSectionEventChanges.disqualifications.push({ mode: mode, object: object });
      }
      else if (mode == 1) {
        if (cachedDis) {
          cachedDis.object = object;
        } else {
          teamSectionEventChanges.disqualifications.push({ mode: mode, object: object });
        }
      }
      else if (mode == 2) {
        for (let i = 0; i < teamSectionEventChanges.disqualifications.length; i++) {
          let item = teamSectionEventChanges.disqualifications[i].object;
          if (item.disqualificationID == object.disqualificationID) {
            teamSectionEventChanges.disqualifications.splice(i, 1);
          }
        }
        if (object.id && object.id != -1) {
          teamSectionEventChanges.disqualifications.push({ mode: mode, object: object });
        }
      }
    }
    else if (type == "Penalty") {
      let cachedPen = _.find(teamSectionEventChanges.penalties, (s) => {
        return s.object.penaltyID == object.penaltyID;
      });
      if (mode == 0) {
        teamSectionEventChanges.penalties.push({ mode: mode, object: object });
      }
      else if (mode == 1) {
        if (cachedPen) {
          cachedPen.object = object;
        } else {
          teamSectionEventChanges.penalties.push({ mode: mode, object: object });
        }
      }
      else if (mode == 2) {
        for (let i = 0; i < teamSectionEventChanges.penalties.length; i++) {
          let item = teamSectionEventChanges.penalties[i].object;
          if (item.penaltyID == object.penaltyID) {
            teamSectionEventChanges.penalties.splice(i, 1);
          }
        }
        if (object.id && object.id != -1) {
          teamSectionEventChanges.penalties.push({ mode: mode, object: object });
        }
      }
    }
    localStorage.setItem("judgmentChanges", JSON.stringify(judgmentChanges));
  }

  sendCachedRequests() {
    let cachedJudgmentChanges = localStorage.getItem("judgmentChanges");
    let judgmentChanges = cachedJudgmentChanges ? JSON.parse(cachedJudgmentChanges) : [];
    let teamSectionEventChanges = _.find(judgmentChanges, (j) => {
      return j.sectionID == this.sectionID
        && j.eventID == this.eventID
        && j.teamID == this.teamID
    });
    if (teamSectionEventChanges) {
      let loading = this.pleaseWaitService.loadingScreen("Internet is available, resaving your changes...");
      this.isSavingCachedChanges = true;
      this.reupdateScores(teamSectionEventChanges.scores).then(() => {
        this.reupdatePenalties(teamSectionEventChanges.penalties).then(() => {
          this.reupdateDisqualification(teamSectionEventChanges.disqualifications).then(() => {
            NotificationService.success("All cached changes have been saved successfully");
            for (let i = 0; i < judgmentChanges.length; i++) {
              let item = judgmentChanges[i];
              if (item.eventID == this.eventID &&
                item.teamID == this.teamID &&
                item.sectionID == this.sectionID &&
                item.disqualifications.length == 0 &&
                item.penalties.length == 0 &&
                item.scores.length == 0) {
                judgmentChanges.splice(i, 1);
              }
            }
            localStorage.setItem("judgmentChanges", JSON.stringify(judgmentChanges));
            this.isSavingCachedChanges = false;
            this.pleaseWaitService.closeLoadingScreen(loading);
            this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
              this.router.navigate([`/events/${this.eventID}/teams/${this.teamID}/sections/${this.sectionID}`]);
            });
          }, (err) => {
            localStorage.setItem("judgmentChanges", JSON.stringify(judgmentChanges));
            this.isSavingCachedChanges = false;
          })
        }, (err) => {
          localStorage.setItem("judgmentChanges", JSON.stringify(judgmentChanges));
          this.isSavingCachedChanges = false;
        })
      }, (err) => {
        localStorage.setItem("judgmentChanges", JSON.stringify(judgmentChanges));
        this.isSavingCachedChanges = false;
      });
    }
  }

  reupdateScores(scores) {
    return new Promise<void>((resolve, reject) => {
      if (scores.length == 0) {
        resolve();
      }
      let score = scores[0];
      let image = score.object.score.photo ? (score.object.score.photo.indexOf("base64,") == -1 ? score.object.score.photo : score.object.score.photo.split("base64,")[1]) : null
      score.object.score.photo = image ? image : null;

      this.eventService.addEditScore(score.object).subscribe((res) => {
        scores.splice(0, 1);
        this.reupdateScores(scores).then(() => {
          resolve();
        }, () => {
          reject();
        });
      }, (err) => {
        this.warningMessage(err.status)
        reject();
      })
    })
  }

  reupdateDisqualification(disqualifications) {
    return new Promise<void>((resolve, reject) => {
      if (disqualifications.length == 0) {
        resolve();
      }
      let dis = disqualifications[0];
      let image = dis.object.photo ? (dis.object.photo.indexOf("base64,") == -1 ? dis.object.photo : dis.object.photo.split("base64,")[1]) : null
      dis.object.photo = image ? image : null;

      if (dis.mode == 0) {
        this.eventService.addTeamSectionDisqualification(dis.object).subscribe((res) => {
          disqualifications.splice(0, 1);
          this.reupdateDisqualification(disqualifications).then(() => {
            resolve();
          }, () => {
            reject();
          });
        }, (err) => {
          this.warningMessage(err.status)
          reject();
        })
      } else if (dis.mode == 1) {
        this.eventService.editTeamSectionDisqualification(dis.object).subscribe((res) => {
          disqualifications.splice(0, 1);
          this.reupdateDisqualification(disqualifications).then(() => {
            resolve();
          }, () => {
            reject();
          });
        }, (err) => {
          this.warningMessage(err.status)
          reject();
        })
      } else {
        this.eventService.deleteTeamSectionDisqualification(dis.object.id).subscribe((res) => {
          disqualifications.splice(0, 1);
          this.reupdateDisqualification(disqualifications).then(() => {
            resolve();
          }, () => {
            reject();
          });
        }, (err) => {
          this.warningMessage(err.status)
          reject();
        })
      }
    })
  }

  reupdatePenalties(penalties) {
    return new Promise<void>((resolve, reject) => {
      if (penalties.length == 0) {
        resolve();
      }
      let penalty = penalties[0];
      let image = penalty.object.photo ? (penalty.object.photo.indexOf("base64,") == -1 ? penalty.object.photo : penalty.object.photo.split("base64,")[1]) : null

      penalty.object.photo = image ? image : null;
      if (penalty.mode == 0) {
        this.eventService.addTeamSectionPenalty(penalty.object).subscribe((res) => {
          penalties.splice(0, 1);
          this.reupdatePenalties(penalties).then(() => {
            resolve();
          }, () => {
            reject();
          });
        }, (err) => {
          this.warningMessage(err.status)
          reject();
        })
      } else if (penalty.mode == 1) {
        this.eventService.editTeamSectionPenalty(penalty.object).subscribe((res) => {
          penalties.splice(0, 1);
          this.reupdatePenalties(penalties).then(() => {
            resolve();
          }, () => {
            reject();
          });
        }, (err) => {
          this.warningMessage(err.status)
          reject();
        })
      } else {
        this.eventService.deleteTeamSectionPenalty(penalty.object.id).subscribe((res) => {
          penalties.splice(0, 1);
          this.reupdatePenalties(penalties).then(() => {
            resolve();
          }, () => {
            reject();
          });
        }, (err) => {
          this.warningMessage(err.status)
          reject();
        })
      }
    })
  }

  warningMessage(status) {
    if (status == 0) {
      NotificationService.warning('No Internet Connection. Your data is temporarily saved and will be submitted when the internet connection is restored. Do not leave this page; otherwise, changes will be lost.', 10000);
    } else {
      NotificationService.warning('An unknown server error occurred. Your data is temporarily saved and will be submitted when the internet connection is restored. Do not leave this page; otherwise, changes will be lost.', 10000);
    }
  }
  handleAffterAddPenDisErorr(object, propertyID, listObject, listOption) {
    listObject.push(object);
    for (let i = 0; i < listOption.length; i++) {
      if (listOption[i].id == object[propertyID]) {
        listOption.splice(i, 1);
        break;
      }
    }
  }
  handleAfterEditSubPenDisErorr(object, listObject, propertyID) {
    for (let i = 0; i < listObject.length; i++) {
      if (listObject[i][propertyID] == object[propertyID]) {
        listObject[i] = JSON.parse(JSON.stringify(object));
      }
    }
  }
  handleAfterDeletePenDisError(object, propertyID, listObject, listOption) {
    listOption.push(object);
    for (let i = 0; i < listObject.length; i++) {
      if (listObject[i][propertyID] == object[propertyID]) {
        listObject.splice(i, 1);
        break;
      }
    }
  }
  checkScore(value, obj) {
    let arrInt = [5, 50, 25, 75];
    let parts = value.split('.');
    if (parts.length > 1) {
      let splitStr = parts[1];
      if (splitStr) {
        let isValid = _.indexOf(arrInt, parseInt(splitStr))
        if (isValid >= 0) {
          obj.isScoreValid = true;
        } else {
          obj.isScoreValid = false;
        }
      }
    }
    else {
      obj.isScoreValid = true;
    }
  }

  getJudgeSectionAssignments() {
    return new Promise<void>((resolve, reject) => {
      this.eventService.getJudgeSectionAssignmentByJudgeUserID(this.eventID, this.sectionID, ((this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id)).subscribe((res: any) => {
        if (res) {
          if (!res.submittedDateTime) {
            this.isLocked = false;
          } else {
            this.isLocked = !this.isAdmin;
          }
        } else {
          this.isLocked = false;
        }
        resolve()
      });
    })
  }

  updateGeneralComment(item) {
    let sectionTemp = JSON.parse(JSON.stringify(item));
    sectionTemp.judgeUserID = (this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id;
    this.eventService.addUpdateJudgeSectionComment(sectionTemp).subscribe(result => {
      this.getTeamSectionDetail(this.eventID, this.sectionID, this.teamID, sectionTemp.judgeUserID).then(res => {
        //console.log("Finished doAddUpdateJudgeSectionTimeInOut and getTeamSectionDetail:");
        //console.log(res);
        this.doGetDataInit(res);
      });
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
      console.log(err);
    })
  }

  checkValueDatetime(item, mode) {
    // mode = 0: time in change
    // mode = 1: time out change
    setTimeout(() => {
      if (!this.isLocked) {
        if (!item.timeIn && !item.timeOut) {
          item.isInvalid = false;
        } else {
          let bkTeamSection = this.bkTeamSectionDetail;
          if ((!item.timeOut && bkTeamSection.timeOut) || (!item.timeIn && bkTeamSection.timeIn)) {
            item.isInvalid = true;
          } else {
            item.isInvalid = false;
            item.isSoonerTimeIn = this.doCheckDatetime(item.timeIn, item.timeOut);
            if (!item.isSoonerTimeIn) {
              this.compareToBackUpSection(item, mode, bkTeamSection);
            } else {
              if (mode == 1 && !bkTeamSection.timeOut) {
                if (item.timeIn && item.timeOut) {
                  let isSoonerTimeIn = this.doCheckDatetime(item.timeIn, item.timeOut)
                  if (isSoonerTimeIn) {
                    let timeOut = new Date(item.timeOut);
                    item.timeOut.setHours(timeOut.getHours() + 12);
                  } else {
                    this.compareToBackUpSection(item, mode, bkTeamSection);
                  }
                }
              }
              if (!bkTeamSection.timeOut) {
                item.isSoonerTimeIn = false;
                this.addUpdateJudgeSectionTimeInOut(item, mode);
              } else {
                this.compareToBackUpSection(item, mode, bkTeamSection);
              }
            }
          }
        }
      }
    })
  }

  compareToBackUpSection(item, mode, bkTeamSection) {
    if (!bkTeamSection.timeIn && item.timeIn) {
      this.addUpdateJudgeSectionTimeInOut(item, mode);
    } else {
      if (mode == 0) {
        this.compareDatetime(item, mode, bkTeamSection);
      }
      if (mode == 1) {
        if (!bkTeamSection.timeOut && item.timeOut) {
          this.addUpdateJudgeSectionTimeInOut(item, mode);
        } else {
          this.compareDatetime(item, mode, bkTeamSection);
        }
      }
    }
  }

  compareDatetime(item, mode, bkTeamSection) {
    let timeChange = mode == 0 ? item.timeIn : item.timeOut;
    let bkTime = mode == 0 ? bkTeamSection.timeIn : bkTeamSection.timeOut;
    let compareTime = this.doCompareDatetime(timeChange, bkTime);
    if (compareTime) {
      let checkTime = this.doCheckDatetime(item.timeIn, item.timeOut);
      item.isSoonerTimeIn = checkTime;
      if (!checkTime) {
        this.addUpdateJudgeSectionTimeInOut(item, mode);
      }
    }
  }

  doCompareDatetime(timeModelChange, timeBackUp) {
    let time = new Date(timeModelChange);
    let bkTime = new Date(timeBackUp);
    if (time.getHours() == bkTime.getHours() && time.getMinutes() == bkTime.getMinutes()) {
      return false;
    }
    return true;
  }

  doCheckDatetime(timeIn, timeOut) {
    let inTime = new Date(timeIn);
    let outTime = timeOut ? new Date(timeOut) : null;
    if (timeIn || timeOut) {
      if (!timeIn || (timeOut && !timeIn)) {
        return true;
      } else {
        if (timeOut && timeIn) {
          if (inTime.getHours() > outTime.getHours() || (inTime.getHours() == outTime.getHours() && inTime.getMinutes() >= outTime.getMinutes())) {
            return true;
          }
          return false;
        } else {
          return false;
        }
      }
    }
  }

  addUpdateJudgeSectionTimeInOut(item, mode) {
    mode == 0 ? item.isAddUpdateTimeIn = true : item.isAddUpdateTimeOut = true;
    let sectionTemp = JSON.parse(JSON.stringify(item));
    sectionTemp.judgeUserID = (this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id;
    if (sectionTemp.timeOut) {
      sectionTemp.timeOut = this.handleDate(sectionTemp.timeOut, sectionTemp.timeOut);
    } else {
      delete sectionTemp.timeOut;
    }
    sectionTemp.timeIn = this.handleDate(sectionTemp.timeIn, sectionTemp.timeIn);
    this.doAddUpdateJudgeSectionTimeInOut(sectionTemp, item);
  }

  doAddUpdateJudgeSectionTimeInOut(sectionTemp, item) {
    this.eventService.addUpdateJudgeSectionTimeInOut(sectionTemp).subscribe(result => {
      item.isAddUpdateTimeIn = false;
      item.isAddUpdateTimeOut = false;
      this.getTeamSectionDetail(this.eventID, this.sectionID, this.teamID, sectionTemp.judgeUserID).then(res => {
        //console.log("Finished doAddUpdateJudgeSectionTimeInOut and getTeamSectionDetail:");
        //console.log(res);
        this.doGetDataInit(res);
      });
    }, (err) => {
      item.isAddUpdateTimeIn = false;
      item.isAddUpdateTimeOut = false;
      NotificationService.error('An unknown server error occurred.');
    })
  }

  handleDate(date, startTime) {
    let d = new Date();
    let date2 = new Date(date);
    let startTime2 = new Date(startTime);
    d.setFullYear(date2.getFullYear(), date2.getMonth(), date2.getDate());
    d.setHours(startTime2.getHours());
    d.setMinutes(startTime2.getMinutes());
    d.setSeconds(0);
    d.setMilliseconds(0);
    return this.adjustForTimezone(d);
  }

  adjustForTimezone(date: Date): Date {
    let timeOffsetInMS: number = date.getTimezoneOffset() * 60000;
    date.setTime(date.getTime() - timeOffsetInMS);
    return date;
  }
  getNextPreviousTeamID() {
    this.eventService.getNextPreviousTeamID(this.eventID, this.sectionID, this.teamSectionDetail.categoryID, this.teamID).subscribe(result => {
      this.nextPreviousTeamID = result;
    })
  }
  nextPreviousTeam(teamID) {
    if (this.role === 'U')
      this.router.navigate(['/events', this.eventID, 'teams', teamID, 'sections', this.sectionID]);
    else
      this.router.navigate(['/events', this.eventID, 'teams', teamID, 'sections', this.sectionID], { queryParams: { judgeid: this.judgeID, role: this.role } });
  }

  loadSubsection(subSectionID) {
    this.cancelAddEditSub();
    const sub = this.subSections.filter((obj) => obj.subSectionID === subSectionID);
    this.score(sub[0]);
  }

  clearTimeInTimeOut(item) {
    item.isInvalid = false;
    if (!this.isLocked) {
      item.timeIn = void 0;
      item.timeOut = void 0;
      let sectionTemp = JSON.parse(JSON.stringify(item));
      sectionTemp.judgeUserID = (this.isAdmin || this.isLeadJudge) ? this.judgeID : this.userInfo.id;
      this.doAddUpdateJudgeSectionTimeInOut(sectionTemp, item);
    }
  }
}
