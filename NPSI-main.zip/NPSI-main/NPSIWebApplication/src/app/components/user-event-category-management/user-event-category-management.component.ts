import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventService } from 'src/app/service/event.service';

@Component({
  selector: 'app-user-event-category-management',
  templateUrl: './user-event-category-management.component.html',
  styleUrls: ['./user-event-category-management.component.css']
})
export class UserEventCategoryManagementComponent implements OnInit {
  @Input("categoryID") categoryID;
  @Input("judgeID") judgeID;
  @Input("isLeadJudge") isLeadJudge;
  @Output("isNoDataManagement") isNoDataManagement = new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
  }
  isNoData(value) {
    this.isNoDataManagement.emit(value);
  }
}
