import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserEventCategoryCulinaryComponent } from './user-event-category-culinary.component';

describe('UserEventCategoryCulinaryComponent', () => {
  let component: UserEventCategoryCulinaryComponent;
  let fixture: ComponentFixture<UserEventCategoryCulinaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserEventCategoryCulinaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserEventCategoryCulinaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
