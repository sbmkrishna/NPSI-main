import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventService } from 'src/app/service/event.service';

@Component({
  selector: 'app-user-event-category-culinary',
  templateUrl: './user-event-category-culinary.component.html',
  styleUrls: ['./user-event-category-culinary.component.css']
})
export class UserEventCategoryCulinaryComponent implements OnInit {
  @Input("categoryID") categoryID;
  @Input("judgeID") judgeID;
  @Input("isLeadJudge") isLeadJudge;
  @Output("isNoDataCulinary") isNoDataCulinary = new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
  }

  isNoData(value) {
    this.isNoDataCulinary.emit(value);
  }
}
