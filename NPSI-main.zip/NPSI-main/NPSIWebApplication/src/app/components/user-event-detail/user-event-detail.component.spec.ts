import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserEventDetailComponent } from './user-event-detail.component';

describe('UserEventDetailComponent', () => {
  let component: UserEventDetailComponent;
  let fixture: ComponentFixture<UserEventDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserEventDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserEventDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
