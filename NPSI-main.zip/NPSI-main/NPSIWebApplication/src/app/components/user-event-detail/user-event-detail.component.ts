import { Component, OnInit, ViewChild } from '@angular/core';
import { EventService } from '../../service/event.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TabDirective, TabsetComponent } from 'ngx-bootstrap/tabs';
import { NotificationService } from 'src/app/service/notification.service';
import { UserService } from '../../service/user.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-user-event-detail',
  templateUrl: './user-event-detail.component.html',
  styleUrls: ['./user-event-detail.component.css']
})
export class UserEventDetailComponent implements OnInit {
  @ViewChild('staticTabs', { static: false }) staticTabs: TabsetComponent;
  eventID: any;
  categories: any;
  categoryManagementID: any;
  categoryCulinaryID: any;
  isLeadJudge: any;
  event: any;
  isLeadJudgeCulinary: any;
  isLeadJudgeManagement: any;
  // isHasSubsection: boolean;
  isNoDatasManagement: boolean = null;
  isNoDatasCulinary: boolean = null;
  isLoadingCategoryData: boolean = true;
  judgeID: any = null;
  judge: any;
  backLinkCode: any;

  constructor(private eventService: EventService,
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private router: Router) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
      if (params.judgeID) {
        this.judgeID = params.judgeID;
        this.userService.getUserDetail(this.judgeID).subscribe((res) => {
          this.judge = res[0];
        }, (err) => {
          NotificationService.error('An unknown server error occurred.')
        })
      }
      //console.log(`JudgeID: ${this.judgeID}`);
    })
    if (this.eventID) {
      if (this.judgeID) {
        // admin or lead judge requesting to impersonate judge
        this.eventService.checkPermissionUserEventDetail(this.eventID, this.judgeID).subscribe((res: any) => {
          if (res.length == 0) {
            this.router.navigate(['/judge-dashboard']);
          } else {
            this.backLinkCode = "A";
            res.forEach((item) => {
              // no need to mark for lead judge, just set correct ID
              if (item.name === 'Management') this.categoryManagementID = item.id;
              if (item.name === 'Culinary') this.categoryCulinaryID = item.id;
              this.checkLeadJudge(this.eventID, item.id).then(res => {
                if (res) this.backLinkCode = "L";
              });
            })
            this.getEventDetail();
          }
          this.categories = res;
        })
      }
      else {
        // category judge or lead judge loading ther own stuff
        this.eventService.checkPermissionUserEventDetail(this.eventID).subscribe((res: any) => {
          if (res.length == 0) {
            this.router.navigate(['/judge-dashboard']);
          } else {
            this.backLinkCode = "U";
            res.forEach((item) => {
              if (item.name == 'Management') {
                this.checkLeadJudge(this.eventID, item.id).then(res => {
                  //console.log(`After mgmt CheckLeadJudge: ${res}`);
                  this.isLeadJudgeManagement = res;
                });
                this.categoryManagementID = item.id;
              } else if (item.name == 'Culinary') {
                this.checkLeadJudge(this.eventID, item.id).then(res => {
                  //console.log(`After cul CheckLeadJudge: ${res}`);
                  this.isLeadJudgeCulinary = res;
                });
                this.categoryCulinaryID = item.id;
              }
            })
            this.getEventDetail();
            // this.checkSubsectionJudge()
          }
          this.categories = res;
        })
      }
    }
  }

  getEventDetail() {
    this.eventService.getEventDetail(this.eventID).subscribe((res) => {
      console.log('res :', res);
      res = _.orderBy(res, ['sortOrder'], ['asc']);
      this.event = res;
      console.log(`backLinkCode: ${this.backLinkCode}`);
    }, (err) => {
      NotificationService.error('An unknown server error occurred.');
    })
  }
  checkLeadJudge(eventID, categoryID) {
    return new Promise(resolve => {
      this.eventService.checkLeadJudge(eventID, categoryID).subscribe((res) => {
        resolve(res);
      }, (err) => {
        NotificationService.error('An unknown server error occurred.');
      })
    })
  }

  // checkSubsectionJudge() {
  //   this.isChecking = true;
  //   this.eventService.checkSubsectionJudge(this.eventID).subscribe((result: any) => {
  //     this.isChecking = false;
  //     if (result && result.subsections > 0 && result.sections > 0) {
  //       this.isHasSubsection = true;
  //     }
  //     if (!result || (result && result.sections <= 0 || (result.sections > 0 && result.subsections <= 0))) {
  //       this.isHasSubsection = false;
  //     }
  //   })
  // }
  isNoDataManagement(value) {
    this.isNoDatasManagement = value;
    if (this.categoryCulinaryID == null || this.isNoDatasCulinary != null) {
      this.isLoadingCategoryData = false;
    }
  }
  isNoDataCulinary(value) {
    this.isNoDatasCulinary = value;
    if (this.categoryManagementID == null || this.isNoDatasManagement != null) {
      this.isLoadingCategoryData = false;
    }
  }
}
