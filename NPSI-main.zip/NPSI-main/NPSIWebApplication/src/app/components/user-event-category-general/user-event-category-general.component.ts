import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EventService } from '../../service/event.service';
import Swal from 'sweetalert2';
import * as _ from 'lodash';
import { NotificationService } from 'src/app/service/notification.service';
import { min } from 'rxjs/operators';
@Component({
  selector: 'app-user-event-category-general',
  templateUrl: './user-event-category-general.component.html',
  styleUrls: ['./user-event-category-general.component.css']
})
export class UserEventCategoryGeneralComponent implements OnInit {
  @Input("categoryID") categoryID;
  @Input("judgeID") judgeID = null;
  @Input("isLeadJudge") isLeadJudge;
  @Output("isNoData") isNoData = new EventEmitter<any>()
  eventID: any;
  sections: any;
  teams: any;
  sectionID: any;
  judgeSectionAssignment: any;
  bkSections: any;
  judgeUserId: any;

  constructor(
    private eventService: EventService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.eventID = params.eventID;
      if (this.judgeID) {
        this.judgeUserId = this.judgeID
      } else {
        const localUser = JSON.parse(localStorage.getItem("userInfo"));
        this.judgeUserId = localUser.id;
      }
      if (this.eventID) {
        this.getSectionUserByEventandCategory();
      }
    })
  }
  getSectionUserByEventandCategory() {
    this.eventService.getSectionUserByEventandCategory(this.eventID, this.categoryID, this.judgeUserId).subscribe((res) => {
      this.sections = res;
      this.sections = _.orderBy(this.sections, ['startTime'], ['asc']);
      for (let i = 0; i < this.sections.length; i++) {
        let section = this.sections[i];
        section.expanded = true;
        let isValidScore = true;
        for (let j = 0; j < section.teams.length; j++) {
          let team = section.teams[j];
          team.expanded = false;
          for (let t = 0; t < team.subsectionScore.length; t++) {
            let subsectionScore = team.subsectionScore[t];
            if (subsectionScore.score && subsectionScore.score.score && subsectionScore.score.comments) {
              if (subsectionScore.score.score >= 0 && subsectionScore.score.comments !== null) {
                if (section.timeInOutNeeded) {
                  if (team.timeIn && team.timeOut){
                    isValidScore = true;
                  } else {
                    isValidScore = false;
                    break;
                  }
                } else {
                  isValidScore = true;
                }
              } else {
                isValidScore = false;
                break;
              }
            } else {
              isValidScore = false;
              break;
            }
            subsectionScore = _.orderBy(subsectionScore, ['sortIndex'], ['asc']);
          }
          team.isUpdateTimeInOut = section.submittedDateTime ? true : false;
          team.subsectionScore = _.orderBy(team.subsectionScore, [(resultItem) => { return (resultItem.sortIndex == 0 || resultItem.sortIndex == null) ? 999 : resultItem.sortIndex; }, 'sortIndex'], ['asc']);
          if (!isValidScore) {
            break;
          }
        }
        section.validSubmitScore = isValidScore;
      }
      this.sections = _.orderBy(this.sections, ['sortOrder'], ['asc']);
      this.bkSections = JSON.parse(JSON.stringify(this.sections));
      if (this.sections.length == 0) {
        this.isNoData.emit(true);
      } else {
        this.isNoData.emit(false);
      }
    })
  }
  submitScore(sectionID) {
    NotificationService.confirm('This cannot be undone. Are you sure you want to submit all the scores for this section?').then((result) => {
      if (result.value) {
        this.eventService.submitScore(this.eventID, sectionID, this.categoryID).subscribe((res) => {
          this.getSectionUserByEventandCategory();
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Submit score successfully.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          })
        }, (err) => {
          Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: 'An unknown server error occurred.',
            showConfirmButton: false,
            timer: 3000,
            toast: true
          })
        })
      }
    })
  }

  navigateToTeam(teamId, sectionId) {
    setTimeout(() => {
      if (this.judgeID) {
        this.router.navigate(['/events', this.eventID, 'teams', teamId, 'sections', sectionId], { queryParams: { judgeid: this.judgeID, role: 'I' } });
      } else {
        this.router.navigate(['/events', this.eventID, 'teams', teamId, 'sections', sectionId]);
      }
    })
  }
}
