import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserEventCategoryGeneralComponent } from './user-event-category-general.component';

describe('UserEventCategoryGeneralComponent', () => {
  let component: UserEventCategoryGeneralComponent;
  let fixture: ComponentFixture<UserEventCategoryGeneralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserEventCategoryGeneralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserEventCategoryGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
