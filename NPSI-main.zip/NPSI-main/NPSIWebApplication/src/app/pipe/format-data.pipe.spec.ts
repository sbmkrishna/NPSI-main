import { FormatDataPipe } from './format-data.pipe';

describe('FormatDataPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatDataPipe();
    expect(pipe).toBeTruthy();
  });
});
