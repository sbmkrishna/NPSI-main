import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatData'
})
export class FormatDataPipe implements PipeTransform {

  transform(value: any, ...args: any): any {
    if (value.length <= 200) {
      return value;
    }
    else {
      return value.substr(0, args) + '...';
    }
  }

}
