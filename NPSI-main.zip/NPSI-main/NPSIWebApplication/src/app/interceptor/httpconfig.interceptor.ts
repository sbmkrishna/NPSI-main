import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';
import { takeUntil } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { AccountService } from '../service/account.service';
import { HttpCancelService } from '../service/http-cancel.service';
import Swal from 'sweetalert2';
@Injectable()
export class HttpConfigInterceptor implements HttpInterceptor {
  constructor(private httpCancelService: HttpCancelService,
    private accountService: AccountService) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token: string = localStorage.getItem('authorizationToken');
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    return next.handle(request).pipe(
      takeUntil(this.httpCancelService.onCancelPendingRequests()),
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          // this.errorDialogService.openDialog(event);
        }
        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        if (error.status == 401) {
          Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: "Your token expired. Please login again.",
            showConfirmButton: false,
            timer: 3000,
            toast: true
          });
          this.accountService.logOut();
        }
        else {
          return throwError(error);
        }

      }));
  }
}
