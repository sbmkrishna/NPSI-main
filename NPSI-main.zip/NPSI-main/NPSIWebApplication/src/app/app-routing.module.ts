import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './components/layout/layout.component';
import { AuthGuardService } from './service/auth-guard.service';
import { LoginComponent } from './components/login/login.component';
import { SectionDetailComponent } from './components/admin/sections/section-detail/section-detail.component';
import { AdminComponent } from './components/admin/admin.component';
import { SectionComponent } from './components/admin/sections/section/section.component';
import { SubsectionComponent } from './components/admin/subsection/subsection.component';
import { PenaltyComponent } from './components/admin/penalty/penalty.component';
import { DisqualificationsComponent } from './components/admin/disqualifications/disqualifications.component';
import { ManageTeamComponent } from './components/admin/manage-team/manage-team.component';
import { EventComponent } from './components/admin/event/event.component';
import { EventDetailComponent } from './components/admin/event-detail/event-detail.component';
import { ManageUserComponent } from './components/admin/manage-user/manage-user.component';
import { EventRunComponent } from './components/admin/event-run/event-run.component';
import { UserComponent } from './components/user/user.component';
import { UserEventDetailComponent } from './components/user-event-detail/user-event-detail.component';
import { UserTeamSectionDetailComponent } from './components/user-team-section-detail/user-team-section-detail.component';
import { EventAdminDashboardComponent } from './components/event-admin-dashboard/event-admin-dashboard.component';
import { JudgeHistoryComponent } from './components/admin/judge-history/judge-history.component';
import { JudgeHistoryScoreComponent } from './components/admin/judge-history-score/judge-history-score.component';
import { AddSectionComponent } from './components/admin/sections/add-section/add-section.component';
import { ReportComponent } from './components/admin/report/report.component';

const routes: Routes = [
  { path: '', redirectTo: 'admin', pathMatch: 'full', canActivate: [AuthGuardService], },
  {
    path: 'admin',
    component: AdminComponent,
    children: [
      { path: '', redirectTo: 'events', pathMatch: 'full', canActivate: [AuthGuardService], },
      { path: "sections/add", component: AddSectionComponent, canActivate: [AuthGuardService] },
      { path: "sections/:sectionID", component: SectionDetailComponent, canActivate: [AuthGuardService] },
      { path: "sections", component: SectionComponent, canActivate: [AuthGuardService] },
      { path: "penalties", component: PenaltyComponent, canActivate: [AuthGuardService] },
      { path: "disqualifications", component: DisqualificationsComponent, canActivate: [AuthGuardService] },
      { path: "teams", component: ManageTeamComponent, canActivate: [AuthGuardService] },
      { path: "events", component: EventComponent, canActivate: [AuthGuardService] },
      { path: "events/:eventID", component: EventDetailComponent, canActivate: [AuthGuardService] },
      { path: "judgehistory/:judgeID", component: JudgeHistoryComponent, canActivate: [AuthGuardService] },
      { path: "judgescore/:judgeID/event/:eventID/section/:sectionID", component: JudgeHistoryScoreComponent, canActivate: [AuthGuardService] },
      { path: "users", component: ManageUserComponent, canActivate: [AuthGuardService] },
      { path: "events/:eventID/run", component: EventRunComponent, canActivate: [AuthGuardService] },
      { path: "events/:eventID/teams/:teamID/sections/:sectionID", component: UserTeamSectionDetailComponent, canActivate: [AuthGuardService] },
      { path: "report", component: ReportComponent, canActivate: [AuthGuardService] },
    ]
  },
  { path: "judge-dashboard", component: UserComponent, canActivate: [AuthGuardService] },
  { path: "events/:eventID", component: UserEventDetailComponent, canActivate: [AuthGuardService] },
  { path: "events/:eventID/judge/:judgeID", component: UserEventDetailComponent, canActivate: [AuthGuardService] },
  { path: "events/:eventID/teams/:teamID/sections/:sectionID", component: UserTeamSectionDetailComponent, canActivate: [AuthGuardService] },
  { path: "login", component: LoginComponent },
  {
    path: "event-admin-dashboard",
    component: EventAdminDashboardComponent,
    canActivate: [AuthGuardService],
    children: [
      { path: '', redirectTo: 'events', pathMatch: 'full', canActivate: [AuthGuardService], },
      { path: "events", component: EventComponent, canActivate: [AuthGuardService] },
      { path: "teams", component: ManageTeamComponent, canActivate: [AuthGuardService] },
      { path: "users", component: ManageUserComponent, canActivate: [AuthGuardService] },
      { path: "events/:eventID/run", component: EventRunComponent, canActivate: [AuthGuardService] },
      { path: "events/:eventID", component: EventDetailComponent, canActivate: [AuthGuardService] },
    ]
  },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
