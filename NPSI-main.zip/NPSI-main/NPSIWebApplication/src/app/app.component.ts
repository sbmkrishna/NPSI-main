import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from './service/account.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'NPSIWebApplication';
  isLogin: boolean = false;
  user: any;
  token: any;
  loadingUserInfo: boolean = false;
  dateModel: Date ;
  constructor(private accountService: AccountService, private router: Router) { }
  ngOnInit() {
    this.accountService.onLogIn.subscribe(res => {
      this.isLogin = true;
      if (res == false) {
        let token = localStorage.getItem("authorizationToken");
        let userInfo = localStorage.getItem("userInfo");
        this.user = userInfo;
        if (!token && !userInfo) {
          this.isLogin = false;
          this.router.navigate(['/login']);
        }
      }
      if (res == true) {
        this.loadingUserInfo = true;
        this.accountService.getUserInfo().subscribe((r: any) => {
          this.user = r
          localStorage.setItem("userInfo", JSON.stringify(r));
          if (r.isSuperAdmin) {
            this.router.navigate(['/admin']);
          } else if (r.roles && r.roles.indexOf("Event - Admin") != -1) {
            this.router.navigate(['/event-admin-dashboard']);
          } else {
            this.router.navigate(['/judge-dashboard']);
          }
          this.loadingUserInfo = false;
        })
      }
    })
  }
}
