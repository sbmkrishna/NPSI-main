import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PositiveIntegerInputDirective } from './directives/positive-integer-input.directive';
import { PositiveDecimalInputDirective } from './directives/positive-decimal-input.directive';
import { CurrencyInputDirective } from './directives/currency-input.directive';


@NgModule({
  declarations: [
    PositiveIntegerInputDirective,
    PositiveDecimalInputDirective,
    CurrencyInputDirective],
  imports: [
    CommonModule
  ],
  exports: [
    PositiveIntegerInputDirective,
    PositiveDecimalInputDirective,
    CurrencyInputDirective
  ]
})
export class ShareModule { }
