import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient, private _router: Router) { }
  header() {
    let headers = new HttpHeaders();
    // let token = localStorage.getItem('authorizationToken');
    // if (token) {
    //   token = token.slice(1,token.length-1);
    //   headers = headers.append('Authorization', 'Bearer ' + token);
    // }
    return headers;
  }
  httpOptionsWithoutContentType = {
    headers: new HttpHeaders({

    }),
    withCredentials: true
  }
  get(url, param: any = null) {
    let headers = this.header();
    let params = new HttpParams();
    //this.createAuthorizationHeader(headers);
    return this.http.get(url, { headers: headers, params: param });
  }
  post(url, data) {
    let headers = this.header();
    return this.http.post(url, data, { headers: headers });
  }
  put(url, data) {
    let headers = this.header();
    return this.http.put(url, data, { headers: headers });
  }
  delete(url) {
    let headers = this.header();
    return this.http.delete(url, { headers: headers })
  }
  postFile(url, data) {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      // withCredentials: true,

      // Ignore this part or  if you want full response you have 
      // to explicitly give as 'boby'as http client by default give res.json()
      observe: 'response' as 'body',

      // have to explicitly give as 'blob' or 'json'
      responseType: 'blob' as 'blob'
    };
    return this.http.post(url, data, options);
  }
}
