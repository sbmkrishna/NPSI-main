import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DisqualificationService {
  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  getDisqualification() {
    let url = this.api_url + 'disqualification/getdisqualification';
    return this.httpService.get(url);
  }
  createDisqualification(object) {
    let url = this.api_url + 'disqualification/createdisqualification';
    return this.httpService.post(url, object);
  }
  editDisqualification(object) {
    let url = this.api_url + 'disqualification/editdisqualification';
    return this.httpService.put(url, object);
  }
  getDisqualificationActive() {
    let url = this.api_url + 'disqualification/getDisqualificationActive';
    return this.httpService.get(url);
  }
  deleteDisqualification(disqualificationID) {
    let url = this.api_url + 'disqualification/deleteDisqualification/' + disqualificationID;
    return this.httpService.delete(url);
  }
}
