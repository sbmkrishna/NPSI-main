import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class PenaltyService {
  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  getPenalty() {
    let url = this.api_url + 'penalty/getPenalty';
    return this.httpService.get(url);
  }
  createPenalty(object) {
    let url = this.api_url + 'penalty/createPenalty';
    return this.httpService.post(url, object);
  }
  editPenalty(object) {
    let url = this.api_url + 'penalty/editPenalty';
    return this.httpService.put(url, object);
  }
  getPenaltiesActive() {
    let url = this.api_url + 'penalty/getPenaltyActive';
    return this.httpService.get(url);
  }
  deletePenalty(penaltyID) {
    let url = this.api_url + 'penalty/deletePenalty/' + penaltyID;
    return this.httpService.delete(url);
  }
}
