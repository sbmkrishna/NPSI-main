import { Injectable } from '@angular/core';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

    constructor() { }

    static success(message){
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: message,
            showConfirmButton: false,
            timer: 7000,
            toast: true
        });
    }

    static warning(message, duration = 7000) {
        Swal.fire({
            position: 'top-end',
            icon: 'warning',
            title: message,
            showConfirmButton: false,
            timer: duration,
            toast: true
        })
    }

    static error(message) {
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: message,
            showConfirmButton: false,
            timer: 7000,
            toast: true
        })
    }

    static confirm(message, title?, confirmBtn?, cancleBtn?) {
        return Swal.fire({
            title: title ? title : 'Are you sure?',
            text: message,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: confirmBtn ? confirmBtn : "Confirm",
            cancelButtonText: cancleBtn ? cancleBtn : "Cancel"
        })
    }

}
