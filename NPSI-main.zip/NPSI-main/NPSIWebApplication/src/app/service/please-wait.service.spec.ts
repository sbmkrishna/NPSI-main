import { TestBed } from '@angular/core/testing';

import { PleaseWaitService } from './please-wait.service';

describe('PleaseWaitService', () => {
  let service: PleaseWaitService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PleaseWaitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
