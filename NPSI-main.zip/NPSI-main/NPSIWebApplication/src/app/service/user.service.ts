import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpService } from './http.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  getRolesJudgesLeadJudge() {
    let url = this.api_url + "user/getRolesJudgesLeadJudge";
    return this.httpService.get(url);
  }
  getAllUser() {
    let url = this.api_url + "user/getAllUser";
    return this.httpService.get(url);
  }
  searchUser(object) {
    let url = this.api_url + "user/searchUser";
    return this.httpService.post(url, object);
  }
  createUser(object) {
    let url = this.api_url + "account/createUser";
    return this.httpService.post(url, object);
  }
  editUser(object) {
    let url = this.api_url + "account/editUser";
    return this.httpService.put(url, object);
  }
  unlockUser(id) {
    let url = this.api_url + `user/unlockUser/${id}`;
    return this.httpService.post(url, null);
  }
  resetPassword(object) {
    let url = this.api_url + `user/resetPassword`;
    return this.httpService.post(url, object);
  }
  getJudgeHistory(id) {
    let url = this.api_url + `user/judgeHistory/${id}`;
    return this.httpService.post(url, null);
  }
  searchScoreHistory(object) {
    let url = this.api_url + "user/judgeScoring";
    return this.httpService.post(url, object);
  }
  getUserDetail(userId) {
    let url = this.api_url + `user/getUserDetail/${userId}`;
    return this.httpService.get(url);
  }
}
