import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { HttpService } from './http.service';
import { report } from 'process';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  searchEvent(object) {
    let url = this.api_url + "event/searchEvent";
    return this.httpService.post(url, object);
  }
  createEvent(object) {
    let url = this.api_url + "event/createEvent";
    return this.httpService.post(url, object);
  }
  editEvent(object) {
    let url = this.api_url + "event/editEvent";
    return this.httpService.put(url, object);
  }
  getEventStatus() {
    let url = this.api_url + "event/getEventStatus";
    return this.httpService.get(url)
  }
  startEvent(id) {
    let url = this.api_url + `event/startEvent/${id}`;
    return this.httpService.post(url, null);
  }
  getEventDetail(id) {
    let url = this.api_url + `event/getEventDetail/${id}`;
    return this.httpService.get(url);
  }
  getEventSection(id, categoryId) {
    let url = this.api_url + `event/getEventSection/${id}/category/${categoryId}`;
    return this.httpService.get(url);
  }
  getEventUser(id, categoryId) {
    let url = this.api_url + `event/getEventUser/${id}/category/${categoryId}`;
    return this.httpService.get(url);
  }
  getEventJudges(id, categoryId) {
    let url = this.api_url + `event/getEventJudges/${id}/category/${categoryId}`;
    return this.httpService.get(url);
  }
  getEventTeam(id, categoryId) {
    let url = this.api_url + `event/getEventTeam/${id}/category/${categoryId}`;
    return this.httpService.get(url);
  }
  addEventSection(object) {
    let url = this.api_url + `event/addEventSection`;
    return this.httpService.post(url, object);
  }
  addJudgeEventSection(object) {
    let url = this.api_url + `event/addJudgeEventSection`;
    return this.httpService.post(url, object);
  }
  deleteJudgeEventSection(object) {
    let url = this.api_url + `event/deleteJudgeEventSection`;
    return this.httpService.post(url, object);
  }
  deleteEventSection(eventID, sectionID) {
    let url = this.api_url + `event/deleteEventSection/${eventID}/${sectionID}`;
    return this.httpService.delete(url);
  }
  addEventTeam(eventID, object) {
    let url = this.api_url + `event/addEventTeam/${eventID}`;
    return this.httpService.post(url, object);
  }
  deleteEventTeam(eventID, teamID) {
    let url = this.api_url + `event/deleteEventTeam/${eventID}/${teamID}`;
    return this.httpService.delete(url);
  }
  addEventUser(object) {
    let url = this.api_url + `event/addEventUser`;
    return this.httpService.post(url, object);
  }
  deleteUserEvent(eventID, userID, categoryID) {
    var object = {
      eventID,
      userID,
      categoryID
    }
    let url = this.api_url + `event/deleteEventUser`;
    return this.httpService.post(url, object);
  }
  getEventCategoryPenalties(eventID, categoryID) {
    let url = this.api_url + `event/getEventCategoryPenalties/${eventID}/${categoryID}`;
    return this.httpService.get(url);
  }
  getEventRun(eventID, categoryID) {
    let url = this.api_url + `event/getEventRun/${eventID}/${categoryID}`;
    return this.httpService.get(url);
  }
  getEventStartedByUserID() {
    let url = this.api_url + `event/getEventStartedByUserID`;
    return this.httpService.get(url);
  }
  getEventActiveByUserID() {
    let url = this.api_url + `event/getEventActiveByUserID`;
    return this.httpService.get(url);
  }
  getEventCompleteByUserID() {
    let url = this.api_url + `event/getEventCompleteByUserID`;
    return this.httpService.get(url);
  }
  checkPermissionUserEventDetail(id, judgeId = null) {
    let url = this.api_url + `event/checkPermissionUserEventDetail/${id}`;
    if (judgeId !== null) url += `/${judgeId}`;
    return this.httpService.get(url);
  }
  getSectionUserByEventandCategory(eventID, categoryID, judgeID = null) {
    let url = this.api_url + `event/getSectionUserByEventandCategory/${eventID}/${categoryID}`;
    if (judgeID !== null) url += `?judgeID=${judgeID}`;
    return this.httpService.get(url);
  }
  getUserEventTeamBySection(eventID, categoryID, sectionID) {
    let url = this.api_url + `event/getUserEventTeamBySection/${eventID}/category/${categoryID}/section/${sectionID}`;
    return this.httpService.get(url);
  }
  getSubsectionByEventSectionAndTeam(eventID, sectionID, teamID, judgeID = null, categoryID) {
    let url = this.api_url + `event/getSubsectionByEventSectionAndTeam/${eventID}/${sectionID}/${teamID}?categoryID=${categoryID}`;
    if (judgeID != null) {
      url = url + `&judgeID=${judgeID}`
    }
    return this.httpService.get(url);
  }
  getTeamSectionPenalties(eventID, sectionID, teamID, judgeID = null) {
    let url = this.api_url + `event/getTeamSectionPenalties/${eventID}/${sectionID}/${teamID}?judgeID=${judgeID}`;
    return this.httpService.get(url);
  }
  getTeamSectionDisqualification(eventID, sectionID, teamID, judgeID = null) {
    let url = this.api_url + `event/getTeamSectionDisqualification/${eventID}/${sectionID}/${teamID}?judgeID=${judgeID}`;
    return this.httpService.get(url);
  }
  getEventSectionPenalty(eventID, sectionID, teamID) {
    let url = this.api_url + `event/getEventSectionPenalty/${eventID}/${sectionID}/${teamID}`;
    return this.httpService.get(url);
  }
  getEventSectionDisqualification(eventID, sectionID, teamID) {
    let url = this.api_url + `event/getEventSectionDisqualification/${eventID}/${sectionID}/${teamID}`;
    return this.httpService.get(url);
  }
  addTeamSectionPenalty(object) {
    let url = this.api_url + `event/addTeamSectionPenalty`;
    return this.httpService.post(url, object);
  }
  addTeamSectionDisqualification(object) {
    let url = this.api_url + `event/addTeamSectionDisqualification`;
    return this.httpService.post(url, object);
  }
  editTeamSectionPenalty(object) {
    let url = this.api_url + `event/editTeamSectionPenalty`;
    return this.httpService.put(url, object);
  }
  editTeamSectionPenaltyStatus(object) {
    let url = this.api_url + `event/editTeamSectionPenaltyStatus`;
    return this.httpService.post(url, object);
  }
  editTeamSectionDisqualification(object) {
    let url = this.api_url + `event/editTeamSectionDisqualification`;
    return this.httpService.put(url, object);
  }
  deleteTeamSectionPenalty(id) {
    let url = this.api_url + `event/deleteTeamSectionPenalty/${id}`;
    return this.httpService.delete(url);
  }
  deleteTeamSectionDisqualification(id) {
    let url = this.api_url + `event/deleteTeamSectionDisqualification/${id}`;
    return this.httpService.delete(url);
  }
  getTeamSectionSubsectionDetail(eventID, sectionID, teamID, subsectionID) {
    let url = this.api_url + `event/getTeamSectionSubsectionDetail/${eventID}/${sectionID}/${teamID}/${subsectionID}`;
    return this.httpService.get(url);
  }
  addEditScore(object) {
    let url = this.api_url + `event/addEditScore`;
    return this.httpService.post(url, object);
  }
  submitScore(eventID, sectionID, categoryID) {
    let url = this.api_url + `event/submitScore/${eventID}/${sectionID}/${categoryID}`;
    return this.httpService.put(url, null);
  }
  getJudgeSectionAssignmentByUserID(eventID, sectionID) {
    let url = this.api_url + `event/getJudgeSectionAssignmentByUserID/${eventID}/${sectionID}`;
    return this.httpService.get(url);
  }
  getJudgeSectionAssignmentByJudgeUserID(eventID, sectionID, judgeID) {
    let url = this.api_url + `event/getJudgeSectionAssignmentByUserID/${eventID}/${sectionID}/${judgeID}`;
    return this.httpService.get(url);
  }
  submitJudgeSectionTeamAssignment(eventID, sectionID, teamID) {
    let url = this.api_url + `event/submitJudgeSectionTeamAssignment/${eventID}/${sectionID}/${teamID}`;
    return this.httpService.put(url, null);
  }
  getJudgeSectionTeamAssignments(eventID, sectionID, teamID) {
    let url = this.api_url + `event/getJudgeSectionTeamAssignments/${eventID}/${sectionID}/${teamID}`;
    return this.httpService.get(url);
  }
  endEvent(id) {
    let url = this.api_url + `event/endEvent/${id}`;
    return this.httpService.post(url, null);
  }
  getCategoryByEventAdmin(id) {
    let url = this.api_url + `event/getCategoryByEventAdmin/${id}`;
    return this.httpService.get(url);
  }
  updateEventSection(eventID, sectionID, sectionEvent) {
    let url = this.api_url + `event/updateEventSection/${eventID}/section/${sectionID}`;
    return this.httpService.put(url, sectionEvent);
  }
  getSubsectionByJudgeAndSection(judgeID, sectionID, eventID) {
    let url = this.api_url + `event/getSubsectionByJudgeAndSection?judgeID=${judgeID}&sectionID=${sectionID}&eventID=${eventID}`;
    return this.httpService.get(url);
  }
  addSubsectionForJudge(judgeID, eventID, categoryID, sectionID, judgeSubsectionAssigment) {
    let url = this.api_url + `event/addSubsectionForJudge?judgeID=${judgeID}&eventID=${eventID}&categoryID=${categoryID}&sectionID=${sectionID}`;
    return this.httpService.post(url, judgeSubsectionAssigment);
  }
  getEventsByReportType(reportType) {
    let url = this.api_url + `event/getEventsByReportType?reportType=${reportType}`;
    return this.httpService.get(url);
  }
  updateEventTeam(eventID, teamID, eventTeam) {
    let url = this.api_url + `event/updateEventTeam/${eventID}/team/${teamID}`;
    return this.httpService.put(url, eventTeam);
  }
  getJudgesByEventAndCategory(eventID, categoryID) {
    let url = this.api_url + `event/getJudgeByEventAndCategory?eventID=${eventID}&categoryID=${categoryID}`;
    return this.httpService.get(url);
  }
  checkLeadJudge(eventID, categoryID) {
    let url = this.api_url + `event/checkCurrentUserLeadJudge?eventID=${eventID}&categoryID=${categoryID}`;
    return this.httpService.get(url);
  }
  addUpdateJudgeSectionComment(judgeSectionObj) {
    let url = this.api_url + `event/addUpdateJudgeSectionComment`;
    return this.httpService.post(url, judgeSectionObj);
  }
  addUpdateJudgeSectionTimeInOut(judgeSectionObj) {
    let url = this.api_url + `event/addUpdateJudgeSectionTimeInOut`;
    return this.httpService.post(url, judgeSectionObj);
  }
  getTeamSectionDetail(eventID, sectionID, teamID, judgeID) {
    let url = this.api_url + `event/getTeamSectionDetail/${eventID}/${sectionID}/${teamID}?judgeID=${judgeID}`;
    return this.httpService.get(url);
  }
  getNextPreviousTeamID(eventID, sectionID, categoryID, teamID) {
    let url = this.api_url + `event/getNextPreviousTeamID?eventID=${eventID}&sectionID=${sectionID}&categoryID=${categoryID}&teamID=${teamID}`;
    return this.httpService.get(url);
  }
  checkSubsectionJudge(eventID) {
    let url = this.api_url + `event/checkSubsectionJudge/${eventID}`;
    return this.httpService.get(url);
  }
}
