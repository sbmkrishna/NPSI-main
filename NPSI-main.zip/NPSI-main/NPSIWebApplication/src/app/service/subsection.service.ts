import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpService } from './http.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SubsectionService {

  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  getSubsection() {
    let url = this.api_url + 'subsection/getSubsection';
    return this.httpService.get(url);
  }
  createSubsection(object) {
    let url = this.api_url + 'subsection/createSubsection';
    return this.httpService.post(url, object);
  }
  editSubsection(object) {
    let url = this.api_url + 'subsection/editSubsection';
    return this.httpService.put(url, object);
  }
  getSubsectionDetail(id) {
    let url = this.api_url + `subsection/getSubsectionDetail/${id}`;
    return this.httpService.get(url);
  }
  getSubsectionByCategory(categoryID) {
    let url = this.api_url + `subsection/getSubsectionByCategory/${categoryID}`;
    return this.httpService.get(url);
  }
}
