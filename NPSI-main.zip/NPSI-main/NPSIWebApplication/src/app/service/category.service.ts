import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  getCategory() {
    let url = this.api_url + 'category/getCategory';
    return this.httpService.get(url);
  }

  getCategoryByEventId(eventId) {
    let url = this.api_url + `category/${eventId}`;
    return this.httpService.get(url);
  }
}
