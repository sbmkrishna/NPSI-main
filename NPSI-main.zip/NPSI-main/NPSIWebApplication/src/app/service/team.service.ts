import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpService } from './http.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TeamService {
  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  searchTeam(object) {
    let url = this.api_url + "team/searchTeam";
    return this.httpService.post(url, object);
  }
  createTeam(object) {
    let url = this.api_url + "team/createTeam";
    return this.httpService.post(url, object);
  }
  editTeam(object) {
    let url = this.api_url + "team/editTeam";
    return this.httpService.put(url, object);
  }
  getTeamsByCategory(id) {
    let url = this.api_url + `team/getTeamsByCategory/${id}`;
    return this.httpService.get(url);
  }
  getTeamDetail(id) {
    let url = this.api_url + `team/getTeamDetail/${id}`;
    return this.httpService.get(url);
  }
  addJudgeSectionTeamAssignment(eventID, sectionID, teamID) {
    let url = this.api_url + `team/addJudgeSectionTeamAssignment/${eventID}/${sectionID}/${teamID}`;
    return this.httpService.post(url, null);
  }
  deleteTeam(teamID) {
    let url = this.api_url + 'team/deleteTeam/' + teamID;
    return this.httpService.delete(url);
  }
  activateDeactiveAllTeams(obj){
    let url = this.api_url + "team/activateDeactiveAllTeams";
    return this.httpService.post(url, obj);
  }
  getAllTeamByActive(active) {
    let url = this.api_url + `team/getAllTeamByActive?active=${active}`;
    return this.httpService.get(url);
  }
}
