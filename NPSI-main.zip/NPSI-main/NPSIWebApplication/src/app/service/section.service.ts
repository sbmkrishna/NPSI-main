import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpService } from './http.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SectionService {

  api_url = environment.api_Url;
  constructor(private httpService: HttpService, private _router: Router) { }
  getSection() {
    let url = this.api_url + 'section/getSection';
    return this.httpService.get(url);
  }
  createSection(object) {
    let url = this.api_url + 'section/createSection';
    return this.httpService.post(url, object);
  }
  editSection(object) {
    let url = this.api_url + 'section/editSection';
    return this.httpService.put(url, object);
  }
  deleteSection(id) {
    let url = this.api_url + `section/deleteSection/${id}`;
    return this.httpService.delete(url);
  }
  checkSectionBeforDeleting(id) {
    let url = this.api_url + `section/checkSectionBeforDeleting/${id}`;
    return this.httpService.get(url);
  }
  getSectionDetail(id) {
    let url = this.api_url + `section/getSectionDetail/${id}`;
    return this.httpService.get(url);
  }
  getSubsectionBySectionID(id) {
    let url = this.api_url + `section/getSectionDetail/${id}/subsection`;
    return this.httpService.get(url);
  }
  getDisqualificationsBySectionID(id) {
    let url = this.api_url + `section/getSectionDetail/${id}/disqualifications`;
    return this.httpService.get(url);
  }
  getPenaltiesBySectionID(id) {
    let url = this.api_url + `section/getSectionDetail/${id}/penalties`;
    return this.httpService.get(url);
  }
  addSubsection(object: any) {
    let url = this.api_url + `section/addSubsection`;
    return this.httpService.post(url, object);
  }
  addPenalty(object: any) {
    let url = this.api_url + `section/addPenalty`;
    return this.httpService.post(url, object);
  }
  addDisqualifications(object: any) {
    let url = this.api_url + `section/addDisqualifications`;
    return this.httpService.post(url, object);
  }
  deleteDisqualifications(sectionID, disID) {
    let url = this.api_url + `section/deleteDisqualifications/${sectionID}/${disID}`;
    return this.httpService.delete(url);
  }
  deletePenalty(sectionID, penID) {
    let url = this.api_url + `section/deletePenalty/${sectionID}/${penID}`;
    return this.httpService.delete(url);
  }
  deleteSubsection(sectionID, subID) {
    let url = this.api_url + `section/deleteSubsection/${sectionID}/${subID}`;
    return this.httpService.delete(url);
  }
  getSectionByCategory(id) {
    let url = this.api_url + `section/getSectionByCategory/${id}`;
    return this.httpService.get(url);
  }
  changeSortIndex(obj) {
    let url = this.api_url + `section/changeSortIndex`;
    return this.httpService.put(url, obj);
  }
}
