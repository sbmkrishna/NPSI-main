import { Injectable } from '@angular/core';
declare var pleaseWait: any;
@Injectable()
export class PleaseWaitService {

  constructor() { }
  loadingScreen(message) {
    var loading = pleaseWait({
      logo: "./assets/images/hourglass.svg",
      backgroundColor: 'rgba(10,10,10,0.7)',
      loadingHtml: ` 
              <h1 class="text-center" style="color:white">`+ message + `</h1>`
    });
    return loading;
  }
  //fn to close loading screen
  closeLoadingScreen(loading) {
    if (loading) {
      loading.finish();
    }

  }
}
