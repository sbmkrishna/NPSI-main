import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  onLogIn = new BehaviorSubject(false);
  api_url = environment.api_Url;
  apiurl = environment.apiUrl;

  constructor(private httpService: HttpService, private _router: Router, private _http: HttpClient) { }
  login(loginInfo) {
    let data = "grant_type=password&username=" + loginInfo.username + "&password=" + loginInfo.password;
    let url = this.apiurl + "oauth/token";
    let headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    loginInfo.grant_type = "password"
    return new Promise((resolve, reject) => {
      this._http.post(url, data, { headers: headers }).toPromise().then((res: any) => {
        var token = res.access_token;
        localStorage.setItem("authorizationToken", token);
        this.onLogIn.next(true);
        resolve();
      }, (err) => {
        reject(err);
      });
    })
  }
  logOut() {
    localStorage.removeItem("authorizationToken");
    localStorage.clear();
    this.onLogIn.next(false);
  }

  loggedIn() {
    this.onLogIn.next(true);
  }
  getUserInfo() {
    let url = this.api_url + "account/getUserInfo";
    return this.httpService.get(url);
  }
}
