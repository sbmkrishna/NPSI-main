import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  api_url = environment.api_Url;
  
  constructor(private httpService: HttpService) { }

  exportDetailedScoring(model) {
    let url = this.api_url + "reports/exportDetailedScoring";
    return this.httpService.postFile(url, model);
  }

  exportRankingReports(model) {
    let url = this.api_url + "reports/exportRankingReports";
    return this.httpService.postFile(url, model);
  }

  exportOverallRankings(model) {
    let url = this.api_url + "reports/exportOverallRankings";
    return this.httpService.postFile(url, model);
  }
}
