import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutComponent } from './components/layout/layout.component';
import { HeaderComponent } from './components/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpConfigInterceptor } from './interceptor/httpconfig.interceptor';
import { AdminComponent } from './components/admin/admin.component';
import { SectionComponent } from './components/admin/sections/section/section.component';
import { SubsectionComponent } from './components/admin/subsection/subsection.component';
import { PenaltyComponent } from './components/admin/penalty/penalty.component';
import { DisqualificationsComponent } from './components/admin/disqualifications/disqualifications.component';
import { ShareModule } from './share/share.module';
import { CustomFormsModule } from 'ngx-custom-validators'
import { NgxSummernoteModule } from 'ngx-summernote';
import { TextMaskModule } from 'angular2-text-mask';
//Begin Ngx-bootstrap
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { SectionDetailComponent } from './components/admin/sections/section-detail/section-detail.component';
import { TabsComponent } from './components/admin/tabs/tabs.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
//End Ngx-bootstrap
import { ManageTeamComponent } from './components/admin/manage-team/manage-team.component';
import { EventComponent } from './components/admin/event/event.component';
import { EventDetailComponent } from './components/admin/event-detail/event-detail.component';
import { AddEditEventComponent } from './components/admin/add-edit-event/add-edit-event.component';
import { EventCategoryManagementComponent } from './components/admin/event-category-management/event-category-management.component';
import { EventCategoryCulinaryComponent } from './components/admin/event-category-culinary/event-category-culinary.component';
import { EventCategoryGeneralComponent } from './components/admin/event-category-general/event-category-general.component';
import { ManageUserComponent } from './components/admin/manage-user/manage-user.component';
import { EventRunComponent } from './components/admin/event-run/event-run.component';
import { EventRunGeneralComponent } from './components/admin/event-run-general/event-run-general.component';
import { UserComponent } from './components/user/user.component';
import { UserEventDetailComponent } from './components/user-event-detail/user-event-detail.component';
import { UserEventCategoryManagementComponent } from './components/user-event-category-management/user-event-category-management.component';
import { UserEventCategoryCulinaryComponent } from './components/user-event-category-culinary/user-event-category-culinary.component';
import { UserEventCategoryGeneralComponent } from './components/user-event-category-general/user-event-category-general.component';
import { UserTeamSectionDetailComponent } from './components/user-team-section-detail/user-team-section-detail.component';
import { FormatDataPipe } from './pipe/format-data.pipe';
import { EventAdminDashboardComponent } from './components/event-admin-dashboard/event-admin-dashboard.component';
import { DatePipe } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DateTimePickerComponent } from './components/date-time-picker/date-time-picker.component';
import { PleaseWaitService } from './service/please-wait.service';
import { AddEditSectionFormComponent } from './components/admin/sections/add-edit-section-form/add-edit-section-form.component';
import { AddSectionComponent } from './components/admin/sections/add-section/add-section.component';
import { JudgeHistoryComponent } from './components/admin/judge-history/judge-history.component';
import { JudgeHistoryScoreComponent } from './components/admin/judge-history-score/judge-history-score.component';
import { AddEditSubsectionFormComponent } from './components/admin/sections/add-edit-subsection-form/add-edit-subsection-form.component';
import { ReportComponent } from './components/admin/report/report.component';
import { AddEditTeamComponent } from './components/admin/add-edit-team/add-edit-team.component';
import { AddTeamComponent } from './components/admin/event-category-general/add-team/add-team.component';
import { EventPenaltyReviewComponent } from './components/admin/event-penalty-review/event-penalty-review.component';
@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HeaderComponent,
    LoginComponent,
    AdminComponent,
    SectionComponent,
    SubsectionComponent,
    PenaltyComponent,
    DisqualificationsComponent,
    SectionDetailComponent,
    TabsComponent,
    ManageTeamComponent,
    EventComponent,
    EventDetailComponent,
    AddEditEventComponent,
    EventCategoryManagementComponent,
    EventCategoryCulinaryComponent,
    EventCategoryGeneralComponent,
    ManageUserComponent,
    EventRunComponent,
    EventRunGeneralComponent,
    UserComponent,
    UserEventDetailComponent,
    UserEventCategoryManagementComponent,
    UserEventCategoryCulinaryComponent,
    UserEventCategoryGeneralComponent,
    UserTeamSectionDetailComponent,
    FormatDataPipe,
    EventAdminDashboardComponent,
    DateTimePickerComponent,
    AddEditSectionFormComponent,
    JudgeHistoryComponent,
    JudgeHistoryScoreComponent,
    AddSectionComponent,
    AddEditSubsectionFormComponent,
    ReportComponent,
    AddEditTeamComponent,
    AddTeamComponent,
    EventPenaltyReviewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    CdkAccordionModule,
    CustomFormsModule,
    AppRoutingModule,
    HttpClientModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TooltipModule.forRoot(),
    TimepickerModule.forRoot(),
    BrowserAnimationsModule,
    ShareModule,
    NgxSummernoteModule,
    TextMaskModule,
    NgbModule,
  ],
  providers: [
    DatePipe,
    PleaseWaitService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
