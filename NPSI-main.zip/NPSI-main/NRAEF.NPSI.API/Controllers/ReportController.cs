﻿using Microsoft.AspNet.Identity;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.Utils;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using Ionic.Zip;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/reports")]
    public class ReportController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [HttpPost]
        [Authorize]
        [Route("exportDetailedScoring")]
        public HttpResponseMessage ExportDetailedScoring([FromBody] DetailedScoringSheetsViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var user = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserID);
                if (!user.IsSuperAdmin)
                {
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
                var fileName = "DetailedScoringSheets-" + model.EventID.ToString() + "-";
                HttpResponseMessage httpResponseMessage = Request.CreateResponse(System.Net.HttpStatusCode.OK);
                if (model.TeamID == null || model.JudgeUserID == null || model.JudgeUserID == "null")
                {
                    if ((model.JudgeUserID == "null" || model.JudgeUserID == null) && model.TeamID != null)
                    {
                        var team = db.Teams.FirstOrDefault(t => t.ID == model.TeamID && t.CategoryID == model.CategoryID);
                        fileName += "AllJudges-" + team.Name.Replace(" ", String.Empty) + ".pdf";
                        List<byte[]> arrByte = new List<byte[]>();
                        var results = ReportServices.GetDetailScoringSheet(model, db);
                        foreach (var item in results)
                        {
                            var reportBytes = ReportServices.AddImageAndParseToByteArray(item, arrByte);
                            arrByte.Add(reportBytes);
                        }
                        var res = ParseToExcel.ConcatAndAddContent(arrByte);

                        httpResponseMessage.Content = new StreamContent(new MemoryStream(res));
                        httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") { FileName = fileName };
                        httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                        httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");

                    }
                    if (model.TeamID == null)
                    {
                        fileName += "AllTeams";
                        List<byte[]> arrByte = new List<byte[]>();
                        var results = ReportServices.GetDetailScoringSheetNoTeam(model, db);
                        using (var ar = new ZipFile())
                        {
                            try
                            {
                                foreach (var data in results)
                                {
                                    List<byte[]> arrayByte = new List<byte[]>();
                                    var index = 1;
                                    bool duplicate = false;
                                    foreach (var item in data.ListData)
                                    {
                                        var reportBytes = ReportServices.AddImageAndParseToByteArray(item, arrayByte);
                                        arrayByte.Add(reportBytes);
                                    }
                                    byte[] res = new byte[] { };
                                    var extension = ".pdf";
                                    do
                                    {
                                        var teamID = data.ListData[0].TeamID;
                                        var team = db.Teams.FirstOrDefault(t => t.ID == teamID && t.CategoryID == model.CategoryID);
                                        var itemFileName = string.Format("{0}{1}-{2}{3}", "DetailedScoringSheets_", model.EventID.ToString(), team.Name.Replace(" ", String.Empty), extension);
                                        if (ar.ContainsEntry(itemFileName))
                                        {
                                            duplicate = true;
                                            index++;
                                        }
                                        else
                                        {
                                            duplicate = false;
                                            res = ParseToExcel.ConcatAndAddContent(arrayByte);
                                            ar.AddEntry(itemFileName, res);
                                        }
                                    } while (duplicate);
                                }

                                var pushStreamContent = new PushStreamContent((stream, content, context) =>
                                {
                                    ar.Save(stream);
                                    stream.Close(); // After save we close the stream to signal that we are done writing.
                                }, "application/zip");

                                httpResponseMessage.Content = pushStreamContent;
                                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                                httpResponseMessage.Content.Headers.ContentDisposition.FileName = string.Format("{0}.zip", fileName);
                                httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                                httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
                            }
                            catch (Exception ex)
                            {
                                LogUtilities.LogError(ex);
                                return Request.CreateResponse(HttpStatusCode.InternalServerError);
                            }
                        }
                    }
                }
                else
                {
                    var judge = db.AspNetUsers.FirstOrDefault(u => u.Id == model.JudgeUserID);
                    var team = db.Teams.FirstOrDefault(t => t.ID == model.TeamID && t.CategoryID == model.CategoryID);
                    fileName += judge.FirstName + judge.LastName + "-" + team.Name.Replace(" ", String.Empty) + ".pdf";
                    List<byte[]> arrByte = new List<byte[]>();
                    var results = ReportServices.GetDetailScoringSheet(model, db);
                    foreach (var item in results)
                    {
                        var reportBytes = ReportServices.AddImageAndParseToByteArray(item, arrByte);
                        arrByte.Add(reportBytes);
                    }
                    var res = ParseToExcel.ConcatAndAddContent(arrByte);

                    httpResponseMessage.Content = new StreamContent(new MemoryStream(res));
                    httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") { FileName = fileName };
                    httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                    httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
                }
                return httpResponseMessage;

            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Authorize]
        [Route("exportRankingReports")]
        public HttpResponseMessage ExportRankingReports([FromBody] RankingReportViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var user = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserID);
                if (!user.IsSuperAdmin)
                {
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
                byte[] reportBytes = new byte[] { };
                var fileName = "";
                HttpResponseMessage httpResponseMessage = Request.CreateResponse(System.Net.HttpStatusCode.OK);

                if (model.TeamID == null)
                {
                    fileName = "RankingReport-" + model.EventID + "-AllTeams";
                    List<byte[]> arrByte = new List<byte[]>();
                    var results = ReportServices.GetSectionByEventAndTeam(model, db);
                    using (var ar = new ZipFile())
                    {
                        try
                        {
                            foreach (var teamResult in results)
                            {
                                var index = 1;
                                bool duplicate = false;
                                foreach (var item in teamResult.Sections)
                                {
                                    if (item.Subsections.Count > 0)
                                    {
                                        item.Subsections[0].FirstIndex = true;
                                    }
                                }
                                if (teamResult.Penalties.Count > 0)
                                {
                                    teamResult.Penalties[0].FirstIndex = true;
                                }
                                var fillingHtml = ReportServices.FillDataInHtml(teamResult, 1);
                                var extension = ".pdf";
                                do
                                {
                                    var itemFileName = string.Format("{0}-{1}{2}", model.EventID.ToString(), teamResult.TeamName.Replace(" ", String.Empty), extension);
                                    if (ar.ContainsEntry(itemFileName))
                                    {
                                        duplicate = true;
                                        index++;
                                    }
                                    else
                                    {
                                        duplicate = false;
                                        reportBytes = ParseToExcel.ParseHtmlToExcel(fillingHtml, false, false);
                                        ar.AddEntry(itemFileName, reportBytes);
                                    }
                                } while (duplicate);
                            }

                            var pushStreamContent = new PushStreamContent((stream, content, context) =>
                            {
                                ar.Save(stream);
                                stream.Close(); // After save we close the stream to signal that we are done writing.
                            }, "application/zip");

                            httpResponseMessage.Content = pushStreamContent;
                            httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                            httpResponseMessage.Content.Headers.ContentDisposition.FileName = string.Format("{0}.zip", fileName);
                            httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
                        }
                        catch (Exception ex)
                        {
                            LogUtilities.LogError(ex);
                            return Request.CreateResponse(HttpStatusCode.InternalServerError);
                        }
                    }
                }
                else
                {
                    var teamName = db.Teams.FirstOrDefault(t => t.ID == model.TeamID && t.CategoryID == model.CategoryID).Name;
                    fileName = "RankingReport-" + model.EventID + "-" + teamName.Replace(" ", String.Empty) + ".pdf";
                    var result = new RankingReportViewModel();
                    result = ReportServices.doGetSectionByEventAndTeam(model, db);
                    foreach (var item in result.Sections)
                    {
                        if (item.Subsections.Count > 0)
                        {
                            item.Subsections[0].FirstIndex = true;
                        }
                    }
                    if (result.Penalties.Count > 0)
                    {
                        result.Penalties[0].FirstIndex = true;
                    }
                    var fillingHtml = ReportServices.FillDataInHtml(result, 1);
                    reportBytes = ParseToExcel.ParseHtmlToExcel(fillingHtml, false, false);
                    httpResponseMessage.Content = new StreamContent(new MemoryStream(reportBytes));
                    httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") { FileName = fileName };
                    httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                    httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
                }
                return httpResponseMessage;
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Authorize]
        [Route("exportOverallRankings")]
        public HttpResponseMessage ExportOverallRankings([FromBody] OverallRankingEventViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var user = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserID);
                if (!user.IsSuperAdmin)
                {
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);
                }
                var categoryName = db.Categories.FirstOrDefault(c => c.ID == model.CategoryID).Name;
                var fileName = categoryName + "-RankingReport.xlsx";
                // Gọi lại hàm để tạo file excel
                var stream = ParseToExcel.CreateExcelFile(model, db);

                HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK);
                string mimeType = MimeMapping.GetMimeMapping(fileName);
                var fileByte = (stream as MemoryStream).ToArray();
                httpResponseMessage.Content = new StreamContent(new MemoryStream(fileByte));
                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") { FileName = fileName };
                httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
                return httpResponseMessage;
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError);
            }
        }
    }
}
public class GenerateOverallRankingModel
{
    public int Place { get; set; }
    public string TeamName { get; set; }
    public decimal Score { get; set; }
}