﻿using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/disqualification")]
    public class DisqualificationController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [SuperAdminAuthorizeAttribute]
        [HttpPost]
        [Route("createDisqualification")]
        public IHttpActionResult CreateDisqualification([FromBody] DisqualificationViewModel model)
        {
            try
            {
                Disqualification disqualification = new Disqualification();
                disqualification.Name = model.Name;
                disqualification.Active = true;
                db.Disqualifications.Add(disqualification);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpPut]
        [Route("editDisqualification")]
        public IHttpActionResult EditDisqualification([FromBody] DisqualificationViewModel model)
        {
            try
            {
                var disqualification = db.Disqualifications.FirstOrDefault(s => s.ID == model.ID);
                disqualification.Name = model.Name;
                disqualification.Active = model.Active;
                db.Entry(disqualification).State = EntityState.Modified;
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getDisqualification")]
        public IHttpActionResult GetDisqualification()
        {
            try
            {
                var disqualifications = db.Disqualifications.Select(s => new DisqualificationViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                    Active = s.Active,
                });
                return Ok(disqualifications.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getDisqualificationActive")]
        public IHttpActionResult GetDisqualificationActive()
        {
            try
            {
                var disqualifications = db.Disqualifications.Where(p => p.Active == true).Select(s => new DisqualificationViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                });
                return Ok(disqualifications.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deleteDisqualification/{disqualificationID}")]
        public IHttpActionResult DeletePenalty([FromUri] int disqualificationID)
        {
            try
            {
                using (var db = new NPSIEntities())
                {
                    var disqualification = db.Disqualifications.FirstOrDefault(p => p.ID == disqualificationID);
                    if (disqualification == null)
                    {
                        return BadRequest();
                    }
                    var teamSectionPenalty = db.TeamSectionDisqualifications.Where(tsp => tsp.DisqualificationID == disqualificationID).ToList();
                    if (teamSectionPenalty.Count > 0)
                    {
                        return Content(HttpStatusCode.BadRequest, "Disqualification cannot be deleted since it was referenced/used in a prior competition. You should make it inactive.");
                    }
                    var sectionDisqualifications = disqualification.Sections.ToList();
                    if (sectionDisqualifications != null)
                    {
                        foreach (var item in sectionDisqualifications)
                        {
                            disqualification.Sections.Remove(item);
                        }
                    }
                    db.Disqualifications.Remove(disqualification);
                    db.SaveChanges();
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }
    }
}
