﻿using Microsoft.AspNet.Identity;
using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.Utils;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Dynamic;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/event")]
    public class EventController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [Authorize]
        [HttpGet]
        [Route("getEventStatus")]
        public IHttpActionResult GetEventStatus()
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }

                var status = db.EventStatus.Select(s => new EventStatusViewModel
                {
                    ID = s.ID,
                    StatusName = s.StatusName,
                    StatusCode = s.StatusCode
                });
                return Ok(status.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }

        }

        [Authorize]
        [HttpPost]
        [Route("searchEvent")]
        public IHttpActionResult SearchEvent([FromBody] SearchEventViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }

                var eventAdminRole = db.AspNetRoles.FirstOrDefault(s => s.Name == Utils.Constants.Roles.EVENTADMIN);

                var listEventID = db.UserEventRoles.Where(s => s.UserID == currentUserID && s.RoleID == eventAdminRole.Id).Select(x => x.EventID).ToList();

                SearchEvent result = new SearchEvent();
                var events = db.Events.Select(s => new EventViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                    StartDateTime = s.StartDateTime,
                    EndDateTime = s.EndDateTime,
                    CreatedDateTime = s.CreatedDateTime,
                    CreatedByUserID = s.CreatedByUserID,
                    Categories = s.Categories.Select(p => new CategoryViewModel
                    {
                        ID = p.ID,
                        Name = p.Name,
                    }).ToList(),
                    StatusID = s.EventStatusLogs.OrderByDescending(p => p.LoggedDateTime).FirstOrDefault().EventStatusID,
                    StatusName = s.EventStatusLogs.OrderByDescending(p => p.LoggedDateTime).FirstOrDefault().EventStatu.StatusName,
                });
                if (listEventID.Count > 0)
                {
                    events = events.Where(s => listEventID.Contains((int)s.ID));
                }
                if (model.Name != null)
                {
                    events = events.Where(s => s.Name.Contains(model.Name));
                }
                if (model.ListStatusID.Count > 0)
                {
                    events = events.Where(s => model.ListStatusID.Contains((int)s.StatusID));
                }

                if (model.CategoryID != null)
                {
                    events = events.Where(s => s.Categories.Select(p => p.ID).Contains((short)model.CategoryID));
                }
                if (model.StartDateFrom != null)
                {
                    events = events.Where(s => DbFunctions.TruncateTime(s.StartDateTime) >= model.StartDateFrom);
                }
                if (model.StartDateTo != null)
                {
                    events = events.Where(s => DbFunctions.TruncateTime(s.StartDateTime) <= model.StartDateTo);
                }
                if (model.EndDateFrom != null)
                {
                    events = events.Where(s => DbFunctions.TruncateTime(s.EndDateTime) >= model.EndDateFrom);
                }
                if (model.EndDateTo != null)
                {
                    events = events.Where(s => DbFunctions.TruncateTime(s.EndDateTime) <= model.EndDateTo);
                }
                Nullable<int> count = null;
                if (model.ReturnTotalCount == false)
                {
                    count = null;
                }
                else
                {
                    count = events.Count();
                }
                //sorting
                if (model.SortedBy == null)
                {
                    //default sort order: Show Incomplete first, show tasks having end date above tasks no end date, show nearer end date first
                    model.SortedBy = "StartDateTime asc";
                }
                events = events.OrderBy(model.SortedBy + ", ID asc");
                //pagination
                if (model.PageNumber == null)
                {
                    model.PageNumber = 1;
                }
                if (model.ItemsPerPage == null)
                {
                    model.ItemsPerPage = 10;
                }
                if (model.ItemsPerPage.HasValue)
                {
                    events = events.Skip(model.ItemsPerPage.Value * (model.PageNumber.Value - 1)).Take(model.ItemsPerPage.Value);
                }
                result.Data = events.ToList();
                result.Count = count;
                return Ok(result);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorize]
        [HttpPost]
        [Route("createEvent")]
        public IHttpActionResult CreateEvent([FromBody] EventViewModel model)
        {
            try
            {
                using (var tran = db.Database.BeginTransaction())
                {
                    try
                    {
                        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                        Event e = new Event();
                        e.Name = model.Name;
                        e.StartDateTime = model.StartDateTime;
                        e.EndDateTime = model.EndDateTime;
                        e.CreatedDateTime = DateTime.Now;
                        e.CreatedByUserID = currentUserID;
                        db.Events.Add(e);
                        db.SaveChanges();

                        EventStatusLog est = new EventStatusLog();
                        est.LoggedDateTime = DateTimeOffset.Now;
                        est.EventStatusID = 1;
                        est.EventID = e.ID;
                        est.LoggedBy = currentUserID;
                        db.EventStatusLogs.Add(est);
                        db.SaveChanges();

                        List<Category> categories = new List<Category>();
                        for (var i = 0; i < model.CategoryIDs.Count; i++)
                        {
                            var categoryID = model.CategoryIDs[i];
                            var category = db.Categories.FirstOrDefault(p => p.ID == categoryID);
                            categories.Add(category);
                        }
                        foreach (var c in categories)
                        {
                            e.Categories.Add(c);
                        }

                        db.SaveChanges();
                        tran.Commit();
                        return Ok(e.ID);
                    }
                    catch (Exception)
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorize]
        [HttpPut]
        [Route("editEvent")]
        public IHttpActionResult EditEvent([FromBody] EventViewModel model)
        {
            try
            {
                using (var tran = db.Database.BeginTransaction())
                {
                    try
                    {
                        var e = db.Events.FirstOrDefault(s => s.ID == model.ID);
                        e.Name = model.Name;
                        e.StartDateTime = model.StartDateTime;
                        e.EndDateTime = model.EndDateTime;
                        db.Entry(e).State = EntityState.Modified;
                        db.SaveChanges();

                        var categories = e.Categories.ToList();
                        foreach (var c in categories)
                        {
                            e.Categories.Remove(c);
                        }
                        db.SaveChanges();

                        List<Category> categories1 = new List<Category>();
                        for (var i = 0; i < model.CategoryIDs.Count; i++)
                        {
                            var categoryID = model.CategoryIDs[i];
                            var category = db.Categories.FirstOrDefault(p => p.ID == categoryID);
                            categories1.Add(category);
                        }

                        foreach (var c in categories1)
                        {
                            e.Categories.Add(c);
                        }
                        db.SaveChanges();

                        tran.Commit();
                        return Ok();
                    }
                    catch (Exception)
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorize]
        [HttpPost]
        [Route("startEvent/{id}")]
        public IHttpActionResult StartEvent(int id)
        {
            try
            {
                var lastStatus = db.EventStatusLogs.Where(s => s.EventID == id).OrderByDescending(s => s.LoggedDateTime).FirstOrDefault();
                if (lastStatus.EventStatu.StatusName != Utils.Constants.EventStatuses.OPENED)
                {
                    return Content(HttpStatusCode.BadRequest, "The event has been started.");
                }
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var statusStarted = db.EventStatus.FirstOrDefault(s => s.StatusName == Utils.Constants.EventStatuses.STARTED);
                EventStatusLog est = new EventStatusLog();
                est.LoggedDateTime = DateTimeOffset.Now;
                est.EventStatusID = statusStarted.ID;
                est.EventID = id;
                est.LoggedBy = currentUserID;
                db.EventStatusLogs.Add(est);
                db.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventDetail/{id}")]
        public IHttpActionResult GetEventDetail(int id)
        {
            try
            {
                var e = db.Events.Select(s => new EventViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                    StartDateTime = s.StartDateTime,
                    EndDateTime = s.EndDateTime,
                    CreatedDateTime = s.CreatedDateTime,
                    CreatedByUserID = s.CreatedByUserID,
                    Categories = s.Categories.Select(p => new CategoryViewModel
                    {
                        ID = p.ID,
                        Name = p.Name,
                    }).ToList(),
                    StatusID = s.EventStatusLogs.OrderByDescending(p => p.LoggedDateTime).FirstOrDefault().EventStatusID,
                    StatusName = s.EventStatusLogs.OrderByDescending(p => p.LoggedDateTime).FirstOrDefault().EventStatu.StatusName,
                    StatusLogDatetime = s.EventStatusLogs.OrderByDescending(p => p.LoggedDateTime).FirstOrDefault().LoggedDateTime,
                }).FirstOrDefault(s => s.ID == id);

                return Ok(e);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventSection/{id}/category/{categoryID}")]
        public IHttpActionResult GetEventSection(int id, int categoryID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, id) == false)
                {
                    return Unauthorized();
                }
                var e = db.Events.FirstOrDefault(s => s.ID == id);
                var sections = from p in e.EventSections.Where(s => s.Section.CategoryID == categoryID)
                               from s in db.Sections
                               where p.SectionID == s.ID
                               select new
                               {
                                   Id = p.SectionID,
                                   Name = s.Name,
                                   SortOrder = p.Section.SortOrder,
                                   Judges = db.JudgeSectionAssignments
                                   .Where(s => s.EventID == id && s.SectionID == p.Section.ID &&
                                   s.AspNetUser.UserEventRoles.FirstOrDefault(r => r.AspNetRole.Name == Utils.Constants.Roles.JUDGE && r.EventID == id) != null)
                                   .Select(v => new AspNetUserViewModel
                                   {
                                       Id = v.AspNetUser.Id,
                                       FirstName = v.AspNetUser.FirstName,
                                       LastName = v.AspNetUser.LastName,
                                       Username = v.AspNetUser.UserName
                                   }).ToList(),
                               };

                return Ok(sections.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

    [Authorize]
    [HttpGet]
    [Route("getEventJudges/{id}/category/{categoryID}")]
    public IHttpActionResult GetEventJudges(int id, int categoryId)
    {
      try
      {
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        var user = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserID);
        var roles = db.UserEventRoles.Where(s => s.UserID == currentUserID && s.EventID == id && s.CategoryID == categoryId).Select(r => r.AspNetRole.Name).ToList();
        if (roles.Contains(Utils.Constants.Roles.EVENTADMIN) || roles.Contains(Utils.Constants.Roles.LEADJUDGE) || user.IsSuperAdmin == true)
        {
          var users = db.UserEventRoles.Where(s => s.EventID == id && s.CategoryID == categoryId).Select(p => new EventUserViewModel
          {
            EventId = p.EventID,
            RoleID = p.RoleID,
            CatogoryID = p.CategoryID,
            UserId = p.UserID,
            Username = p.AspNetUser.UserName,
            Rolename = p.AspNetRole.Name,
            FirstName = p.AspNetUser.FirstName,
            LastName = p.AspNetUser.LastName,
          });
          return Ok(users.ToList());
        }
        else
        {
          return Unauthorized();
        }
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

        [Authorize]
        [HttpGet]
        [Route("getEventUser/{id}/category/{categoryID}")]
        public IHttpActionResult GetEventUsers(int id, int categoryId)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, id) == false)
                {
                    return Unauthorized();
                }
                var users = db.UserEventRoles.Where(s => s.EventID == id && s.CategoryID == categoryId).Select(p => new EventUserViewModel
                {
                    EventId = p.EventID,
                    RoleID = p.RoleID,
                    CatogoryID = p.CategoryID,
                    UserId = p.UserID,
                    Username = p.AspNetUser.UserName,
                    Rolename = p.AspNetRole.Name,
                    FirstName = p.AspNetUser.FirstName,
                    LastName = p.AspNetUser.LastName,
                });
                return Ok(users.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventTeam/{id}/category/{categoryID}")]
        public IHttpActionResult GetEventTeam(int id, int categoryID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, id) == false)
                {
                    return Unauthorized();
                }
                var e = db.Events.FirstOrDefault(s => s.ID == id);

                var teams = e.EventTeams.Select(p => new EventTeamViewModel
                {
                    EventID = p.EventID,
                    TeamID = p.TeamID,
                    TeamName = p.Team.Name,
                    CategoryID = p.Team.CategoryID,
                    SchoolName = p.Team.SchoolName,
                    CategoryName = p.Team.Category.Name,
                    StartTime = p.StartTime,
                    EndTime = p.EndTime,
                    Date = p.StartTime.Date,
                    Email = p.Team.Email,
                    Active = p.Team.Active,
                    Phone = p.Team.Phone,
                    PrimaryContactName = p.Team.PrimaryContactName,
                    SortOrder = p.SortOrder,
                    Members = p.Team.Members.Select(v => new MemberViewModel
                    {
                        ID = v.ID,
                        Name = v.Name,
                        Phone = v.Phone,
                        Email = v.Email
                    }).ToList(),
                }).Where(s => s.EventID == id && s.CategoryID == categoryID).OrderBy(o => o.StartTime).ThenBy(et => et.SortOrder);
                return Ok(teams.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addEventSection")]
        public IHttpActionResult AddEventSection([FromBody] AddEventSectionViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }

                foreach (var i in model.EventSection)
                {
                    var isExistEventSection = db.EventSections.FirstOrDefault(es => es.EventID == i.EventID && es.SectionID == i.SectionID);
                    if (isExistEventSection == null)
                    {
                        EventSection eventSection = new EventSection
                        {
                            EventID = i.EventID,
                            SectionID = i.SectionID,
                        };
                        db.EventSections.Add(eventSection);
                    }

                    if (i.Judges != null && i.Judges.Count > 0)
                    {
                        foreach (var item in i.Judges)
                        {
                            var judgeSectionAssignment = new JudgeSectionAssignment
                            {
                                JudgeUserID = item.JudgeUserID,
                                SectionID = i.SectionID,
                                EventID = i.EventID
                            };
                            db.JudgeSectionAssignments.Add(judgeSectionAssignment);

                            var subsections = db.Subsections.Where(w => w.SectionID == i.SectionID).Select(s => new SubsectionViewModel
                            {
                                ID = s.ID,
                            }).ToList();
                            foreach (var subsection in subsections)
                            {
                                var jugdeSubsectionAssignment = new JudgeSubsectionAssignment
                                {
                                    JudgeUserID = item.JudgeUserID,
                                    SubsectionID = subsection.ID.Value,
                                    EventID = i.EventID
                                };
                                db.JudgeSubsectionAssignments.Add(jugdeSubsectionAssignment);
                            }
                        }
                    }
                    db.SaveChanges();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpPut]
        [Route("updateEventSection/{eventID}/section/{sectionID}")]
        public IHttpActionResult UpdateEventSection([FromUri] int eventID, [FromUri] int sectionID, [FromBody] EventSectionViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }

                using (var db = new NPSIEntities())
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var eventSection = db.EventSections.FirstOrDefault(es => es.EventID == eventID && es.SectionID == sectionID);
                            if (eventSection == null)
                            {
                                dbTransaction.Rollback();
                                return NotFound();
                            }

                            var judgeSectionAssignmentList = db.JudgeSectionAssignments.Where(w => w.EventID == eventID && w.SectionID == sectionID)
                                .Select(s => new JudgeSectionAssignmentViewModel
                                {
                                    JudgeUserID = s.JudgeUserID,
                                    EventID = s.EventID,
                                    SectionID = s.SectionID
                                }).ToList();
                            var listJudge = checkDiffJudgeAssignment(model.Judges, judgeSectionAssignmentList);
                            foreach (var item in listJudge.ListAdd)
                            {
                                var judgeSectionAssignment = new JudgeSectionAssignment
                                {
                                    JudgeUserID = item.JudgeUserID,
                                    SectionID = sectionID,
                                    EventID = eventID
                                };
                                db.JudgeSectionAssignments.Add(judgeSectionAssignment);
                            }
                            foreach (var item in listJudge.ListRemove)
                            {
                                var judgeSectionAssignments = db.JudgeSubsectionAssignments
                                    .Where(w => w.JudgeUserID == item.JudgeUserID && w.EventID == eventID).ToList();
                                if (judgeSectionAssignments != null)
                                {
                                    foreach (var i in judgeSectionAssignments)
                                    {
                                        var score = db.Scores.FirstOrDefault(s => s.SubsectionID == i.SubsectionID && s.EventID == eventID && s.JudgeUserID == item.JudgeUserID);
                                        if (score != null)
                                        {
                                            dbTransaction.Rollback();
                                            return Content(HttpStatusCode.BadRequest, "Scores existed at subsection " + score.Subsection.Name + ".");
                                        }
                                    }
                                }
                                db.JudgeSubsectionAssignments.RemoveRange(judgeSectionAssignments);
                                db.JudgeSectionAssignments.Remove(db.JudgeSectionAssignments.FirstOrDefault(w => w.EventID == eventID && w.SectionID == sectionID && w.JudgeUserID == item.JudgeUserID));
                            }
                            db.SaveChanges();
                            dbTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbTransaction.Rollback();
                            LogUtilities.LogError(ex);
                            return Content(HttpStatusCode.InternalServerError, "An unknown server error occurred.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpDelete]
        [Route("deleteEventSection/{eventID}/{sectionID}")]
        public IHttpActionResult DeleteEventSection(int eventID, int sectionID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();

                if (db.Scores.Any(s => s.EventID == eventID && s.Subsection.SectionID == sectionID))
                {
                    return Content(HttpStatusCode.BadRequest, "The section cannot be removed as it has started being scored.");
                }


                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, eventID) == false)
                {
                    return Unauthorized();
                }

                var judges = db.JudgeSectionAssignments.Where(s => s.EventID == eventID && s.SectionID == sectionID).ToList();
                if (judges.Count > 0)
                {
                    foreach (var item in judges)
                    {
                        db.JudgeSectionAssignments.Remove(item);
                    }
                }
                var judgeSubsectionAssignments = db.JudgeSubsectionAssignments.Where(s => s.EventID == eventID && s.Subsection.SectionID == sectionID).ToList();
                if (judgeSubsectionAssignments.Count > 0)
                {
                    foreach (var item in judgeSubsectionAssignments)
                    {
                        db.JudgeSubsectionAssignments.Remove(item);
                    }
                }
                db.SaveChanges();

                var eventSection = db.EventSections.FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID);

                db.EventSections.Remove(eventSection);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addJudgeEventSection")]
        public IHttpActionResult AddJudgeEventSection([FromBody] JudgeEventSectionViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }
                JudgeSectionAssignment judgeSectionAssignment = new JudgeSectionAssignment();
                judgeSectionAssignment.JudgeUserID = model.JudgeUserID;
                judgeSectionAssignment.EventID = model.EventID;
                judgeSectionAssignment.SectionID = model.SectionID;
                db.JudgeSectionAssignments.Add(judgeSectionAssignment);
                var subsections = db.Subsections.Where(w => w.SectionID == model.SectionID).Select(s => new SubsectionViewModel
                {
                    ID = s.ID,
                }).ToList();
                foreach (var subsection in subsections)
                {
                    var jugdeSubsectionAssignment = new JudgeSubsectionAssignment
                    {
                        JudgeUserID = model.JudgeUserID,
                        SubsectionID = subsection.ID.Value,
                        EventID = model.EventID
                    };
                    db.JudgeSubsectionAssignments.Add(jugdeSubsectionAssignment);
                }
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpPost]
        [Route("deleteJudgeEventSection")]
        public IHttpActionResult DeleteJudgeEventSection([FromBody] JudgeEventSectionViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var checkScore = db.Scores.Where(s => s.JudgeUserID == model.JudgeUserID && s.EventID == model.EventID && s.Subsection.SectionID == model.SectionID).ToList();
                if (checkScore.Count > 0)
                {
                    return Content(HttpStatusCode.BadRequest, "The judge cannot be unassigned from the section as he/she has started scoring in the section.");
                }
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }

                //delete subsection assignments
                var judgeSubsectionAssignments = db.JudgeSubsectionAssignments.Where(jsa => jsa.JudgeUserID == model.JudgeUserID && jsa.Subsection.SectionID == model.SectionID && jsa.EventID == model.EventID);
                db.JudgeSubsectionAssignments.RemoveRange(judgeSubsectionAssignments);

                //delete section assignment
                var judgeSectionsAssignment = db.JudgeSectionAssignments.FirstOrDefault(s => s.JudgeUserID == model.JudgeUserID && s.EventID == model.EventID && s.SectionID == model.SectionID);
                db.JudgeSectionAssignments.Remove(judgeSectionsAssignment);

                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addEventTeam/{eventID}")]
        public IHttpActionResult AddEventTeam([FromUri] int eventID, [FromBody] List<AddEventTeamViewModel> model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, eventID) == false)
                {
                    return Unauthorized();
                }
                foreach (var item in model)
                {
                    var team = new EventTeam
                    {
                        TeamID = item.TeamID,
                        EventID = eventID,
                        StartTime = item.StartTime,
                        EndTime = item.EndTime,
                        SortOrder = item.SortOrder
                    };
                    db.EventTeams.Add(team);
                }
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpDelete]
        [Route("deleteEventTeam/{eventID}/{teamID}")]
        public IHttpActionResult DeleteEventTeam(int eventID, int teamID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var checkScore = db.Scores.Where(s => s.EventID == eventID && s.TeamID == teamID).ToList();
                if (checkScore.Count > 0)
                {
                    return Content(HttpStatusCode.BadRequest, "The team cannot be removed as it has scores in at least one section.");
                }
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, eventID) == false)
                {
                    return Unauthorized();
                }

                var eventTeam = db.EventTeams.FirstOrDefault(et => et.EventID == eventID && et.TeamID == teamID);
                if (eventTeam == null)
                {
                    return Content(HttpStatusCode.NotFound, "The team is not exist in event.");
                }
                db.EventTeams.Remove(eventTeam);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addEventUser")]
        public IHttpActionResult AddUserEvent([FromBody] AddUserEventRoleViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }
                var users = db.UserEventRoles.Where(s => s.EventID == model.EventID && s.CategoryID == model.CategoryID);
                foreach (var user in users)
                {
                    for (var i = 0; i < model.ListUser.Count; i++)
                    {
                        var item = model.ListUser[i];
                        if (item.UserID == user.UserID)
                        {
                            db.UserEventRoles.Remove(user);
                            UserEventRole userEventRole = new UserEventRole();
                            userEventRole.EventID = model.EventID;
                            userEventRole.RoleID = item.RoleID;
                            userEventRole.CategoryID = model.CategoryID;
                            userEventRole.UserID = item.UserID;
                            db.UserEventRoles.Add(userEventRole);
                            model.ListUser.Remove(item);
                        }
                    }
                }

                foreach (var item in model.ListUser)
                {
                    UserEventRole userEventRole = new UserEventRole();
                    userEventRole.EventID = model.EventID;
                    userEventRole.CategoryID = model.CategoryID;
                    userEventRole.UserID = item.UserID;
                    userEventRole.RoleID = item.RoleID;
                    db.UserEventRoles.Add(userEventRole);
                }
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("deleteEventUser")]
        public IHttpActionResult DeleteEventUser([FromBody] DeleteUserEventRoleViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }
                var userEventRole = db.UserEventRoles.FirstOrDefault(s => s.EventID == model.EventID && s.UserID == model.UserID && s.CategoryID == model.CategoryID);

                if (userEventRole.AspNetRole.Name == Utils.Constants.Roles.JUDGE)
                {

                    var judgeSectionAssign = db.JudgeSectionAssignments.Where(s => s.EventID == model.EventID && s.JudgeUserID == model.UserID && s.EventSection.Section.CategoryID == model.CategoryID).ToList();
                    if (judgeSectionAssign.Count > 0)
                    {
                        return Content(HttpStatusCode.BadRequest, "The judge cannot be removed as he has been assigned to at least one section, please unassign him/her from sections first.");
                    }

                }
                else if (userEventRole.AspNetRole.Name == Utils.Constants.Roles.LEADJUDGE)
                {
                    var checkScore = db.Scores.Where(s => s.EventID == model.EventID && s.JudgeUserID == model.UserID).ToList();
                    if (checkScore.Count > 0)
                    {
                        return Content(HttpStatusCode.BadRequest, "The lead judge cannot be removed as he/she has started scoring in at least one section.");
                    }
                }
                db.UserEventRoles.Remove(userEventRole);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventRun/{id}/{categoryId}")]
        public IHttpActionResult GetEventRun(int id, int categoryId)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                bool isLeadJudge = true;
                var admin = EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID);
                if (admin == false)
                {
                    var checkLeadJudge = checkCurrentUserLeadJudge(id, categoryId, db);
                    isLeadJudge = checkLeadJudge ? true : false;
                    if (!isLeadJudge) return Unauthorized();
                }

                var e = db.Events.FirstOrDefault(s => s.ID == id);
                var sections = from p in e.EventSections.Where(s => s.Section.CategoryID == categoryId && (isLeadJudge))
                               from s in db.Sections
                               where p.SectionID == s.ID
                               select new
                               {
                                   Id = p.SectionID,
                                   Name = s.Name,
                                   SortOrder = s.SortOrder,
                                   Teams = p.Event.EventTeams.Select(x => new EventTeamViewModel
                                   {
                                       EventID = e.ID,
                                       TeamID = x.TeamID,
                                       TeamName = x.Team.Name,
                                       CategoryID = x.Team.CategoryID,
                                       SchoolName = x.Team.SchoolName,
                                       CategoryName = x.Team.Category.Name,
                                       StartTime = x.StartTime,
                                       EndTime = x.EndTime,
                                       SortOrder = x.SortOrder,
                                       PenaltyCount = db.TeamSectionPenalties.Where(tsp => tsp.EventID == p.EventID && tsp.SectionID == p.SectionID && tsp.TeamID == x.TeamID).Count(),
                                       Judges = db.JudgeSectionAssignments.Where(s => s.EventID == id && s.SectionID == p.Section.ID)
                                       .Select(v => new AspNetUserViewModel
                                       {
                                           Id = v.AspNetUser.Id,
                                           FirstName = v.AspNetUser.FirstName,
                                           LastName = v.AspNetUser.LastName,
                                           Username = v.AspNetUser.UserName,
                                           Status = v.SubmittedDateTime.HasValue ? "Complete" : "In Progress",
                                           TimeIn = v.EventSection.Event.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.JudgeUserID == v.AspNetUser.Id && jst.EventID == id && jst.Team.CategoryID == categoryId && jst.SectionID == v.SectionID).TimeIn,
                                           TimeOut = v.EventSection.Event.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.JudgeUserID == v.AspNetUser.Id && jst.EventID == id && jst.Team.CategoryID == categoryId && jst.SectionID == v.SectionID).TimeOut,
                                       }).ToList(),
                                   }).Where(u => u.CategoryID == categoryId)
                                   .OrderBy(et => et.StartTime)
                                   .ThenBy(et => et.SortOrder).ToList(),
                               };
                return Ok(sections.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getUserEventCategoryList")]
        public IHttpActionResult GetUserEventCategoryList()
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var eventCategories = from uer in db.UserEventRoles
                                      join evt in db.Events on uer.EventID equals evt.ID
                                      join cat in db.Categories on uer.CategoryID equals cat.ID
                                      join anr in db.AspNetRoles on uer.RoleID equals anr.Id
                                      where uer.UserID == currentUserID
                                      select new
                                      {
                                          EventID = uer.EventID,
                                          EventName = evt.Name,
                                          CategoryID = uer.CategoryID,
                                          CategoryName = cat.Name,
                                          RoleID = uer.RoleID,
                                          RoleName = anr.Name,
                                          Status = evt.EventStatusLogs.OrderByDescending(esl => esl.LoggedDateTime).FirstOrDefault().EventStatu.StatusName
                                      };
                return Ok(eventCategories.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventStartedByUserID")]
        public IHttpActionResult GetEventStartedByUserID()
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var events = from eu in db.UserEventRoles.Where(s => s.UserID == currentUserID).GroupBy(p => p.EventID).Select(grp => grp.FirstOrDefault())
                             from e in db.Events.Where(s => s.EventStatusLogs.OrderByDescending(x => x.LoggedDateTime).FirstOrDefault().EventStatu.StatusName == Utils.Constants.EventStatuses.OPENED)
                             where eu.EventID == e.ID
                             select new
                             {
                                 EventID = e.ID,
                                 EventName = e.Name
                             };
                return Ok(events.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventActiveByUserID")]
        public IHttpActionResult GetEventActiveByUserID()
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var events = from eu in db.UserEventRoles.Where(s => s.UserID == currentUserID).GroupBy(p => p.EventID).Select(grp => grp.FirstOrDefault())
                             from e in db.Events.Where(s => s.EventStatusLogs.OrderByDescending(x => x.LoggedDateTime).FirstOrDefault().EventStatu.StatusName == Utils.Constants.EventStatuses.STARTED &&
                                                        s.EventStatusLogs.OrderByDescending(x => x.LoggedDateTime).FirstOrDefault().EventStatu.StatusName != Utils.Constants.EventStatuses.COMPLETED)
                             where eu.EventID == e.ID
                             select new
                             {
                                 EventID = e.ID,
                                 EventName = e.Name,
                             };
                return Ok(events.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventCompleteByUserID")]
        public IHttpActionResult GetEventCompleteByUserID()
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var events = from eu in db.UserEventRoles.Where(s => s.UserID == currentUserID).GroupBy(p => p.EventID).Select(grp => grp.FirstOrDefault())
                             from e in db.Events.Where(s => s.EventStatusLogs.OrderByDescending(x => x.LoggedDateTime).FirstOrDefault().EventStatu.StatusName == Utils.Constants.EventStatuses.COMPLETED)
                             where eu.EventID == e.ID
                             select new
                             {
                                 EventID = e.ID,
                                 EventName = e.Name
                             };
                return Ok(events.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

    [Authorize]
    [HttpGet]
    [Route("checkPermissionUserEventDetail/{id}/{judgeID}")]
    public IHttpActionResult CheckPermissionUserEventDetail(int id, string judgeID)
    {
      try
      {
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        var currentUser = db.AspNetUsers.FirstOrDefault(u => u.Id == currentUserID);
        var currentEventRole = db.UserEventRoles.FirstOrDefault(s => s.EventID == id && s.UserID == currentUserID && s.AspNetRole.Name == Utils.Constants.Roles.LEADJUDGE);

        // current user must be either superadmin or lead judge for this event
        if (currentUser.IsSuperAdmin || currentEventRole != null)
        {
          var judgeEvent = db.UserEventRoles.Where(s => s.EventID == id && s.UserID == judgeID).ToList();
          List<CategoryViewModel> categories = new List<CategoryViewModel>();
          if (judgeEvent.Count > 0)
          {
            categories = judgeEvent.Select(s => new CategoryViewModel
            {
              ID = s.Category.ID,
              Name = s.Category.Name
            }).ToList();
          }
          return Ok(categories);
        }
        else
        {
          return Unauthorized();
        }
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

        [Authorize]
        [HttpGet]
        [Route("checkPermissionUserEventDetail/{id}")]
        public IHttpActionResult CheckPermissionUserEventDetail(int id)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var userEvent = db.UserEventRoles.Where(s => s.EventID == id && s.UserID == currentUserID).ToList();
                List<CategoryViewModel> categories = new List<CategoryViewModel>();
                if (userEvent.Count > 0)
                {
                    categories = userEvent.Select(s => new CategoryViewModel
                    {
                        ID = s.Category.ID,
                        Name = s.Category.Name
                    }).ToList();
                }
                return Ok(categories);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventSectionTeamDetail/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetEventSectionTeamDetail(int eventID, int sectionID, int teamID)
        {
            // only for judges to call for themselves
            var currentJudgeId = HttpContext.Current.User.Identity.GetUserId();

            try
            {
                var result = from es in db.EventSections
                             join et in db.EventTeams on es.EventID equals et.EventID
                             join jstio in db.JudgeSectionTeamInOuts
                                on new { et.TeamID, JudgeUserID = currentJudgeId, es.SectionID, es.EventID }
                                equals new { jstio.TeamID, jstio.JudgeUserID, jstio.SectionID, jstio.EventID }
                                into jj
                             from jsti in jj.DefaultIfEmpty()
                             join jsa in db.JudgeSectionAssignments
                                on new { JudgeUserID = currentJudgeId, es.SectionID, es.EventID }
                                equals new { jsa.JudgeUserID, jsa.SectionID, jsa.EventID }
                                into ja
                             from js in ja.DefaultIfEmpty()
                             where es.EventID == eventID && es.SectionID == sectionID && et.TeamID == teamID
                             select new EventSectionTeamJudgeViewModel()
                             {
                                 EventID = es.EventID,
                                 EventName = es.Event.Name,
                                 CategoryID = es.Section.CategoryID,
                                 CategoryName = es.Section.Category.Name,
                                 SectionID = es.SectionID,
                                 SectionName = es.Section.Name,
                                 TeamID = et.TeamID,
                                 TeamName = et.Team.Name,
                                 TeamEmail = et.Team.Email,
                                 TeamPhone = et.Team.Phone,
                                 SchoolName = et.Team.SchoolName,
                                 Active = et.Team.Active,
                                 StartTime = et.StartTime,
                                 EndTime = et.EndTime,
                                 //Date = et.StartTime.Date,
                                 JudgeUserID = currentJudgeId,
                                 JudgeFirstName = jsti.AspNetUser.FirstName,
                                 JudgeLastName = jsti.AspNetUser.LastName,
                                 Done = !(js.SubmittedDateTime == null),
                                 TimeIn = jsti.TimeIn,
                                 TimeOut = jsti.TimeOut,
                                 TimeInOutNeeded = es.Section.TimeInOutNeeded,
                                 SortOrder = et.SortOrder,
                                 Comments = jsti.Comments,
                                 SubsectionScores = es.Section.Subsections
                                    .Where(ss => ss.JudgeSubsectionAssignments.Any(j => j.JudgeUserID == currentJudgeId && j.EventID == eventID))
                                    .Select(p => new SubsectionScoreViewModel
                                    {
                                        EventID = et.EventID,
                                        TeamID = et.TeamID,
                                        CategoryID = es.Section.CategoryID,
                                        JudgeUserID = currentJudgeId,
                                        SectionID = es.SectionID,
                                        SubSectionID = p.ID,
                                        SubSectionName = p.Name,
                                        Description = p.Description,
                                        MinScore = p.MinScore,
                                        MaxScore = p.MaxScore,
                                        SortIndex = p.SortIndex,
                                        Criteria = p.Criteria.Select(x => new CriteriaViewModel
                                        {
                                            Title = x.Title,
                                            Description = x.Description,
                                            MaxScore = x.MaxScore,
                                            MinScore = x.MinScore
                                        }).ToList(),
                                        Score = p.Scores
                                            .Where(u => u.EventID == eventID && u.TeamID == teamID && u.JudgeUserID == currentJudgeId && u.SubsectionID == p.ID)
                                            .Select(x => new ScoreViewModel
                                            {
                                                ID = x.ID,
                                                Score = x.Score1,
                                                CreatedDateTime = x.CreatedDateTime,
                                                SubsectionID = x.SubsectionID,
                                                JudgeUserID = x.JudgeUserID,
                                                TeamID = x.TeamID,
                                                EventID = x.EventID,
                                                SectionID = p.SectionID,
                                                Comments = x.Comments,
                                                Photo = x.Photo,
                                                MaxVal = x.Subsection.MaxScore,
                                                MinVal = x.Subsection.MinScore
                                            }).FirstOrDefault()
                                    })
                                    .OrderBy(s => s.SortIndex)
                                    .ToList(),
                                 Penalties = db.TeamSectionPenalties
                                    .Where(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == currentJudgeId)
                                    .Select(p => new TeamSectionPenaltiesViewModel
                                    {
                                        ID = p.ID,
                                        CreatedDateTime = p.CreatedDateTime,
                                        PenaltyID = p.PenaltyID,
                                        JudgeUserID = p.JudgeUserID,
                                        TeamID = p.TeamID,
                                        EventID = p.EventID,
                                        SectionID = p.SectionID,
                                        Comments = p.Comments,
                                        Photo = p.Photo,
                                        Name = p.Penalty.Name,
                                        PenaltyStatusID = p.PenaltyStatusID,
                                        Deduction = p.Deduction,
                                        DeductionMax = p.Penalty.DeductionMax,
                                        DeductionMin = p.Penalty.DeductionMin,
                                        DeductionRange = p.Penalty.DeductionMin + (p.Penalty.DeductionMax != null ? " - " + p.Penalty.DeductionMax : ""),
                                        Questions = db.TeamSectionPenaltyQuestions.Where(q => q.TeamSectionPenaltyID == p.ID).Select(q => new PenaltyQuestionViewModel
                                        {
                                            PenaltyQuestionID = q.PenaltyQuestionID,
                                            PenaltyID = q.PenaltyQuestion.PenaltyID,
                                            QuestionNbr = q.PenaltyQuestion.QuestionNbr,
                                            QuestionText = q.PenaltyQuestion.QuestionText,
                                            AnswerType = q.PenaltyQuestion.AnswerType,
                                            AnswerText = q.AnswerText
                                        }).ToList()
                                    }).ToList(),
                                 Disqualifications = db.TeamSectionDisqualifications
                                    .Where(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == currentJudgeId)
                                    .Select(p => new TeamSectionDisqualificationViewModel
                                    {
                                        ID = p.ID,
                                        CreatedDateTime = p.CreatedDateTime,
                                        DisqualificationID = p.DisqualificationID,
                                        JudgeUserID = p.JudgeUserID,
                                        TeamID = p.TeamID,
                                        EventID = p.EventID,
                                        SectionID = p.SectionID,
                                        Comments = p.Comments,
                                        Photo = p.Photo,
                                        Name = p.Disqualification.Name,
                                    }).ToList()
                             };

                // save detail object
                EventSectionTeamJudgeViewModel est = result.FirstOrDefault();

                // make sure each subsection has a score, provide an empty one if needed
                foreach (SubsectionScoreViewModel sub in est.SubsectionScores)
                {
                    if (sub.Score == null)
                    {
                        sub.Score = new ScoreViewModel()
                        {
                            ID = null,
                            SubsectionID = sub.SubSectionID,
                            JudgeUserID = sub.JudgeUserID,
                            TeamID = sub.TeamID,
                            EventID = sub.EventID,
                            SectionID = sub.SectionID,
                            MaxVal = sub.MaxScore,
                            MinVal = sub.MinScore
                        };
                    }
                }

                // return finished object
                return Ok(est);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getSectionUserByEventandCategory/{eventID}/{categoryID}")]
        public IHttpActionResult GetSectionUserByEventandCategory(int eventID, int categoryID, string judgeID = null)
        {
            try
            {
                var judgeUserID = judgeID != null ? judgeID : HttpContext.Current.User.Identity.GetUserId();
                var user = db.UserEventRoles.FirstOrDefault(s => s.EventID == eventID && s.CategoryID == categoryID && s.UserID == judgeUserID);
                var eventSections = db.EventSections.Where(e => e.EventID == eventID);
                bool isLeadJudge = false;

                if (user.AspNetRole.Name.ToLower() == Utils.Constants.Roles.LEADJUDGE.ToLower())
                {
                    isLeadJudge = true;
                }

                var result = eventSections.Where(e => isLeadJudge || e.JudgeSectionAssignments.Any(j => j.JudgeUserID == judgeUserID))
                    .Select(p => new SectionViewModel
                    {
                        ID = p.SectionID,
                        Name = p.Section.Name,
                        SortOrder = p.Section.SortOrder,
                        CategoryID = p.Section.CategoryID,
                        TimeInOutNeeded = p.Section.TimeInOutNeeded,
                        SubmittedDateTime = p.JudgeSectionAssignments.FirstOrDefault(j => j.JudgeUserID == judgeUserID).SubmittedDateTime,
                        Teams = p.Event.EventTeams.Select(x => new EventTeamViewModel
                        {
                            TeamID = x.TeamID,
                            TeamName = x.Team.Name,
                            CategoryID = x.Team.CategoryID,
                            SchoolName = x.Team.SchoolName,
                            CategoryName = x.Team.Category.Name,
                            StartTime = x.StartTime,
                            EndTime = x.EndTime,
                            SortOrder = x.SortOrder,
                            Done = (db.JudgeSectionAssignments.FirstOrDefault(u => u.EventID == eventID && u.SectionID == p.SectionID && u.JudgeUserID == judgeUserID) != null &&
                            db.JudgeSectionAssignments.FirstOrDefault(u => u.EventID == eventID && u.SectionID == p.SectionID && u.JudgeUserID == judgeUserID).SubmittedDateTime != null) ? true : false,
                            SubsectionScore = p.Section.Subsections
                            .Where(ss => ((isLeadJudge && ss.JudgeSubsectionAssignments.Any(j => j.EventID == eventID))) || ss.JudgeSubsectionAssignments.Any(j => j.JudgeUserID == judgeUserID && j.EventID == eventID))
                            .Select(j => new SubsectionScoreViewModel
                                {
                                    SectionID = j.SectionID,
                                    SubSectionID = j.ID,
                                    SubSectionName = j.Name,
                                    SortIndex = j.SortIndex,
                                    Score = j.Scores.Where(s => s.TeamID == x.TeamID && s.JudgeUserID == judgeUserID && s.EventID == eventID)
                                    .Select(s => new ScoreViewModel()
                                    {
                                        ID = s.ID,
                                        JudgeUserID = s.JudgeUserID,
                                        TeamID = s.TeamID,
                                        EventID = s.EventID,
                                        Score = s.Score1,
                                        Photo = s.Photo,
                                        Comments = s.Comments
                                    }).FirstOrDefault()
                                }).ToList(),
                            TimeIn = x.Team.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.TeamID == x.TeamID && jst.JudgeUserID == judgeUserID && jst.SectionID == p.SectionID && jst.EventID == eventID).TimeIn,
                            TimeOut = x.Team.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.TeamID == x.TeamID && jst.JudgeUserID == judgeUserID && jst.SectionID == p.SectionID && jst.EventID == eventID).TimeOut,
                            Comments = x.Team.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.TeamID == x.TeamID && jst.JudgeUserID == judgeUserID && jst.SectionID == p.SectionID && jst.EventID == eventID).Comments
                        }).Where(v => v.CategoryID == categoryID).OrderBy(o => o.StartTime).ThenBy(et => et.SortOrder).ToList(),
                    }).Where(w => w.CategoryID == categoryID).ToList();
                return Ok(result);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        //[Authorize]
        //[HttpGet]
        //[Route("getUserEventTeamBySection/{id}/category/{categoryID}/section/{sectionID}")]
        //public IHttpActionResult GetUserEventTeamBySection(int id, int categoryID, int sectionID)
        //{
        //    try
        //    {
        //        var e = db.Events.FirstOrDefault(s => s.ID == id);
        //        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        //        var teams = e.Teams.Select(p => new EventTeamViewModel
        //        {
        //            EventID = e.ID,
        //            TeamID = p.ID,
        //            TeamName = p.Name,
        //            CategoryID = p.CategoryID,
        //            SchoolName = p.SchoolName,
        //            Done = (db.JudgeSectionTeamAssignments.FirstOrDefault(s => s.TeamID == p.ID && s.EventID == id && s.SectionID == sectionID && s.JudgeUserID == currentUserID) != null &&
        //            db.JudgeSectionTeamAssignments.FirstOrDefault(s => s.TeamID == p.ID && s.EventID == id && s.SectionID == sectionID && s.JudgeUserID == currentUserID).SubmittedDateTime != null) ? true : false
        //        }).Where(s => s.EventID == id && s.CategoryID == categoryID);
        //        return Ok(teams.ToList());
        //    }
        //    catch (Exception ex)
        //    {
        //        LogUtilities.LogError(ex);
        //        throw;
        //    }
        //}

        [Authorize]
        [HttpGet]
        [Route("getSubsectionByEventSectionAndTeam/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetSubsectionByEventSectionAndTeam(int eventID, int sectionID, int teamID, string judgeID = null, int? categoryID = null)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();

                var result = new List<SubsectionScoreViewModel>();
                var eventSection = db.EventSections.FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID);
                var filteredUserID = judgeID != null ? judgeID : currentUserID;
                var user = db.UserEventRoles.FirstOrDefault(s => s.EventID == eventID && s.CategoryID == categoryID && s.UserID == filteredUserID);
                bool isLeadJudge = false;
                if (user.AspNetRole.Name.ToLower() == Utils.Constants.Roles.LEADJUDGE.ToLower())
                {
                    isLeadJudge = true;
                }

                result = eventSection.Section.Subsections
                    .Where(ss => isLeadJudge ||
                     ss.JudgeSubsectionAssignments.Any(jsa => jsa.JudgeUserID == filteredUserID && jsa.EventID == eventID))
                    .Select(p => new SubsectionScoreViewModel
                    {
                        SubSectionID = p.ID,
                        SubSectionName = p.Name,
                        Description = p.Description,
                        MinScore = p.MinScore,
                        MaxScore = p.MaxScore,
                        SortIndex = p.SortIndex,
                        Criteria = p.Criteria.Select(x => new CriteriaViewModel
                        {
                            Title = x.Title,
                            Description = x.Description,
                            MaxScore = x.MaxScore,
                            MinScore = x.MinScore
                        }).ToList(),
                        Score = p.Scores.Select(x => new ScoreViewModel
                        {
                            ID = x.ID,
                            Score = x.Score1,
                            CreatedDateTime = x.CreatedDateTime,
                            SubsectionID = x.SubsectionID,
                            JudgeUserID = x.JudgeUserID,
                            TeamID = x.TeamID,
                            EventID = x.EventID,
                            SectionID = p.SectionID,
                            Comments = x.Comments,
                            Photo = x.Photo
                        }).FirstOrDefault(u => u.EventID == eventID && u.TeamID == teamID && u.JudgeUserID == filteredUserID)
                    }).ToList();
                return Ok(result);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

    [Authorize]
    [HttpGet]
    [Route("getEventCategoryPenalties/{eventID}/{categoryID}")]
    public IHttpActionResult GetEventCategoryPenalties(int eventID, int categoryID)
    {
      try 
      {
        var penalties = db.TeamSectionPenalties
          .Where(tsp => tsp.EventID == eventID && tsp.Section.CategoryID == categoryID)
          .Select(p => new EventCategoryPenaltyViewModel
          {
            ID = p.ID,
            CreatedDateTime = p.CreatedDateTime,
            PenaltyID = p.PenaltyID,
            Penalty = p.Penalty.Name,
            Comments = p.Comments,
            Photo = p.Photo,
            EventID = p.EventID,
            TeamID = p.TeamID,
            Team = p.Team.Name,
            JudgeUserID = p.JudgeUserID,
            JudgeLastName = p.AspNetUser.LastName,
            JudgeFirstName = p.AspNetUser.FirstName,
            JudgeUserName = p.AspNetUser.UserName,
            SectionID = p.SectionID,
            Section = p.Section.Name,
            Deduction = p.Deduction,
            DeductionMax = p.Penalty.DeductionMax,
            DeductionMin = p.Penalty.DeductionMin,
            DeductionRange = p.Penalty.DeductionMin + (p.Penalty.DeductionMax != null ? " - " + p.Penalty.DeductionMax : ""),
            UpdatedUserID = p.UpdatedUserID,
            Questions = db.TeamSectionPenaltyQuestions.Where(q => q.TeamSectionPenaltyID == p.ID).Select(q => new PenaltyQuestionViewModel
            {
              PenaltyQuestionID = q.PenaltyQuestionID,
              PenaltyID = q.PenaltyQuestion.PenaltyID,
              QuestionNbr = q.PenaltyQuestion.QuestionNbr,
              QuestionText = q.PenaltyQuestion.QuestionText,
              AnswerType = q.PenaltyQuestion.AnswerType,
              AnswerText = q.AnswerText
            }).ToList(),
            PenaltyStatusID = p.PenaltyStatusID,
            StatusCode = p.PenaltyStatu.StatusCode,
            StatusName = p.PenaltyStatu.StatusName
          })
          .ToList();

        return Ok(penalties);
      }
      catch (Exception ex)
      {
          LogUtilities.LogError(ex);
          throw;
      }
    }

        [Authorize]
        [HttpGet]
        [Route("getTeamSectionPenalties/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetTeamSectionPenalties(int eventID, int sectionID, int teamID, [FromUri] string judgeID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var penalties = db.TeamSectionPenalties
                    .Where(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == (judgeID != "null" ? judgeID : currentUserID))
                    .Select(p => new TeamSectionPenaltiesViewModel
                    {
                      ID = p.ID,
                      CreatedDateTime = p.CreatedDateTime,
                      PenaltyID = p.PenaltyID,
                      JudgeUserID = p.JudgeUserID,
                      TeamID = p.TeamID,
                      EventID = p.EventID,
                      SectionID = p.SectionID,
                      Comments = p.Comments,
                      Photo = p.Photo,
                      Name = p.Penalty.Name,
                      PenaltyStatusID = p.PenaltyStatusID,
                      Deduction = p.Deduction,
                      DeductionMax = p.Penalty.DeductionMax,
                      DeductionMin = p.Penalty.DeductionMin,
                      DeductionRange = p.Penalty.DeductionMin + (p.Penalty.DeductionMax != null ? " - " + p.Penalty.DeductionMax : ""),
                      Questions = db.TeamSectionPenaltyQuestions.Where(q => q.TeamSectionPenaltyID == p.ID).Select(q => new PenaltyQuestionViewModel
                      {
                        PenaltyQuestionID = q.PenaltyQuestionID,
                        PenaltyID = q.PenaltyQuestion.PenaltyID,
                        QuestionNbr = q.PenaltyQuestion.QuestionNbr,
                        QuestionText = q.PenaltyQuestion.QuestionText,
                        AnswerType = q.PenaltyQuestion.AnswerType,
                        AnswerText = q.AnswerText
                      }).ToList()
                    }).ToList();
                return Ok(penalties);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getTeamSectionDisqualification/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetTeamSectionDisqualification(int eventID, int sectionID, int teamID, [FromUri] string judgeID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var disqualifications = db.TeamSectionDisqualifications.Where(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == (judgeID != "null" ? judgeID : currentUserID)).Select(p => new TeamSectionDisqualificationViewModel
                {
                    ID = p.ID,
                    CreatedDateTime = p.CreatedDateTime,
                    DisqualificationID = p.DisqualificationID,
                    JudgeUserID = p.JudgeUserID,
                    TeamID = p.TeamID,
                    EventID = p.EventID,
                    SectionID = p.SectionID,
                    Comments = p.Comments,
                    Photo = p.Photo,
                    Name = p.Disqualification.Name,
                }).ToList();
                return Ok(disqualifications);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }

        }

        [Authorize]
        [HttpGet]
        [Route("getEventSectionPenalty/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetEventSectionPenalty(int eventID, int sectionID, int teamID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var listPenaltiedIDSelected = db.TeamSectionPenalties
                    .Where(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == currentUserID)
                    .Select(p => p.PenaltyID);
                var penalties = db.EventSections
                    .FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID).Section.Penalties
                    .Where(p => listPenaltiedIDSelected.Contains(p.ID) == false).Select(x => new PenaltyViewModel
                    {
                      ID = x.ID,
                      Name = x.Name,
                      DeductionRange = x.DeductionMin + (x.DeductionMax != null ? " - " + x.DeductionMax : ""),
                      DeductionMin = x.DeductionMin,
                      DeductionMax = x.DeductionMax,
                      Questions = x.PenaltyQuestions.Select(q => new PenaltyQuestionViewModel
                      {
                        PenaltyQuestionID = q.ID,
                        PenaltyID = x.ID,
                        QuestionNbr = q.QuestionNbr,
                        QuestionText = q.QuestionText,
                        AnswerType = q.AnswerType
                      }).ToList()
                    }).ToList();
                return Ok(penalties);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventSectionDisqualification/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetEventSectionDisqualification(int eventID, int sectionID, int teamID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var listDisqualificationsIDSelected = db.TeamSectionDisqualifications.Where(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == currentUserID).Select(p => p.DisqualificationID);
                var disqualifications = db.EventSections.FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID).Section.Disqualifications.Where(p => listDisqualificationsIDSelected.Contains(p.ID) == false).Select(x => new PenaltyViewModel
                {
                    ID = x.ID,
                    Name = x.Name,
                }).ToList();
                return Ok(disqualifications);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addTeamSectionPenalty")]
        public IHttpActionResult AddTeamSectionPenalty([FromBody] TeamSectionPenaltiesViewModel model)
        {
            try
            {
                if (CheckStartedEvent(model.EventID) == false)
                {
                  throw new Exception("This competition has not started yet.");
                }
                if (CheckCompledtedEvent(model.EventID) == true)
                {
                  throw new Exception("This competition is marked as complete and judging is done.");
                }
                if (CheckSubmitedDate(model.EventID, model.SectionID, model.TeamID) == true)
                {
                  throw new Exception("You are not assigned as a judge to this event.");
                }
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                TeamSectionPenalty teamSectionPenalty = new TeamSectionPenalty();
                teamSectionPenalty.CreatedDateTime = DateTimeOffset.Now;
                teamSectionPenalty.PenaltyID = model.PenaltyID;
                teamSectionPenalty.JudgeUserID = (model.JudgeUserID == null ? currentUserID : model.JudgeUserID);
                teamSectionPenalty.TeamID = model.TeamID;
                teamSectionPenalty.EventID = model.EventID;
                teamSectionPenalty.SectionID = model.SectionID;
                teamSectionPenalty.Comments = model.Comments;
                teamSectionPenalty.Photo = model.Photo;
                teamSectionPenalty.Deduction = model.Deduction;
                teamSectionPenalty.PenaltyStatusID = model.PenaltyStatusID;
                teamSectionPenalty.UpdatedUserID = currentUserID;
                db.TeamSectionPenalties.Add(teamSectionPenalty);
                foreach (PenaltyQuestionViewModel pq in model.Questions)
                {
                  db.TeamSectionPenaltyQuestions.Add(new TeamSectionPenaltyQuestion()
                  {
                    TeamSectionPenaltyID = teamSectionPenalty.ID,
                    PenaltyQuestionID = pq.PenaltyQuestionID,
                    AnswerText = pq.AnswerText
                  });
                }
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return BadRequest(ex.Message);
            }
        }

    [Authorize]
    [HttpPost]
    [Route("editTeamSectionPenaltyStatus")]
    public IHttpActionResult EditTeamSectionPenaltyStatus([FromBody] TeamSectionPenaltyStatusViewModel model)
    {
      try
      {
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        var pen = db.TeamSectionPenalties.FirstOrDefault(s => s.ID == model.ID);
        if (pen == null)
        {
          throw new Exception("That penalty does not exist.");
        }
        else
        {
          if (CheckStartedEvent(pen.EventID) == false)
          {
            throw new Exception("This competition has not started yet.");
          }
          if (CheckCompledtedEvent(pen.EventID) == true)
          {
            throw new Exception("This competition is marked as complete and judging is done.");
          }
          if (!(checkCurrentUserLeadJudge(pen.EventID, pen.Section.CategoryID, db) || EventAdmin.CheckEventRoles(currentUserID,pen.EventID)))
          {
            throw new Exception("You are not authorized to change the status of this penalty.");
          }
          // all good, update status and save
          pen.PenaltyStatusID = model.PenaltyStatusID;
          db.Entry(pen).State = EntityState.Modified;
          db.SaveChanges();
        }

        return Ok();
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        return BadRequest(ex.Message);
      }
    }

        [Authorize]
        [HttpPut]
        [Route("editTeamSectionPenalty")]
        public IHttpActionResult EditTeamSectionPenalty([FromBody] TeamSectionPenaltiesViewModel model)
        {
            try
            {
                if (CheckStartedEvent(model.EventID) == false)
                {
                  throw new Exception("This competition has not started yet.");
                }
                if (CheckCompledtedEvent(model.EventID) == true)
                {
                  throw new Exception("This competition is marked as complete and judging is done.");
                }
                if (CheckSubmitedDate(model.EventID, model.SectionID, model.TeamID) == true)
                {
                  throw new Exception("You are not assigned as a judge to this event.");
                }
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var pen = db.TeamSectionPenalties.FirstOrDefault(s => s.ID == model.ID && s.JudgeUserID == (model.JudgeUserID == null ? currentUserID : model.JudgeUserID));
                pen.Comments = model.Comments;
                pen.Deduction = model.Deduction;
                pen.Photo = model.Photo;
                pen.PenaltyStatusID = model.PenaltyStatusID;
                pen.UpdatedUserID = currentUserID;
                db.Entry(pen).State = EntityState.Modified;
                foreach (PenaltyQuestionViewModel pq in model.Questions)
                {
                  TeamSectionPenaltyQuestion teamSectionPenaltyQuestion = db.TeamSectionPenaltyQuestions
                    .FirstOrDefault(x => x.PenaltyQuestionID == pq.PenaltyQuestionID && x.TeamSectionPenaltyID == pen.ID);
                  if (teamSectionPenaltyQuestion == null)
                    db.TeamSectionPenaltyQuestions.Add(new TeamSectionPenaltyQuestion()
                    {
                      TeamSectionPenaltyID = pen.ID,
                      PenaltyQuestionID = pq.PenaltyQuestionID,
                      AnswerText = pq.AnswerText
                    });
                  else
                    teamSectionPenaltyQuestion.AnswerText = pq.AnswerText;
                }
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpDelete]
        [Route("deleteTeamSectionPenalty/{id}")]
        public IHttpActionResult DeleteTeamSectionPenalty(int id)
        {
            try
            {
                //var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var pen = db.TeamSectionPenalties.FirstOrDefault(s => s.ID == id);  //&& s.JudgeUserID == currentUserID);
                pen.TeamSectionPenaltyQuestions.Clear();
                db.TeamSectionPenalties.Remove(pen);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addTeamSectionDisqualification")]
        public IHttpActionResult AddTeamSectionDisqualification([FromBody] TeamSectionDisqualificationViewModel model)
        {
            try
            {
                if (CheckStartedEvent(model.EventID) == false)
                {
                  throw new Exception("This competition has not started yet.");
                }
                if (CheckCompledtedEvent(model.EventID) == true)
                {
                  throw new Exception("This competition is marked as complete and judging is done.");
                }
                if (CheckSubmitedDate(model.EventID, model.SectionID, model.TeamID) == true)
                {
                  throw new Exception("You are not assigned as a judge to this event.");
                }
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                TeamSectionDisqualification teamSectionDisqualification = new TeamSectionDisqualification();
                teamSectionDisqualification.CreatedDateTime = DateTimeOffset.Now;
                teamSectionDisqualification.DisqualificationID = model.DisqualificationID;
                teamSectionDisqualification.JudgeUserID = (model.JudgeUserID == null ? currentUserID : model.JudgeUserID);
                teamSectionDisqualification.TeamID = model.TeamID;
                teamSectionDisqualification.EventID = model.EventID;
                teamSectionDisqualification.SectionID = model.SectionID;
                teamSectionDisqualification.Comments = model.Comments;
                teamSectionDisqualification.Photo = model.Photo;
                teamSectionDisqualification.UpdatedUserID = currentUserID;
                db.TeamSectionDisqualifications.Add(teamSectionDisqualification);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPut]
        [Route("editTeamSectionDisqualification")]
        public IHttpActionResult EditTeamSectionDisqualification([FromBody] TeamSectionDisqualificationViewModel model)
        {
            try
            {
                if (CheckStartedEvent(model.EventID) == false)
                {
                  throw new Exception("This competition has not started yet.");
                }
                if (CheckCompledtedEvent(model.EventID) == true)
                {
                  throw new Exception("This competition is marked as complete and judging is done.");
                }
                if (CheckSubmitedDate(model.EventID, model.SectionID, model.TeamID) == true)
                {
                  throw new Exception("You are not assigned as a judge to this event.");
                }
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var dis = db.TeamSectionDisqualifications.FirstOrDefault(s => s.ID == model.ID && s.JudgeUserID == (model.JudgeUserID == null ? currentUserID : model.JudgeUserID));
                dis.Comments = model.Comments;
                dis.Photo = model.Photo;
                dis.UpdatedUserID = currentUserID;
                db.Entry(dis).State = EntityState.Modified;
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpDelete]
        [Route("deleteTeamSectionDisqualification/{id}")]
        public IHttpActionResult DeleteTeamSectionDisqualification(int id)
        {
            try
            {
                //var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var dis = db.TeamSectionDisqualifications.FirstOrDefault(s => s.ID == id);  // && s.JudgeUserID == currentUserID);
                db.TeamSectionDisqualifications.Remove(dis);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return BadRequest(ex.Message);
            }
        }


        [Authorize]
        [HttpGet]
        [Route("getTeamSectionSubsectionDetail/{eventID}/{sectionID}/{teamID}/{subsectionID}")]
        public IHttpActionResult GetTeamSectionSubsectionDetail(int eventID, int sectionID, int teamID, int subsectionID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var subSection = db.Scores.Where(s => s.EventID == eventID && s.SubsectionID == subsectionID && s.TeamID == teamID).Select(p => new SubsectionScoreViewModel
                {
                    SubSectionID = p.SubsectionID,
                    SubSectionName = p.Subsection.Name,
                    Description = p.Subsection.Description,
                    MinScore = p.Subsection.MinScore,
                    MaxScore = p.Subsection.MaxScore,
                    Criteria = db.Criteria.Where(v => v.SubsectionId == subsectionID).Select(x => new CriteriaViewModel
                    {
                        Title = x.Title,
                        Description = x.Description,
                        MaxScore = x.MaxScore,
                        MinScore = x.MinScore
                    }).ToList(),
                    Score =
                    {
                        ID = p.ID,
                        Score = p.Score1,
                        CreatedDateTime = p.CreatedDateTime,
                        SubsectionID = p.SubsectionID,
                        JudgeUserID = p.JudgeUserID,
                        TeamID = p.TeamID,
                        EventID = p.EventID,
                        SectionID = p.Subsection.SectionID,
                        Comments = p.Comments,
                        Photo = p.Photo
                    }
                }).FirstOrDefault(s => s.SubSectionID == subsectionID);
                return Ok(subSection);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addEditScore")]
        public IHttpActionResult AddEditScore([FromBody] SubsectionScoreViewModel model)
        {
            try
            {
                var scoreId = 0;
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var judgeUserID = model.JudgeUserID == null ? currentUserID : model.JudgeUserID;
                var user = db.UserEventRoles.FirstOrDefault(s => s.EventID == model.EventID && s.CategoryID == model.CategoryID && s.UserID == currentUserID);
                var judgeSubsectionAssignment = db.JudgeSubsectionAssignments.FirstOrDefault(f => f.EventID == model.EventID && f.JudgeUserID == judgeUserID && f.SubsectionID == model.SubSectionID);
                if (judgeSubsectionAssignment == null && user.AspNetRole.Name.ToLower() != Utils.Constants.Roles.LEADJUDGE.ToLower())
                {
                    return Unauthorized();
                }
                if (CheckStartedEvent(model.EventID) == false)
                {
                    return BadRequest();
                }
                if (CheckCompledtedEvent(model.EventID) == true)
                {
                    return BadRequest();
                }
                if (CheckSubmitedDate(model.EventID, model.SectionID, model.TeamID) == true)
                {
                    return BadRequest();
                }
                if (model.Score.ID == null)
                {
                    Score score = new Score();
                    score.Score1 = model.Score.Score;
                    score.CreatedDateTime = DateTimeOffset.Now;
                    score.SubsectionID = model.SubSectionID;
                    score.JudgeUserID = judgeUserID;
                    score.TeamID = model.TeamID;
                    score.EventID = model.EventID;
                    score.Comments = model.Score.Comments;
                    score.Photo = model.Score.Photo;
                    score.UpdatedUserID = currentUserID;
                    db.Scores.Add(score);
                    db.SaveChanges();
                    scoreId = score.ID;
                }
                else
                {
                    var score = db.Scores.FirstOrDefault(s => s.ID == model.Score.ID);
                    score.Comments = model.Score.Comments;
                    score.Photo = model.Score.Photo;
                    score.Score1 = model.Score.Score;
                    score.UpdatedUserID = currentUserID;
                    db.Entry(score).State = EntityState.Modified;
                    db.SaveChanges();
                    scoreId = score.ID;
                }
                return Ok(scoreId);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPut]
        [Route("submitScore/{eventID}/{sectionID}/{categoryID}")]
        public IHttpActionResult SubmitScore(int eventID, int sectionID, int categoryID)
        {
            try
            {
                if (CheckStartedEvent(eventID) == false)
                {
                    return BadRequest();
                }
                if (CheckCompledtedEvent(eventID) == true)
                {
                    return BadRequest();
                }
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var judgeSectionAssignment = db.JudgeSectionAssignments.FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.JudgeUserID == currentUserID);
                if (judgeSectionAssignment == null)
                {
                    judgeSectionAssignment = new JudgeSectionAssignment()
                    {
                        JudgeUserID = currentUserID,
                        EventID = eventID,
                        SectionID = sectionID,
                    };
                    judgeSectionAssignment.SubmittedDateTime = DateTimeOffset.Now;
                    db.JudgeSectionAssignments.Add(judgeSectionAssignment);
                }
                else
                {
                    judgeSectionAssignment.SubmittedDateTime = DateTimeOffset.Now;
                    db.Entry(judgeSectionAssignment).State = EntityState.Modified;
                }

                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getJudgeSectionAssignmentByUserID/{eventID}/{sectionID}")]
        public IHttpActionResult GetJudgeSectionAssignmentByUserID(int eventID, int sectionID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var judgeSectionAssignment = db.JudgeSectionAssignments.Select(p => new JudgeSectionAssignmentViewModel
                {
                    JudgeUserID = p.JudgeUserID,
                    SectionID = p.SectionID,
                    EventID = p.EventID,
                    SubmittedDateTime = p.SubmittedDateTime,
                }).FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.JudgeUserID == currentUserID);
                return Ok(judgeSectionAssignment);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getJudgeSectionAssignmentByUserID/{eventID}/{sectionID}/{judgeID}")]
        public IHttpActionResult GetJudgeSectionAssignmentByUserID(int eventID, int sectionID, string judgeID)
        {
            try
            {
                var judgeSectionAssignment = db.JudgeSectionAssignments.Select(p => new JudgeSectionAssignmentViewModel
                {
                    JudgeUserID = p.JudgeUserID,
                    SectionID = p.SectionID,
                    EventID = p.EventID,
                    SubmittedDateTime = p.SubmittedDateTime,
                }).FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.JudgeUserID == judgeID);
                return Ok(judgeSectionAssignment);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        //[Authorize]
        //[HttpPut]
        //[Route("submitJudgeSectionTeamAssignment/{eventID}/{sectionID}/{teamID}")]
        //public IHttpActionResult SubmitJudgeSectionTeamAssignment(int eventID, int sectionID, int teamID)
        //{
        //    try
        //    {
        //        if (CheckStartedEvent(eventID) == false)
        //        {
        //            return BadRequest();
        //        }
        //        if (CheckCompledtedEvent(eventID) == true)
        //        {
        //            return BadRequest();
        //        }
        //        var currentUserID = HttpContext.Current.User.Identity.GetUserId();

        //        var subSections = db.JudgeSubsectionAssignments.Any(s=>s.EventID == eventID && s.Subsection.SectionID == sectionID && s.TeamID == teamID && s.Score1).FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID).Section.Subsections.Select(p => new SubsectionScoreViewModel
        //        {
        //            SubSectionID = p.ID,
        //            SubSectionName = p.Name,
        //            Score = p.Scores.Select(x => new ScoreViewModel
        //            {
        //                ID = x.ID,
        //                JudgeUserID = x.JudgeUserID,
        //                TeamID = x.TeamID,
        //            }).FirstOrDefault(u => u.TeamID == teamID && u.JudgeUserID == currentUserID)
        //        }).ToList();

        //        for (var i = 0; i < subSections.Count; i++)
        //        {
        //            if (subSections[i].Score == null)
        //            {
        //                return BadRequest();
        //            }
        //        }

        //        var judgeSectionTeamAssignment = db.JudgeSectionTeamAssignments.FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.JudgeUserID == currentUserID && s.TeamID == teamID);
        //        judgeSectionTeamAssignment.SubmittedDateTime = DateTimeOffset.Now;
        //        db.Entry(judgeSectionTeamAssignment).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        LogUtilities.LogError(ex);
        //        throw;
        //    }
        //}

        //[Authorize]
        //[HttpGet]
        //[Route("getJudgeSectionTeamAssignments/{eventID}/{sectionID}/{teamID}")]
        //public IHttpActionResult GetJudgeSectionTeamAssignments(int eventID, int sectionID, int teamID)
        //{
        //    try
        //    {
        //        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        //        var judgeSectionTeamAssignments = db.JudgeSectionTeamAssignments.Select(p => new JudgeSectionTeamAssignmentsViewModel
        //        {
        //            JudgeUserID = p.JudgeUserID,
        //            TeamID = p.TeamID,
        //            EventID = p.EventID,
        //            SectionID = p.SectionID,
        //            SubmittedDateTime = p.SubmittedDateTime
        //        }).FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID && s.JudgeUserID == currentUserID);
        //        return Ok(judgeSectionTeamAssignments);
        //    }
        //    catch (Exception ex)
        //    {
        //        LogUtilities.LogError(ex);
        //        throw;
        //    }
        //}

        [Authorize]
        [HttpPost]
        [Route("endEvent/{id}")]
        public IHttpActionResult EndEvent(int id)
        {
            try
            {
                var completedStatus = db.EventStatus.FirstOrDefault(s => s.StatusName == Utils.Constants.EventStatuses.COMPLETED);
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                EventStatusLog eventStatusLog = new EventStatusLog();
                eventStatusLog.LoggedDateTime = DateTimeOffset.Now;
                eventStatusLog.LoggedBy = currentUserID;
                eventStatusLog.EventID = id;
                eventStatusLog.EventStatusID = completedStatus.ID;
                db.EventStatusLogs.Add(eventStatusLog);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getCategoryByEventAdmin/{eventID}")]
        public IHttpActionResult GetCategoryByEventAdmin(int eventID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();

                var eventAdminRole = db.AspNetRoles.FirstOrDefault(s => s.Name == Utils.Constants.Roles.EVENTADMIN);
                var listCategoryName = db.UserEventRoles.Where(s => s.UserID == currentUserID && s.EventID == eventID && s.RoleID == eventAdminRole.Id).Select(x => x.Category.Name).ToList();
                return Ok(listCategoryName);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getSubsectionByJudgeAndSection")]
        public IHttpActionResult GetSubsectionByJudgeAndSection(string judgeID, int? sectionID, int? eventID)
        {
            try
            {
                using (var db = new NPSIEntities())
                {
                    if (string.IsNullOrEmpty(judgeID) || sectionID == null || eventID == null)
                    {
                        return BadRequest();
                    }
                    var subsections = db.JudgeSubsectionAssignments
                        .Where(w => w.JudgeUserID == judgeID && w.Subsection.SectionID == sectionID && w.EventID == eventID)
                        .Select(j => new SubsectionViewModel
                        {
                            ID = j.SubsectionID,
                            Name = j.Subsection.Name,
                            Active = j.Subsection.Active,
                            CategoryName = db.Categories.FirstOrDefault(c => c.ID == j.Subsection.Section.CategoryID).Name,
                            Criteria = j.Subsection.Criteria.Select(c => new CriteriaViewModel
                            {
                                Title = c.Title,
                                Description = c.Description,
                                MaxScore = c.MaxScore,
                                MinScore = c.MinScore,
                                SubsectionId = c.SubsectionId
                            }).ToList(),
                            Description = j.Subsection.Description,
                            MaxScore = j.Subsection.MaxScore,
                            MinScore = j.Subsection.MinScore,
                            SectionID = j.Subsection.SectionID,
                            SortIndex = j.Subsection.SortIndex
                        });
                    return Ok(subsections.ToList());
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpPost]
        [Route("addSubsectionForJudge")]
        public IHttpActionResult AddSubsectionForJudge(string judgeID, int eventID, int categoryID, int sectionID, [FromBody] List<JugdeSubsectionAssignmentViewModel> model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, eventID) == false)
                {
                    return Unauthorized();
                }
                using (NPSIEntities db = new NPSIEntities())
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var judgeSubsectionAssigmentList = db.JudgeSubsectionAssignments
                                .Where(w => w.JudgeUserID == judgeID && w.EventID == eventID && w.Subsection.SectionID == sectionID)
                                .Select(a => new JugdeSubsectionAssignmentViewModel
                                {
                                    SubsectionID = a.SubsectionID,
                                    EventID = a.EventID,
                                    JudgeUserID = a.JudgeUserID,
                                    SubsectionName = a.Subsection.Name
                                }).ToList();
                            var objTemp = checkDiffJudgeSubsectionAssignment(model, judgeSubsectionAssigmentList);
                            foreach (var item in objTemp.ListAdd)
                            {
                                var jugdeSubsectionAssignment = new JudgeSubsectionAssignment
                                {
                                    JudgeUserID = judgeID,
                                    SubsectionID = item.SubsectionID,
                                    EventID = eventID
                                };
                                db.JudgeSubsectionAssignments.Add(jugdeSubsectionAssignment);
                            }
                            foreach (var item in objTemp.ListRemove)
                            {
                                var score = db.Scores.FirstOrDefault(s => s.Team.CategoryID == categoryID && s.SubsectionID == item.SubsectionID && s.EventID == eventID && s.JudgeUserID == judgeID);
                                if (score != null)
                                {
                                    dbTransaction.Rollback();
                                    return Content(HttpStatusCode.BadRequest, "Scores existed at subsection " + score.Subsection.Name + ".");
                                }
                                db.JudgeSubsectionAssignments.Remove(db.JudgeSubsectionAssignments.FirstOrDefault(w => w.EventID == eventID && w.SubsectionID == item.SubsectionID && w.JudgeUserID == judgeID));
                            }

                            db.SaveChanges();
                            dbTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbTransaction.Rollback();
                            LogUtilities.LogError(ex);
                            return Content(HttpStatusCode.InternalServerError, "An unknown server error occurred.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return Content(HttpStatusCode.InternalServerError, "An unknown server error occurred.");
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getEventsByReportType")]
        public IHttpActionResult GetEventsByReportType(int reportType)
        {
            try
            {
                var statusID = db.EventStatus.FirstOrDefault(es => reportType == 1 || reportType == 2 ? (es.StatusName.ToLower() == Utils.Constants.EventStatuses.STARTED.ToLower()) : es.StatusName.ToLower() == Utils.Constants.EventStatuses.COMPLETED.ToLower()).ID;
                var results = db.Events
                    .Where(e => e.EventStatusLogs.Any(esl => esl.EventStatusID == statusID))
                    .Select(e => new EventViewModel
                    {
                        ID = e.ID,
                        Name = e.Name,
                    })
                    .ToList();
                return Ok(results);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpPut]
        [Route("updateEventTeam/{eventID}/team/{teamID}")]
        public IHttpActionResult UpdateEventTeam([FromUri] int eventID, [FromUri] int teamID, [FromBody] EventTeamViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                if (EventAdmin.CheckEventRoles(currentUserID, model.EventID) == false)
                {
                    return Unauthorized();
                }

                using (var db = new NPSIEntities())
                {
                    using (var dbcxtTranctions = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var eventTeam = db.EventTeams.FirstOrDefault(et => et.EventID == eventID && et.TeamID == teamID);
                            if (eventTeam == null)
                            {
                                dbcxtTranctions.Rollback();
                                return NotFound();
                            }
                            eventTeam.StartTime = model.StartTime;
                            eventTeam.EndTime = model.EndTime;
                            eventTeam.SortOrder = model.SortOrder;
                            db.SaveChanges();
                            dbcxtTranctions.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            LogUtilities.LogError(ex);
                            return InternalServerError();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getJudgeByEventAndCategory")]
        public IHttpActionResult GetJudgeByEventAndCategory(int eventID, int categoryID)
        {
            try
            {
                var results = db.JudgeSectionAssignments
                   .Where(w => w.EventID == eventID && w.EventSection.Section.CategoryID == categoryID)
                   .Select(j => new JudgeSectionAssignmentViewModel
                   {
                       JudgeUserID = j.JudgeUserID,
                       EventID = j.EventID,
                       FirstName = db.AspNetUsers.FirstOrDefault(u => u.Id == j.JudgeUserID).FirstName,
                       LastName = db.AspNetUsers.FirstOrDefault(u => u.Id == j.JudgeUserID).LastName,
                   }).Distinct().ToList();
                return Ok(results);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpGet]
        [Route("checkCurrentUserLeadJudge")]
        public IHttpActionResult CheckCurrentUserLeadJudge(int eventID, int categoryID)
        {
            try
            {
                var isLeadJudge = checkCurrentUserLeadJudge(eventID, categoryID, db);
                if (isLeadJudge)
                {
                    return Ok(true);
                }
                return Ok(false);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

    [Authorize]
    [HttpPost]
    [Route("addUpdateJudgeSectionComment")]
    public IHttpActionResult AddUpdateJudgeSectionComment([FromBody] JudgeSectionTimeInOutViewModel model)
    {
      try
      {
        var submittedDateTime = db.Events.FirstOrDefault(e => e.ID == model.EventID)
          .EventSections.FirstOrDefault(es => es.EventID == model.EventID && es.SectionID == model.SectionID)
          .JudgeSectionAssignments.FirstOrDefault(j => j.JudgeUserID == model.JudgeUserID).SubmittedDateTime;
        if (submittedDateTime == null)
        {
          var judgeSectionTime = db.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == model.EventID 
            && jst.JudgeUserID == model.JudgeUserID && jst.SectionID == model.SectionID && jst.TeamID == model.TeamID);
          if (judgeSectionTime == null)
          {
            var judgeSection = new JudgeSectionTeamInOut
            {
              TeamID = model.TeamID,
              EventID = model.EventID,
              JudgeUserID = model.JudgeUserID,
              SectionID = model.SectionID,
              Comments = model.GeneralComments
            };
            db.JudgeSectionTeamInOuts.Add(judgeSection);
            db.SaveChanges();
          }
          else
          {
            judgeSectionTime.Comments = model.GeneralComments;
            db.SaveChanges();
          }
          return Ok();
        }
        else
        {
          return BadRequest();
        }
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        return InternalServerError();
      }
    }

        [Authorize]
        [HttpPost]
        [Route("addUpdateJudgeSectionTimeInOut")]
        public IHttpActionResult AddUpdateJudgeSectionTimeInOut([FromBody] JudgeSectionTimeInOutViewModel model)
        {
            try
            {
                var submittedDateTime = db.Events.FirstOrDefault(e => e.ID == model.EventID).EventSections
                     .FirstOrDefault(es => es.EventID == model.EventID && es.SectionID == model.SectionID)
                     .JudgeSectionAssignments.FirstOrDefault(j => j.JudgeUserID == model.JudgeUserID).SubmittedDateTime;
                if (submittedDateTime == null)
                {
                    var judgeSectionTime = db.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == model.EventID && jst.JudgeUserID == model.JudgeUserID && jst.SectionID == model.SectionID && jst.TeamID == model.TeamID);
                    if (judgeSectionTime == null)
                    {
                        var judgeSection = new JudgeSectionTeamInOut
                        {
                            TeamID = model.TeamID,
                            EventID = model.EventID,
                            JudgeUserID = model.JudgeUserID,
                            SectionID = model.SectionID,
                            TimeIn = model.TimeIn,
                            TimeOut = model.TimeOut,
                        };
                        db.JudgeSectionTeamInOuts.Add(judgeSection);
                        db.SaveChanges();
                    }
                    else
                    {
                        judgeSectionTime.TimeOut = model.TimeOut;
                        judgeSectionTime.TimeIn = model.TimeIn;
                        db.SaveChanges();
                    }
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getTeamSectionDetail/{eventID}/{sectionID}/{teamID}")]
        public IHttpActionResult GetTeamSectionDetail(int eventID, int sectionID, int teamID, string judgeID)
        {
            try
            {
                var eventDetail = db.Events.Where(e => e.ID == eventID)
                    .Select(e => new TeamSectionDetailViewModel
                    {
                        EventID = e.ID,
                        EventName = e.Name,
                        StatusName = e.EventStatusLogs.OrderByDescending(p => p.LoggedDateTime).FirstOrDefault().EventStatu.StatusName,
                        TeamID = e.EventTeams.FirstOrDefault(et => et.EventID == eventID && et.TeamID == teamID).TeamID,
                        TeamName = e.EventTeams.FirstOrDefault(et => et.EventID == eventID && et.TeamID == teamID).Team.Name,
                        CategoryID = e.EventTeams.FirstOrDefault(et => et.EventID == eventID && et.TeamID == teamID).Team.CategoryID,
                        CategoryName = e.EventTeams.FirstOrDefault(et => et.EventID == eventID && et.TeamID == teamID).Team.Category.Name,
                        SectionID = e.EventSections.FirstOrDefault(es => es.EventID == eventID && es.SectionID == sectionID).SectionID,
                        SectionName = e.EventSections.FirstOrDefault(es => es.EventID == eventID && es.SectionID == sectionID).Section.Name,
                        Description = e.EventSections.FirstOrDefault(es => es.EventID == eventID && es.SectionID == sectionID).Section.Description,
                        Active = e.EventSections.FirstOrDefault(es => es.EventID == eventID && es.SectionID == sectionID).Section.Active,
                        SortOrder = e.EventSections.FirstOrDefault(es => es.EventID == eventID && es.SectionID == sectionID).Section.SortOrder,
                        TimeIn = e.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == eventID && jst.SectionID == sectionID && jst.JudgeUserID == judgeID && jst.TeamID == teamID).TimeIn,
                        TimeOut = e.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == eventID && jst.SectionID == sectionID && jst.JudgeUserID == judgeID && jst.TeamID == teamID).TimeOut,
                        TimeInOutNeeded = e.EventSections.FirstOrDefault(et => et.EventID == eventID && et.SectionID == sectionID).Section.TimeInOutNeeded,
                        GeneralComments = e.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == eventID && jst.SectionID == sectionID && jst.JudgeUserID == judgeID && jst.TeamID == teamID).Comments
                    }).FirstOrDefault();
                return Ok(eventDetail);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [HttpGet]
        [Route("getNextPreviousTeamID")]
        public IHttpActionResult GetNextPreviousTeamID(int eventID, int sectionID, short categoryID, int teamID)
        {
            try
            {
                var result = new NextPreviousTeam();
                var judgeSectionTeamInOuts = db.EventTeams
                    .Where(jst => jst.EventID == eventID && jst.Team.CategoryID == categoryID)
                   .Select(jst => new EventTeamViewModel
                   {
                       TeamID = jst.TeamID,
                       StartTime = jst.StartTime,
                       SortOrder = jst.SortOrder,
                   }).OrderBy(jst => jst.StartTime).ThenBy(et => et.SortOrder).ToList();
                if (judgeSectionTeamInOuts.Count > 1)
                {
                    for (var i = 0; i < judgeSectionTeamInOuts.Count; i++)
                    {
                        if (judgeSectionTeamInOuts[i].TeamID == teamID)
                        {
                            if (i == 0)
                            {
                                result.NextTeamID = judgeSectionTeamInOuts[i + 1].TeamID;
                                result.PreviousTeamID = null;
                            }
                            else if (i == judgeSectionTeamInOuts.Count - 1)
                            {
                                result.NextTeamID = null;
                                result.PreviousTeamID = judgeSectionTeamInOuts[i - 1].TeamID;
                            }
                            else
                            {
                                result.NextTeamID = judgeSectionTeamInOuts[i + 1].TeamID;
                                result.PreviousTeamID = judgeSectionTeamInOuts[i - 1].TeamID;
                            }
                            break;
                        }
                    }
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [Authorize]
        [HttpGet]
        [Route("checkSubsectionJudge/{eventID}")]
        public IHttpActionResult CheckSubsectionJudge(int eventID)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                var e = db.Events.Select(s => new EventViewModel
                {
                    ID = s.ID,
                    Sections = s.EventSections.Count(),
                    Subsections = s.JudgeSubsectionAssignments.Where(j => j.JudgeUserID == currentUserID).Count()
                }).FirstOrDefault(s => s.ID == eventID);
                return Ok(e);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }


        private bool checkCurrentUserLeadJudge(int eventID, int categoryID, NPSIEntities db)
        {
            var currentUserID = HttpContext.Current.User.Identity.GetUserId();
            var userEventRole = db.UserEventRoles.FirstOrDefault(u => u.EventID == eventID && u.CategoryID == categoryID && u.UserID == currentUserID);
            if (userEventRole == null) 
            { 
              return false;
            }
            else
            {
              return (userEventRole.AspNetRole.Name.ToLower() == "lead judge");
            }
        }

        private AddRemoveJudgeSubsectionAssignment checkDiffJudgeSubsectionAssignment(List<JugdeSubsectionAssignmentViewModel> subsectionModel, List<JugdeSubsectionAssignmentViewModel> subsectionList)
        {
            var objectTemp = new AddRemoveJudgeSubsectionAssignment();
            var listAdd = new List<JugdeSubsectionAssignmentViewModel>();
            var listRemove = new List<JugdeSubsectionAssignmentViewModel>();
            listRemove = subsectionList.Where(a => !subsectionModel.Any(a1 => a.SubsectionID == a1.SubsectionID)).ToList();
            listAdd = subsectionModel.Where(a => !subsectionList.Any(a1 => a.SubsectionID == a1.SubsectionID)).ToList();
            objectTemp.ListAdd = listAdd;
            objectTemp.ListRemove = listRemove;
            return objectTemp;
        }

        private AddRemoveJudgeSectionAssignment checkDiffJudgeAssignment(List<JudgeSectionAssignmentViewModel> judgeModel, List<JudgeSectionAssignmentViewModel> judgeUserList)
        {
            var objectTemp = new AddRemoveJudgeSectionAssignment();
            var listAdd = new List<JudgeSectionAssignmentViewModel>();
            var listRemove = new List<JudgeSectionAssignmentViewModel>();
            listRemove = judgeUserList.Where(a => !judgeModel.Any(a1 => a.JudgeUserID == a1.JudgeUserID)).ToList();
            listAdd = judgeModel.Where(a => !judgeUserList.Any(a1 => a.JudgeUserID == a1.JudgeUserID)).ToList();
            objectTemp.ListAdd = listAdd;
            objectTemp.ListRemove = listRemove;
            return objectTemp;
        }

        public bool CheckSubmitedDate(int eventID, int sectionID, int teamID)
        {
            var currentUserID = HttpContext.Current.User.Identity.GetUserId();
            var judgeSectionAssignments = db.JudgeSectionAssignments.Select(p => new JudgeSectionAssignmentViewModel
            {
                JudgeUserID = p.JudgeUserID,
                EventID = p.EventID,
                SectionID = p.SectionID,
                SubmittedDateTime = p.SubmittedDateTime
            }).FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.JudgeUserID == currentUserID);
            return judgeSectionAssignments != null && judgeSectionAssignments.SubmittedDateTime != null;
        }

        public bool CheckCompledtedEvent(int eventID)
        {
            var eventStatusLog = db.EventStatusLogs.Where(s => s.EventID == eventID).OrderByDescending(p => p.LoggedDateTime).FirstOrDefault();
            return eventStatusLog.EventStatu.StatusName == Utils.Constants.EventStatuses.COMPLETED ? true : false;
        }

        public bool CheckStartedEvent(int eventID)
        {
            var eventStatusLog = db.EventStatusLogs.Where(s => s.EventID == eventID).OrderByDescending(p => p.LoggedDateTime).FirstOrDefault();
            return eventStatusLog.EventStatu.StatusName == Utils.Constants.EventStatuses.STARTED ? true : false;
        }
    }
}

class SearchEvent
{
    public int? Count { get; set; }
    public List<EventViewModel> Data { get; set; }

}

class AddRemoveJudgeSubsectionAssignment
{
    public List<JugdeSubsectionAssignmentViewModel> ListAdd { get; set; }
    public List<JugdeSubsectionAssignmentViewModel> ListRemove { get; set; }
}

class AddRemoveJudgeSectionAssignment
{
    public List<JudgeSectionAssignmentViewModel> ListAdd { get; set; }
    public List<JudgeSectionAssignmentViewModel> ListRemove { get; set; }
}

class NextPreviousTeam
{
    public int? NextTeamID { get; set; }
    public int? PreviousTeamID { get; set; }
}