﻿using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/subsection")]
    public class SubsectionController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [SuperAdminAuthorizeAttribute]
        [HttpPost]
        [Route("createSubsection")]
        public IHttpActionResult CreateSubsection([FromBody] SubsectionViewModel model)
        {
            try
            {
                Subsection subSection = new Subsection();
                subSection.Description = model.Description;
                subSection.MaxScore = model.MaxScore;
                subSection.MinScore = model.MinScore;
                subSection.Name = model.Name;
                subSection.Active = true;
                subSection.SectionID = model.SectionID;
                db.Subsections.Add(subSection);
                db.SaveChanges();

                foreach (var item in model.Criteria)
                {
                    Criterion c = new Criterion();
                    c.Description = item.Description;
                    c.MaxScore = item.MaxScore;
                    c.MinScore = item.MinScore;
                    c.SubsectionId = subSection.ID;
                    db.Criteria.Add(c);
                }

                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpPut]
        [Route("editSubsection")]
        public IHttpActionResult EditSubsection([FromBody] SubsectionViewModel model)
        {
            try
            {
                var subSection = db.Subsections.FirstOrDefault(s => s.ID == model.ID);
                subSection.Description = model.Description;
                subSection.MaxScore = model.MaxScore;
                subSection.MinScore = model.MinScore;
                subSection.SectionID = model.SectionID;
                subSection.Name = model.Name;
                subSection.Active = model.Active;
                db.Entry(subSection).State = EntityState.Modified;

                if (subSection.Criteria.Count > 0)
                {
                    foreach (var item in subSection.Criteria.ToList())
                    {
                        var itemToRemove = db.Criteria.FirstOrDefault(x => x.ID == item.ID);
                        if (itemToRemove != null)
                        {
                            db.Criteria.Remove(itemToRemove);
                        }
                    }
                }

                foreach (var item in model.Criteria)
                {
                    Criterion c = new Criterion();
                    c.Description = item.Description;
                    c.MaxScore = item.MaxScore;
                    c.MinScore = item.MinScore;
                    c.SubsectionId = subSection.ID;
                    db.Criteria.Add(c);
                }

                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getSubsection")]
        public IHttpActionResult GetSubsection()
        {
            try
            {
                var subs = db.Subsections.Select(s => new SubsectionViewModel
                {
                    ID = s.ID,
                    Description = s.Description,
                    MaxScore = s.MaxScore,
                    MinScore = s.MinScore,
                    SectionID = s.SectionID,                    
                    Name = s.Name,
                    Active = s.Active,
                });
                return Ok(subs.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getSubsectionDetail/{id}")]
        public IHttpActionResult GetSubsectionDetail(int id)
        {
            try
            {
                var sub = db.Subsections.Select(s => new SubsectionViewModel
                {
                    ID = s.ID,
                    Description = s.Description,
                    MaxScore = s.MaxScore,
                    MinScore = s.MinScore,
                    SectionID = s.SectionID,                    
                    Name = s.Name,
                    Active = s.Active,
                    Criteria = db.Criteria.Where(v => v.SubsectionId == s.ID).Select(p => new CriteriaViewModel
                    {
                        Title = p.Title,
                        Description = p.Description,
                        MaxScore = p.MaxScore,
                        MinScore = p.MinScore
                    }).ToList(),
                }).FirstOrDefault(s => s.ID == id);
                return Ok(sub);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }


        //[SuperAdminAuthorize]
        //[HttpGet]
        //[Route("getSubsectionByCategory/{id}")]
        //public IHttpActionResult GetSubsectionByCategory(int id)
        //{
        //    try
        //    {
        //        var subs = db.Subsections.Where(p => p.Active == true && p.CategoryID == id).Select(s => new SubsectionViewModel
        //        {
        //            ID = s.ID,
        //            Name =s.Name,
        //            Active = s.Active
        //        });
        //        return Ok(subs.ToList());
        //    }
        //    catch (Exception ex)
        //    {
        //        LogUtilities.LogError(ex);
        //        throw;
        //    }
        //}
    }
}
