﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.Utils;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/account")]
    public class AccountsController : ApiController
    {
        public string UserId;
        NPSIEntities db = new NPSIEntities();

        [Authorize]
        [HttpGet]
        [Route("getUserInfo")]
        public IHttpActionResult GetUserDetail()
        {
            try
            {
                var currentUserId = HttpContext.Current.User.Identity.GetUserId();
                var user = db.AspNetUsers.Select(p => new AspNetUserViewModel
                {
                    Id = p.Id,
                    Username = p.UserName,
                    Email = p.Email,
                    PhoneNumber = p.PhoneNumber,
                    FirstName = p.FirstName,
                    LastName = p.LastName,
                    IsSuperAdmin = p.IsSuperAdmin,
                    Active = p.Active,
                    Roles = db.UserEventRoles.Where(v => v.UserID == p.Id).Select(x => x.AspNetRole.Name).ToList(),
                    Photo = p.Photo,
                    Organization = p.Organization
                }).FirstOrDefault(s => s.Id == currentUserId);
                return Ok(user);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("createUser")]
        public async Task<IHttpActionResult> CreateUserAsync([FromBody] CreateUserViewModel userModel)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                var checkUserExists = db.AspNetUsers.FirstOrDefault(s => s.UserName.ToLower() == userModel.Username.ToLower() || s.Email.ToLower() == userModel.Email.ToLower());
                if (checkUserExists != null)
                {
                    return Content(HttpStatusCode.BadRequest, "Username or Email Existed.");
                }
                UserManager<IdentityUserViewModel> userManager = HttpContext.Current.GetOwinContext().GetUserManager<UserManager<IdentityUserViewModel>>();
                IdentityUserViewModel user = new IdentityUserViewModel
                {
                    UserName = userModel.Username,
                    Email = userModel.Email,
                    PhoneNumber = userModel.PhoneNumber,
                    FirstName = userModel.FirstName,
                    LastName = userModel.LastName,
                    Photo = userModel.Photo,
                    Active = userModel.Active,
                    IsSuperAdmin = userModel.IsSuperAdmin,
                    Organization = userModel.Organization
                };
                UserId = user.Id;
                var result = await userManager.CreateAsync(user, userModel.Password);
                return Ok(user.Id);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPost]
        [Route("changePassword")]
        public async Task<IHttpActionResult> ChangePassword([FromBody] ChangePasswordViewModel changePasswordViewModel)
        {
            try
            {
                var currentUserId = HttpContext.Current.User.Identity.GetUserId();

                var aspNetUser = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserId);

                UserManager<IdentityUserViewModel> userManager = HttpContext.Current.GetOwinContext().GetUserManager<UserManager<IdentityUserViewModel>>();
                IdentityUserViewModel user = await userManager.FindAsync(aspNetUser.UserName, changePasswordViewModel.OldPassword);

                var checkPassword = userManager.CheckPassword(user, changePasswordViewModel.OldPassword);

                if (checkPassword == true)
                {
                    userManager.ChangePassword(currentUserId, changePasswordViewModel.OldPassword, changePasswordViewModel.NewPassword);
                    return Ok();
                }
                else
                {
                    return Content(HttpStatusCode.Forbidden, "Forbidden");
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPut]
        [Route("EditProfile")]
        public async Task<IHttpActionResult> EditProfileAsync([FromBody] CreateUserViewModel editProfileModel)
        {
            try
            {
                var currentUserId = HttpContext.Current.User.Identity.GetUserId();
                var aspNetUser = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserId);

                UserManager<IdentityUserViewModel> userManager = HttpContext.Current.GetOwinContext().GetUserManager<UserManager<IdentityUserViewModel>>();
                IdentityUserViewModel user = await userManager.FindAsync(aspNetUser.UserName, editProfileModel.Password);

                var checkPassword = userManager.CheckPassword(user, editProfileModel.Password);
                if (checkPassword == true)
                {
                    aspNetUser.Email = editProfileModel.Email;
                    aspNetUser.FirstName = editProfileModel.FirstName;
                    aspNetUser.PhoneNumber = editProfileModel.PhoneNumber;
                    aspNetUser.Email = editProfileModel.Email;
                    aspNetUser.Photo = editProfileModel.Photo;
                    aspNetUser.Active = editProfileModel.Active;
                    aspNetUser.Organization = editProfileModel.Organization;
                    db.Entry(aspNetUser).State = EntityState.Modified;
                    db.SaveChanges();
                    return Ok();
                }
                else
                {
                    return Content(HttpStatusCode.Forbidden, "Forbidden");
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPut]
        [Route("editUser")]
        public IHttpActionResult EditUserAsync([FromBody] CreateUserViewModel editProfileModel)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                var checkUserExists = db.AspNetUsers.FirstOrDefault(s => s.UserName.ToLower() != editProfileModel.Username.ToLower() && s.Email.ToLower() == editProfileModel.Email.ToLower());
                if (checkUserExists != null)
                {
                    return Content(HttpStatusCode.BadRequest, "Email Existed.");
                }
                var aspNetUser = db.AspNetUsers.FirstOrDefault(s => s.Id == editProfileModel.Id);

                aspNetUser.Email = editProfileModel.Email;
                aspNetUser.FirstName = editProfileModel.FirstName;
                aspNetUser.LastName = editProfileModel.LastName;
                aspNetUser.PhoneNumber = editProfileModel.PhoneNumber;
                aspNetUser.Email = editProfileModel.Email;
                aspNetUser.Photo = editProfileModel.Photo;
                aspNetUser.Active = editProfileModel.Active;
                aspNetUser.IsSuperAdmin = editProfileModel.IsSuperAdmin;
                aspNetUser.Organization = editProfileModel.Organization;
                db.Entry(aspNetUser).State = EntityState.Modified;
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }
    }
}
