﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.Utils;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
  [EnableCors(origins: "*", headers: "*", methods: "*")]
  [RoutePrefix("api/user")]
  public class UsersController : ApiController
  {
    NPSIEntities db = new NPSIEntities();

    [Authorize]
    [Route("searchUser")]
    public IHttpActionResult SearchUser([FromBody] SearchUserViewModel model)
    {
      try
      {
        Nullable<int> count = null;
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
        {
          return Unauthorized();
        }
        SearchUser result = new SearchUser();
        var users = db.AspNetUsers.Select(s => new AspNetUserViewModel
        {
          Id = s.Id,
          FirstName = s.FirstName,
          LastName = s.LastName,
          Email = s.Email,
          IsSuperAdmin = s.IsSuperAdmin,
          Photo = s.Photo,
          Active = s.Active,
          Username = s.UserName,
          PhoneNumber = s.PhoneNumber,
          Lock = s.LockoutEnabled,
          Roles = db.UserEventRoles.Where(er => er.UserID == s.Id).Select(r => r.AspNetRole.Name).Distinct().ToList(),
          IsJudge = false,
          Organization = s.Organization
        });

        if (model.UserId != null) users = users.Where(s => s.Id == model.UserId);
        if (model.Username != null) users = users.Where(s => s.Username.Contains(model.Username));
        if (model.Email != null) users = users.Where(s => s.Email.Contains(model.Email));
        if (model.FirstName != null) users = users.Where(s => s.FirstName.Contains(model.FirstName));
        if (model.LastName != null) users = users.Where(s => s.LastName.Contains(model.LastName));
        if (!string.IsNullOrEmpty(model.PhoneNumber)) users = users.Where(s => s.PhoneNumber.Contains(model.PhoneNumber));
        if (model.Organization != null) users = users.Where(s => s.Organization.Contains(model.Organization));
        if (model.Active != null) users = users.Where(s => s.Active == model.Active);
        if (model.IsSuperAdmin != null) users = users.Where(s => s.IsSuperAdmin == model.IsSuperAdmin);
        if (model.ReturnTotalCount == false) count = null; else count = users.Count();
        if (model.SortedBy == null) model.SortedBy = "Username asc";
        if (model.PageNumber == null) model.PageNumber = 1;
        if (model.ItemsPerPage == null) model.ItemsPerPage = 10;
        users = users.OrderBy(model.SortedBy);
        if (model.ItemsPerPage.HasValue) users = users.Skip(model.ItemsPerPage.Value * (model.PageNumber.Value - 1)).Take(model.ItemsPerPage.Value);
        result.Data = users.Select(u => new AspNetUserViewModel
        {
          Id = u.Id,
          FirstName = u.FirstName,
          LastName = u.LastName,
          Email = u.Email,
          IsSuperAdmin = u.IsSuperAdmin,
          Photo = u.Photo,
          Active = u.Active,
          Username = u.Username,
          PhoneNumber = u.PhoneNumber,
          Lock = u.Lock,
          Roles = u.Roles,
          IsJudge = u.Roles.Contains(Utils.Constants.Roles.JUDGE) || u.Roles.Contains(Utils.Constants.Roles.LEADJUDGE),
          Organization = u.Organization
        }).ToList();
        result.Count = count;

        return Ok(result);
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

    [Authorize]
    [HttpGet]
    [Route("getRolesJudgesLeadJudge")]
    public IHttpActionResult GetRolesJudgeLeadJudge()
    {
      try
      {
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
        {
          return Unauthorized();
        }
        var roles = db.AspNetRoles.Where(s => s.Name == Utils.Constants.Roles.JUDGE || s.Name == Utils.Constants.Roles.LEADJUDGE || s.Name == Utils.Constants.Roles.EVENTADMIN).Select(p => new AspNetRolesViewModel
        {
          ID = p.Id,
          Name = p.Name,
        }).ToList();
        return Ok(roles);
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

    [Authorize]
    [HttpGet]
    [Route("getAllUser")]
    public IHttpActionResult GetAllUser()
    {
      try
      {

        var users = db.AspNetUsers
            .Where(asp => asp.IsSuperAdmin == false)
            .Select(p => new AspNetUserViewModel
            {
              Id = p.Id,
              FirstName = p.FirstName,
              LastName = p.LastName,
              Username = p.UserName,
              Fullname = p.FirstName + " " + p.LastName,
              Organization = p.Organization
            }).ToList();
        return Ok(users);
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

    [Authorize]
    [HttpPost]
    [Route("unlockUser/{id}")]
    public IHttpActionResult UnlockUser(string id)
    {
      try
      {
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
        {
          return Unauthorized();
        }
        var user = db.AspNetUsers.FirstOrDefault(s => s.Id == id);
        user.LockoutEnabled = false;
        user.AccessFailedCount = 0;
        db.Entry(user).State = System.Data.Entity.EntityState.Modified;
        db.SaveChanges();
        return Ok();
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }
    [Authorize]
    [HttpPost]
    [Route("resetPassword")]
    public async Task<IHttpActionResult> ResetPassword([FromBody] ResetPasswordViewModel model)
    {
      try
      {
        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
        {
          return Unauthorized();
        }
        UserManager<IdentityUserViewModel> userManager = HttpContext.Current.GetOwinContext().GetUserManager<UserManager<IdentityUserViewModel>>();
        await userManager.RemovePasswordAsync(model.UserID);
        await userManager.AddPasswordAsync(model.UserID, model.Password);
        var user = db.AspNetUsers.FirstOrDefault(s => s.Id == model.UserID);
        using (var client = new SmtpClient())
        {
          System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
          string debugEmailAddresses = System.Configuration.ConfigurationManager.AppSettings["DebugEmailAddresses"];
          List<string> listTo = new List<string>();
          if (!string.IsNullOrEmpty(debugEmailAddresses))
            listTo = debugEmailAddresses.Split(',').ToList();
          else
            listTo.Add(user.Email);
          foreach (string item in listTo) mail.To.Add(item.Trim());
          mail.From = new MailAddress(System.Configuration.ConfigurationManager.AppSettings["FromEmailAddress"]);
          mail.Subject = "Your NPSI user's password has been reset";
          if (!string.IsNullOrEmpty(debugEmailAddresses)) mail.Body = "<p>To: " + user.Email + "</p>";
          mail.Body = mail.Body + "<p>Your new password is " + "<b>" + model.Password + "</b>" + "</p>";
          mail.IsBodyHtml = true;
          client.Send(mail);
        }
        return Ok();
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

    [Authorize]
    [HttpGet]
    [Route("getUserDetail/{userId}")]
    public IHttpActionResult GetUserDetail(string userId)
    {
      try
      {
        var users = db.AspNetUsers
          .Where(a => a.Id == userId)
          .Select(s => new AspNetUserViewModel
          {
            Id = s.Id,
            FirstName = s.FirstName,
            LastName = s.LastName,
            Email = s.Email,
            IsSuperAdmin = s.IsSuperAdmin,
            Photo = s.Photo,
            Active = s.Active,
            Username = s.UserName,
            PhoneNumber = s.PhoneNumber,
            Lock = s.LockoutEnabled,
            Roles = db.UserEventRoles.Where(er => er.UserID == s.Id).Select(r => r.AspNetRole.Name).Distinct().ToList(),
            IsJudge = false,
            Organization = s.Organization
          });

        return Ok(users.ToList());
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

    [Authorize]
    [HttpPost]
    [Route("judgeHistory/{judgeUserId}")]
    public IHttpActionResult GetJudgeHistory(string judgeUserId)
    {
      try
      {
        var query = from uer in db.UserEventRoles.Where(j => j.UserID == judgeUserId)
                    join e in db.Events on uer.EventID equals e.ID
                    join c in db.Categories on uer.CategoryID equals c.ID
                    join r in db.AspNetRoles on uer.RoleID equals r.Id
                    join jsa in db.JudgeSectionAssignments
                      on new { UserID = uer.UserID, EventID = uer.EventID } equals new { UserID = jsa.JudgeUserID, EventID = jsa.EventID } into joined_uerjsa
                    from uerjsa in joined_uerjsa.DefaultIfEmpty()
                    select new
                    {
                      JudgeUserID = uer.UserID,
                      uer.EventID,
                      EventName = e.Name,
                      e.StartDateTime,
                      SectionID = (int?)uerjsa.SectionID,
                      SectionName = uerjsa.EventSection.Section.Name,
                      CategoryName = c.Name,
                      RoleName = r.Name
                    };

        return Ok(query.ToList());
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }

    [Authorize]
    [HttpPost]
    [Route("judgeScoring")]
    public IHttpActionResult GetJudgeScoring([FromBody] SearchScoreViewModel model)
    {
      try
      {
        var scores = db.Scores
          .Where(sc =>
            sc.JudgeUserID == model.JudgeUserID
            && (sc.EventID == (model.EventID ?? 0) || model.EventID == null)
            && (sc.Subsection.SectionID == (model.SectionID ?? 0) || model.SectionID == null)
            && (sc.SubsectionID == (model.SubsectionID ?? 0) || model.SubsectionID == null)
          );
        var r = scores.ToList();
        var query = from sc in scores
                    join e in db.Events on sc.EventID equals e.ID
                    join t in db.Teams on sc.TeamID equals t.ID
                    join s in db.Sections on sc.Subsection.SectionID equals s.ID into joined_scs
                    from scs in joined_scs.DefaultIfEmpty()
                    join ss in db.Subsections on sc.SubsectionID equals ss.ID into joined_scsss
                    from scsss in joined_scsss.DefaultIfEmpty()
                    select new
                    {
                      sc.ID,
                      sc.EventID,
                      EventName = e.Name,
                      SectionID = scs.ID,
                      SectionName = scs.Name,
                      sc.SubsectionID,
                      SubsectionName = scsss.Name,
                      sc.TeamID,
                      TeamName = t.Name,
                      sc.Score1,
                      sc.CreatedDateTime,
                      sc.Comments
                    };

        return Ok(query.ToList());
      }
      catch (Exception ex)
      {
        LogUtilities.LogError(ex);
        throw;
      }
    }
  }

  class SearchUser
  {
    public int? Count { get; set; }
    public List<AspNetUserViewModel> Data { get; set; }

  }
}
