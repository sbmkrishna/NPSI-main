﻿using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/penalty")]
    public class PenaltyController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [SuperAdminAuthorizeAttribute]
        [HttpPost]
        [Route("createPenalty")]
        public IHttpActionResult CreatePenalty([FromBody] PenaltyViewModel model)
        {
            try
            {
                Penalty penalty = new Penalty();
                penalty.DeductionMin = model.DeductionMin;
                penalty.DeductionMax = model.DeductionMax;
                penalty.Name = model.Name;
                penalty.Active = true;
                db.Penalties.Add(penalty);
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpPut]
        [Route("editPenalty")]
        public IHttpActionResult EditPenalty([FromBody] PenaltyViewModel model)
        {
            try
            {
                var penalty = db.Penalties.FirstOrDefault(s => s.ID == model.ID);
                penalty.DeductionMin = model.DeductionMin;
                penalty.DeductionMax = model.DeductionMax;
                penalty.Name = model.Name;
                penalty.Active = model.Active;
                db.Entry(penalty).State = EntityState.Modified;
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getPenalty")]
        public IHttpActionResult GetPenalty()
        {
            try
            {
                var penalties = db.Penalties.Select(s => new PenaltyViewModel
                {
                    ID = s.ID,
                    DeductionRange = s.DeductionMin + (s.DeductionMax != null ? " - " + s.DeductionMax : ""),
                    DeductionMin = s.DeductionMin,
                    DeductionMax = s.DeductionMax.Value,
                    Name = s.Name,
                    Active = s.Active,
                });
                return Ok(penalties.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getPenaltyActive")]
        public IHttpActionResult GetPenaltyActive()
        {
            try
            {
                var penalties = db.Penalties.Where(p => p.Active == true).Select(s => new PenaltyViewModel
                {
                    ID = s.ID,
                    DeductionRange = s.DeductionMin + (s.DeductionMax != null ? " - " + s.DeductionMax : ""),
                    DeductionMax = s.DeductionMax,
                    DeductionMin = s.DeductionMin,
                    Name = s.Name,
                });
                return Ok(penalties.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deletePenalty/{penaltyID}")]
        public IHttpActionResult deletePenalty([FromUri] int penaltyID)
        {
            try
            {
                using (var db = new NPSIEntities())
                {
                    var penalty = db.Penalties.FirstOrDefault(p => p.ID == penaltyID);
                    if(penalty == null)
                    {
                        return BadRequest();
                    }
                    var teamSectionPenalty = db.TeamSectionPenalties.Where(tsp => tsp.PenaltyID == penaltyID).ToList();
                    if(teamSectionPenalty.Count > 0)
                    {
                        return Content(HttpStatusCode.BadRequest, "Penalty cannot be deleted since it was referenced/used in a prior competition. You should make it inactive.");
                    }
                    var sectionPenalties = penalty.Sections.ToList();
                    if(sectionPenalties != null)
                    {
                        foreach (var item in sectionPenalties)
                        {
                            penalty.Sections.Remove(item);
                        }
                    }
                    db.Penalties.Remove(penalty);
                    db.SaveChanges();
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }
    }
}
