﻿using Microsoft.AspNet.Identity;
using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.Utils;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/team")]
    public class TeamController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [Authorize]
        [HttpPost]
        [Route("createTeam")]
        public IHttpActionResult CreateTeam([FromBody] TeamViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                Team team = new Team();
                team.SchoolName = model.SchoolName;
                team.Name = model.Name;
                team.Email = model.Email;
                team.Phone = model.Phone;
                team.PrimaryContactName = model.PrimaryContactName;
                team.CategoryID = model.CategoryID;
                team.Active = true;
                db.Teams.Add(team);
                db.SaveChanges();

                foreach (var item in model.Members)
                {
                    Member member = new Member();
                    member.Name = item.Name;
                    member.Email = item.Email;
                    member.Phone = item.Phone;
                    member.TeamID = team.ID;
                    db.Members.Add(member);
                }
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }


        [Authorize]
        [HttpPost]
        [Route("searchTeam")]
        public IHttpActionResult SearchTeam([FromBody] SearchTeamViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                SearchTeam result = new SearchTeam();
                var teams = db.Teams.Select(s => new TeamViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                    Phone = s.Phone,
                    Email = s.Email,
                    PrimaryContactName = s.PrimaryContactName,
                    SchoolName = s.SchoolName,
                    CategoryID = s.CategoryID,
                    CategoryName = s.Category.Name,
                    Active = s.Active,
                    Members = s.Members.Select(v => new MemberViewModel
                    {
                        ID = v.ID,
                        Name = v.Name,
                        Phone = v.Phone,
                        Email = v.Email
                    }).ToList(),
                });
                if (model.SchoolName != null)
                {
                    teams = teams.Where(s => s.SchoolName.Contains(model.SchoolName));
                }
                if (model.TeamName != null)
                {
                    teams = teams.Where(s => s.Name.Contains(model.TeamName));
                }
                if (model.PhoneNumber != null)
                {
                    teams = teams.Where(s => s.Phone.Contains(model.PhoneNumber));
                }
                if (model.CategoryID != null)
                {
                    teams = teams.Where(s => s.CategoryID == model.CategoryID);
                }
                if (model.Email != null)
                {
                    teams = teams.Where(s => s.Email.Contains(model.Email));
                }
                if (model.Active != null)
                {
                    teams = teams.Where(s => s.Active == model.Active);
                }
                Nullable<int> count = null;
                if (model.ReturnTotalCount == false)
                {
                    count = null;
                }
                else
                {
                    count = teams.Count();
                }
                //sorting
                if (model.SortedBy == null)
                {
                    //default sort order: Show Incomplete first, show tasks having end date above tasks no end date, show nearer end date first
                    model.SortedBy = "SchoolName asc";
                }
                teams = teams.OrderBy(model.SortedBy);
                //pagination
                if (model.PageNumber == null)
                {
                    model.PageNumber = 1;
                }
                if (model.ItemsPerPage == null)
                {
                    model.ItemsPerPage = 10;
                }
                if (model.ItemsPerPage.HasValue)
                {
                    teams = teams.Skip(model.ItemsPerPage.Value * (model.PageNumber.Value - 1)).Take(model.ItemsPerPage.Value);
                }
                result.Data = teams.ToList();
                result.Count = count;
                return Ok(result);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpPut]
        [Route("editTeam")]
        public IHttpActionResult EditTeam([FromBody] TeamViewModel model)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                var team = db.Teams.FirstOrDefault(s => s.ID == model.ID);
                if (team == null)
                {
                    return NotFound();
                }
                else
                {
                    if (team.Members.Count > 0)
                    {
                        foreach (var item in team.Members.ToList())

                        {
                            var itemToRemove = db.Members.FirstOrDefault(x => x.ID == item.ID);
                            if (itemToRemove != null)
                            {
                                db.Members.Remove(itemToRemove);
                            }
                            db.SaveChanges();
                        }
                    }
                    team.SchoolName = model.SchoolName;
                    team.Name = model.Name;
                    team.Email = model.Email;
                    team.Phone = model.Phone;
                    team.PrimaryContactName = model.PrimaryContactName;
                    team.CategoryID = model.CategoryID;
                    team.Active = model.Active;

                    db.SaveChanges();
                    if (model.Members != null)
                    {
                        for (var i = 0; i < model.Members.Count; i++)
                        {
                            db.Members.Add(new Member
                            {
                                Name = model.Members[i].Name,
                                Phone = model.Members[i].Phone,
                                Email = model.Members[i].Email,
                                TeamID = team.ID,
                            });
                            db.SaveChanges();
                        }
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getTeamsByCategory/{id}")]
        public IHttpActionResult GetTeamsByCategory(int id)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                var teams = db.Teams.Where(v => v.CategoryID == id).Select(s => new TeamViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                    SchoolName = s.SchoolName,
                    CategoryID = s.CategoryID,
                    Active = s.Active,
                    CategoryName = s.Category.Name,
                    Members = s.Members.Select(v => new MemberViewModel
                    {
                        ID = v.ID,
                        Name = v.Name,
                        Phone = v.Phone,
                        Email = v.Email
                    }).ToList(),
                });
                return Ok(teams);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getTeamDetail/{id}")]
        public IHttpActionResult GetTeamDetail(int id)
        {
            try
            {
                var team = db.Teams.Select(p => new TeamViewModel
                {
                    ID = p.ID,
                    Name = p.Name,
                    CategoryID = p.CategoryID,
                    CategoryName = p.Category.Name,
                    SchoolName = p.SchoolName,
                }).FirstOrDefault(s => s.ID == id);
                return Ok(team);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        //[Authorize]
        //[HttpPost]
        //[Route("addJudgeSectionTeamAssignment/{eventID}/{sectionID}/{teamID}")]
        //public IHttpActionResult AddJudgeSectionTeamAssignment(int eventID, int sectionID, int teamID)
        //{
        //    try
        //    {
        //        if (CheckStartedEvent(eventID) == false)
        //        {
        //            return BadRequest();
        //        }
        //        var currentUserID = HttpContext.Current.User.Identity.GetUserId();
        //        var judgeSectionTeam = db.JudgeSectionTeamAssignments.FirstOrDefault(s => s.JudgeUserID == currentUserID && s.EventID == eventID && s.SectionID == sectionID && s.TeamID == teamID);
        //        var leadJudge = db.AspNetRoles.FirstOrDefault(s => s.Name == Utils.Constants.Roles.LEADJUDGE);
        //        var section = db.Sections.FirstOrDefault(s => s.ID == sectionID);
        //        var userEventRole = db.UserEventRoles.FirstOrDefault(s => s.EventID == eventID && s.RoleID == leadJudge.Id && s.UserID == currentUserID && s.CategoryID == section.CategoryID);
        //        var judgeSectionAssignment = db.JudgeSectionAssignments.FirstOrDefault(s => s.EventID == eventID && s.SectionID == sectionID && s.JudgeUserID == currentUserID);
        //        if (judgeSectionTeam == null)
        //        {
        //            if (judgeSectionAssignment == null && userEventRole != null)
        //            {
        //                JudgeSectionAssignment j = new JudgeSectionAssignment();
        //                j.JudgeUserID = currentUserID;
        //                j.SectionID = sectionID;
        //                j.EventID = eventID;
        //                db.JudgeSectionAssignments.Add(j);
        //                db.SaveChanges();
        //            }
        //            JudgeSectionTeamAssignment judgeSectionTeamAssignment = new JudgeSectionTeamAssignment();
        //            judgeSectionTeamAssignment.JudgeUserID = currentUserID;
        //            judgeSectionTeamAssignment.EventID = eventID;
        //            judgeSectionTeamAssignment.SectionID = sectionID;
        //            judgeSectionTeamAssignment.TeamID = teamID;
        //            db.JudgeSectionTeamAssignments.Add(judgeSectionTeamAssignment);
        //            db.SaveChanges();
        //        }
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        LogUtilities.LogError(ex);
        //        throw;
        //    }
        //}

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deleteTeam/{teamID}")]
        public IHttpActionResult DeleteTeam([FromUri] int teamID)
        {
            try
            {
                using (var db = new NPSIEntities())
                {
                    var team = db.Teams.FirstOrDefault(p => p.ID == teamID);
                    if (team == null)
                    {
                        return BadRequest();
                    }
                    var member = db.Members.Where(m => m.TeamID == teamID).ToList();
                    if (team.EventTeams.Any())
                    {
                        return Content(HttpStatusCode.BadRequest, "Team cannot be deleted since it was referenced/used in a prior competition. You should make it inactive.");
                    }
                    db.Members.RemoveRange(member);
                    db.Teams.Remove(team);
                    db.SaveChanges();
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        [SuperAdminAuthorize]
        [HttpPost]
        [Route("activateDeactiveAllTeams")]
        public IHttpActionResult ActivateDeactiveAllTeams([FromBody] ActiveDeactiveModel model)
        {
            try
            {
                foreach(var item in model.Ids)
                {
                    var team = db.Teams.FirstOrDefault(t => t.ID == item);
                    team.Active = model.Type;  
                    db.SaveChanges();
                }
          
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }



        [SuperAdminAuthorize]
        [HttpGet]
        [Route("getAllTeamByActive")]
        public IHttpActionResult GetAllTeamByActive([FromUri] bool active)
        {
            try
            {
                var teams = db.Teams.Where(t => t.Active != active).Select(t => t.ID).ToList();
                return Ok(teams);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        public bool CheckStartedEvent(int eventID)
        {
            var eventStatusLog = db.EventStatusLogs.Where(s => s.EventID == eventID).OrderByDescending(p => p.LoggedDateTime).FirstOrDefault();
            return eventStatusLog.EventStatu.StatusName == Utils.Constants.EventStatuses.STARTED ? true : false;
        }
    }
}
class SearchTeam
{
    public int? Count { get; set; }
    public List<TeamViewModel> Data { get; set; }
}

public class ActiveDeactiveModel
{
    public bool Type { get; set; }
    public List<int> Ids { get; set; }
}