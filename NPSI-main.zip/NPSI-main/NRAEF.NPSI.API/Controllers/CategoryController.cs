﻿using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/category")]
    public class CategoryController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [Authorize]
        [HttpGet]
        [Route("getCategory")]
        public IHttpActionResult GetCategory()
        {
            try
            {
                var categories = db.Categories.Select(s => new CategoryViewModel
                {
                    ID = s.ID,
                    Name = s.Name,
                });
                return Ok(categories.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("{eventId}")]
        public IHttpActionResult GetCategoryByEventID(int eventId)
        {
            try
            {
                var categories = db.Events.FirstOrDefault(f => f.ID == eventId).Categories
                    .Select(c => new CategoryViewModel
                {
                    ID = c.ID,
                    Name = c.Name
                });
                return Ok(categories.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }
    }
}
