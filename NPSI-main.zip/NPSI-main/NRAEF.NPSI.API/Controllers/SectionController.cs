﻿using Microsoft.AspNet.Identity;
using NRAEF.NPSI.API.Authorization_Filter;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.Utils;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NRAEF.NPSI.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/section")]
    public class SectionController : ApiController
    {
        NPSIEntities db = new NPSIEntities();

        [SuperAdminAuthorizeAttribute]
        [HttpPost]
        [Route("createSection")]
        public IHttpActionResult CreateSection([FromBody] SectionViewModel model)
        {
            try
            {
                Section section = new Section();
                section.CategoryID = model.CategoryID;
                section.Description = model.Description;
                section.Name = model.Name;
                section.Active = true;
                section.SortOrder = model.SortOrder;
                section.TimeInOutNeeded = model.TimeInOutNeeded;
                db.Sections.Add(section);
                db.SaveChanges();
                return Ok(section.ID);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpPut]
        [Route("editSection")]
        public IHttpActionResult EditSection([FromBody] SectionViewModel model)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(s => s.ID == model.ID);
                if (section == null)
                {
                    return Content(HttpStatusCode.NotFound, "Section is not found");
                }
                section.CategoryID = model.CategoryID;
                section.Description = model.Description;
                section.Name = model.Name;
                section.Active = model.Active;
                section.SortOrder = model.SortOrder;
                section.TimeInOutNeeded = model.TimeInOutNeeded;
                db.Entry(section).State = EntityState.Modified;
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return InternalServerError();
            }
        }

        //[SuperAdminAuthorizeAttribute]
        //[HttpPost]
        //[Route("addSubsection")]
        //public IHttpActionResult AddSubsection([FromBody] SectionSubsectionViewModel model)
        //{
        //    try
        //    {
        //        //var section = db.Sections.FirstOrDefault(p => p.ID == model.SectionID);
        //        //if (section != null)
        //        //{
        //        for (var i = 0; i < model.SubSorts.Count; i++)
        //        {
        //            SectionSubsection sectionSubsection = new SectionSubsection();
        //            sectionSubsection.SectionID = model.SectionID;
        //            sectionSubsection.SubsectionID = model.SubSorts[i].ID;
        //            sectionSubsection.SortIndex = model.SubSorts[i].SortIndex != 0 ? model.SubSorts[i].SortIndex : (int?)null;
        //            db.SectionSubsections.Add(sectionSubsection);
        //        }
        //        //foreach (var co in cos)
        //        //{
        //        //    section.Subsections.Add(co);
        //        //}
        //        db.SaveChanges();
        //        //}
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {
        //        LogUtilities.LogError(ex);
        //        throw;
        //    }
        //}

        [SuperAdminAuthorizeAttribute]
        [HttpPost]
        [Route("addPenalty")]
        public IHttpActionResult AddPenalty([FromBody] SectionPenaltyViewModel model)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == model.SectionID);
                if (section != null)
                {
                    List<Penalty> cos = new List<Penalty>();
                    for (var i = 0; i < model.Ids.Count; i++)
                    {
                        var penaltyId = model.Ids[i];
                        var penalty = db.Penalties.FirstOrDefault(p => p.ID == penaltyId);
                        cos.Add(penalty);
                    }
                    foreach (var co in cos)
                    {
                        section.Penalties.Add(co);
                    }
                    db.SaveChanges();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }
        [SuperAdminAuthorizeAttribute]
        [HttpPost]
        [Route("addDisqualifications")]
        public IHttpActionResult AddDisqualifications([FromBody] SectionDisqualificationsViewModel model)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == model.SectionID);
                if (section != null)
                {
                    List<Disqualification> cos = new List<Disqualification>();
                    for (var i = 0; i < model.Ids.Count; i++)
                    {
                        var disqualificationId = model.Ids[i];
                        var disqualification = db.Disqualifications.FirstOrDefault(p => p.ID == disqualificationId);
                        cos.Add(disqualification);
                    }
                    foreach (var co in cos)
                    {
                        section.Disqualifications.Add(co);
                    }
                    db.SaveChanges();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deleteSection/{id}")]
        public IHttpActionResult DeleteSection(int id)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == id);

                if (section != null)
                {
                    var disqualifications = section.Disqualifications.ToList();
                    foreach (var disqualification in disqualifications)
                    {
                        section.Disqualifications.Remove(disqualification);
                    }
                    var penalties = section.Penalties.ToList();
                    foreach (var penalty in penalties)
                    {
                        section.Penalties.Remove(penalty);
                    }
                    var subs = db.Subsections.Where(s => s.SectionID == id);
                    foreach (var subsections in subs)
                    {
                        var cris = db.Criteria.Where(c => c.SubsectionId == subsections.ID);
                        foreach (var cri in cris)
                        {
                            db.Criteria.Remove(cri);
                        }
                        db.Subsections.Remove(subsections);
                    }
                    db.Sections.Remove(section);
                    db.SaveChanges();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deleteSubsection/{sectionId}/{subsectionId}")]
        public IHttpActionResult DeleteSubsection(int sectionId, int subsectionId)
        {
            try
            {
                var sub = db.Subsections.FirstOrDefault(p => p.ID == subsectionId);
                if (sub != null)
                {
                    if (sub.Scores.Any())
                    {
                        return BadRequest("Scores existed");
                    }

                    foreach (var assign in sub.JudgeSubsectionAssignments)
                    {
                        db.JudgeSubsectionAssignments.Remove(assign);
                    }

                    var tempCriteria = sub.Criteria.ToList();
                    foreach (var cri in tempCriteria)
                    {
                        db.Criteria.Remove(cri);
                    }
                    db.Subsections.Remove(sub);
                    db.SaveChanges();
                }
                else
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deletePenalty/{sectionId}/{penaltyId}")]
        public IHttpActionResult DeletePenalty(int sectionId, int penaltyId)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == sectionId);
                if (section != null)
                {
                    var penalty = section.Penalties.FirstOrDefault(s => s.ID == penaltyId);
                    section.Penalties.Remove(penalty);
                    db.SaveChanges();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpDelete]
        [Route("deleteDisqualifications/{sectionId}/{disqualificationId}")]
        public IHttpActionResult DeleteDisqualifications(int sectionId, int disqualificationId)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == sectionId);
                if (section != null)
                {
                    var disqualifications = section.Disqualifications.FirstOrDefault(s => s.ID == disqualificationId);
                    section.Disqualifications.Remove(disqualifications);
                    db.SaveChanges();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getSection")]
        public IHttpActionResult GetSection()
        {
            try
            {
                var sections = db.Sections.Select(p => new SectionViewModel
                {
                    ID = p.ID,
                    SortOrder = p.SortOrder,
                    Name = p.Name,
                    Description = p.Description,
                    Active = p.Active,
                    CategoryID = p.CategoryID,
                    CategoryName = p.Category.Name,
                    TimeInOutNeeded = p.TimeInOutNeeded,
                }).ToList();
                return Ok(sections);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("checkSectionBeforDeleting/{id}")]
        public IHttpActionResult CheckSectionBeforDeleting(int id)
        {
            try
            {
                var e = db.Events.FirstOrDefault(s => s.EventSections.FirstOrDefault(v => v.SectionID == id) != null && s.EventSections.FirstOrDefault(v => v.SectionID == id).SectionID == id);
                if (e != null)
                {
                    return Ok("false");
                }
                return Ok("true");
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }


        [Authorize]
        [HttpGet]
        [Route("getSectionDetail/{id}")]
        public IHttpActionResult GetSectionDetail(int id)
        {
            try
            {
                var section = db.Sections.Select(p => new SectionViewModel
                {
                    ID = p.ID,
                    Name = p.Name,
                    Description = p.Description,
                    Active = p.Active,
                    CategoryID = p.CategoryID,
                    CategoryName = p.Category.Name,
                    SortOrder = p.SortOrder,
                    TimeInOutNeeded = p.TimeInOutNeeded,
                }).FirstOrDefault(s => s.ID == id);
                return Ok(section);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getSectionDetail/{id}/subsection")]
        public IHttpActionResult GetSubsectionBySectionID(int id)
        {
            try
            {
                var subs = db.Subsections.Where(s => s.SectionID == id).Select(p => new SubsectionViewModel
                {
                    ID = p.ID,
                    Description = p.Description,
                    MinScore = p.MinScore,
                    MaxScore = p.MaxScore,
                    Name = p.Name,
                    SortIndex = p.SortIndex,
                    Active = p.Active,
                    SectionID = p.SectionID,
                    Criteria = p.Criteria.Select(c => new CriteriaViewModel
                    {
                        Title = c.Title,
                        Description = c.Description,
                        MaxScore = c.MaxScore,
                        MinScore = c.MinScore,
                        SubsectionId = c.SubsectionId
                    }).ToList()
                });
                return Ok(subs.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getSectionDetail/{id}/disqualifications")]
        public IHttpActionResult GetdisqualificationsBySectionID(int id)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == id);
                var dis = section.Disqualifications.Select(p => new DisqualificationViewModel
                {
                    ID = p.ID,
                    Name = p.Name,
                    Active = p.Active,
                });
                return Ok(dis.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }
        [SuperAdminAuthorizeAttribute]
        [HttpGet]
        [Route("getSectionDetail/{id}/penalties")]
        public IHttpActionResult GetPenaltiesBySectionID(int id)
        {
            try
            {
                var section = db.Sections.FirstOrDefault(p => p.ID == id);
                var pens = section.Penalties.Select(p => new PenaltyViewModel
                {
                    ID = p.ID,
                    DeductionRange = p.DeductionMin + (p.DeductionMax != null ? " - " + p.DeductionMax : ""),
                    Name = p.Name,
                    Active = p.Active,
                });
                return Ok(pens.ToList());
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [Authorize]
        [HttpGet]
        [Route("getSectionByCategory/{id}")]
        public IHttpActionResult GetSectionByCategory(int id)
        {
            try
            {
                var currentUserID = HttpContext.Current.User.Identity.GetUserId();
                if (EventAdmin.CheckRolesAdminOrEventAdmin(currentUserID) == false)
                {
                    return Unauthorized();
                }
                var sections = db.Sections.Where(s => s.CategoryID == id && s.Active == true).Select(p => new SectionViewModel
                {
                    ID = p.ID,
                    Name = p.Name,
                    Description = p.Description,
                    Active = p.Active,
                    CategoryID = p.CategoryID,
                    CategoryName = p.Category.Name,
                    SortOrder = p.SortOrder,
                    TimeInOutNeeded = p.TimeInOutNeeded
                }).ToList();
                return Ok(sections);
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }

        [SuperAdminAuthorize]
        [HttpPut]
        [Route("changeSortIndex")]
        public IHttpActionResult ChangeSortIndex([FromBody] AddEditSectionSubsectionViewModel model)
        {
            try
            {
                var secSub = db.Subsections.FirstOrDefault(s => s.ID == model.SubsectionID);
                if (secSub == null)
                {
                    return NotFound();
                }
                secSub.SortIndex = model.SortIndex != null ? model.SortIndex : (int?)null;
                db.Entry(secSub).State = EntityState.Modified;
                db.SaveChanges();
                return Ok();
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                throw;
            }
        }
    }
}
