﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using NRAEF.NPSI.API.ViewModel;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace NRAEF.NPSI.API.Authorization_Filter
{
    public class SuperAdminAuthorizeAttribute : AuthorizeAttribute
    {
        protected override bool IsAuthorized(HttpActionContext actionContext)
        {
            try
            {
                bool isAuthorized = base.IsAuthorized(actionContext);
                if (!isAuthorized)
                {
                    return false;
                }

                UserManager<IdentityUserViewModel> userManager = HttpContext.Current.GetOwinContext().GetUserManager<UserManager<IdentityUserViewModel>>();
                IdentityUserViewModel user;
                if (HttpContext.Current.User != null)
                {
                    string userId = HttpContext.Current.User.Identity.GetUserId();
                    user = userManager.Users.FirstOrDefault(s => s.Id == userId);
                    if (user != null && user.IsSuperAdmin == true)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                LogUtilities.LogError(ex);
                return false;
            }
        }
        
    }
}