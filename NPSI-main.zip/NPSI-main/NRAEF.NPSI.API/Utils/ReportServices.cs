﻿using Newtonsoft.Json;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.ViewModel;
using Nustache.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.Utils
{
    public class ReportServices
    {
        // parse data and filling to whitespace in html file
        public static string FillDataInHtml<T>(T model, int mode)
        {
            // mode = 0: export detailed scoring sheets
            // mode = 1: export ranking report
            var response = JsonConvert.SerializeObject(model);
            var r = JsonConvert.DeserializeObject<T>(response);
            var templatePath = mode == 0 ? Constants.HtmlPaths.DETAILED_SCORING_SHEETS : Constants.HtmlPaths.RANKING_REPORT;
            templatePath = System.Web.Hosting.HostingEnvironment.MapPath("~/" + templatePath);
            string html = JsonToHtmlHelper.JsonToHtml(templatePath, r);
            return html;
        }


        public static List<ListDetailedScoringSheetsViewModel> GetDetailScoringSheetNoTeam(DetailedScoringSheetsViewModel model, NPSIEntities db)
        {
            var teams = new List<EventTeamViewModel>();
            var team = new EventTeamViewModel();
            var listData = new List<ListDetailedScoringSheetsViewModel>();

            if (model.TeamID == null)
            {
                teams = db.EventTeams.Where(et => et.EventID == model.EventID && et.Team.CategoryID == model.CategoryID)
                    .Select(et => new EventTeamViewModel
                    {
                        TeamID = et.TeamID,
                        TeamName = et.Team.Name,
                        StartTime = et.StartTime,
                        SortOrder = et.SortOrder,
                    }).OrderBy(et => et.StartTime).ThenBy(et => et.SortOrder).ToList();
                foreach (var item in teams)
                {
                    model.TeamID = item.TeamID;
                    var results = doGetDataDetailScoringSheet(model, db);
                    listData.Add(new ListDetailedScoringSheetsViewModel
                    {
                        ListData = results.ToList()
                    });
                }
            }

            return listData;
        }

        public static List<DetailedScoringSheetsViewModel> GetDetailScoringSheet(DetailedScoringSheetsViewModel model, NPSIEntities db)
        {
            var team = db.Teams
                .Where(t => t.ID == model.TeamID && t.CategoryID == model.CategoryID)
                .Select(t => new EventTeamViewModel
                {
                    TeamID = t.ID,
                    TeamName = t.Name,
                }).FirstOrDefault();
            model.TeamID = team.TeamID;
            var results = doGetDataDetailScoringSheet(model, db);
            return results;
        }

        private static List<DetailedScoringSheetsViewModel> doGetDataDetailScoringSheet(DetailedScoringSheetsViewModel model, NPSIEntities db)
        {
            if (model.JudgeUserID != null)
            {
                var judge = db.AspNetUsers.FirstOrDefault(u => u.Id == model.JudgeUserID);
            }
            var results = db.JudgeSectionAssignments
                .Where(w => w.EventID == model.EventID && w.EventSection.Section.CategoryID == model.CategoryID && (((model.JudgeUserID == null || model.JudgeUserID == "null") && w.JudgeUserID != null) || w.JudgeUserID == model.JudgeUserID))
                .Select(s => new DetailedScoringSheetsViewModel
                {
                    EventID = s.EventID,
                    EventName = s.EventSection.Event.Name,
                    CategoryID = s.EventSection.Event.Categories.FirstOrDefault(c => c.ID == model.CategoryID).ID,
                    CategoryName = s.EventSection.Event.Categories.FirstOrDefault(c => c.ID == model.CategoryID).Name.ToUpper(),
                    SectionID = s.SectionID,
                    SectionName = s.EventSection.Section.Name,
                    TeamID = model.TeamID,
                    TeamName = db.Teams.FirstOrDefault(t => t.ID == model.TeamID && t.CategoryID == model.CategoryID).Name,
                    JudgeName = db.AspNetUsers.FirstOrDefault(u => u.Id == s.JudgeUserID).FirstName + " " + db.AspNetUsers.FirstOrDefault(u => u.Id == s.JudgeUserID).LastName,
                    JudgePhone = db.AspNetUsers.FirstOrDefault(u => u.Id == s.JudgeUserID).PhoneNumber,
                    JudgeUserID = s.JudgeUserID,
                    TimeInOutNeeded = s.EventSection.Section.TimeInOutNeeded,
                    TimeIn = s.EventSection.Event.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == model.EventID && jst.TeamID == model.TeamID && (((model.JudgeUserID == null || model.JudgeUserID == "null") && jst.JudgeUserID == s.JudgeUserID) || jst.JudgeUserID == model.JudgeUserID) && jst.SectionID == s.SectionID).TimeIn,
                    TimeOut = s.EventSection.Event.JudgeSectionTeamInOuts.FirstOrDefault(jst => jst.EventID == model.EventID && jst.TeamID == model.TeamID && (((model.JudgeUserID == null || model.JudgeUserID == "null") && jst.JudgeUserID == s.JudgeUserID) || jst.JudgeUserID == model.JudgeUserID) && jst.SectionID == s.SectionID).TimeOut,
                    Subsections = s.EventSection.Section.Subsections
                      .Where(ss => ss.JudgeSubsectionAssignments.Any(j => (((model.JudgeUserID == null || model.JudgeUserID == "null") && j.JudgeUserID == s.JudgeUserID) || j.JudgeUserID == model.JudgeUserID) && j.EventID == model.EventID))
                      .Select(ss => new SubsectionScoreViewModel
                      {
                          EventID = s.EventID,
                          CategoryID = ss.Section.CategoryID,
                          TeamID = model.TeamID.Value,
                          SubSectionID = ss.ID,
                          SubSectionName = ss.Name,
                          Description = ss.Description,
                          SortIndex = ss.SortIndex,
                          Excellent = ss.MaxScore <= 5 ? "5" : ss.MaxScore <= 10 ? "9 - 10" : "13 - 15",
                          VeryGood = ss.MaxScore <= 5 ? "4" : ss.MaxScore <= 10 ? "7 - 8" : "10 - 12",
                          Good = ss.MaxScore <= 5 ? "3" : ss.MaxScore <= 10 ? "5 - 6" : "7 - 9",
                          Fair = ss.MaxScore <= 5 ? "2" : ss.MaxScore <= 10 ? "3 - 4" : "4 - 6",
                          Poor = ss.MaxScore <= 5 ? "1" : ss.MaxScore <= 10 ? "1 - 2" : "1 - 3",
                          ScoreConcept = ss.Scores.FirstOrDefault(f => f.SubsectionID == ss.ID && ((f.JudgeUserID == s.JudgeUserID && (model.JudgeUserID == null || model.JudgeUserID == "null")) || f.JudgeUserID == model.JudgeUserID) && f.EventID == model.EventID && f.TeamID == model.TeamID).Score1,
                          Comments = ss.Scores.FirstOrDefault(f => f.SubsectionID == ss.ID && ((f.JudgeUserID == s.JudgeUserID && (model.JudgeUserID == null || model.JudgeUserID == "null")) || f.JudgeUserID == model.JudgeUserID) && f.EventID == model.EventID && f.TeamID == model.TeamID).Comments,
                          Image = ss.Scores.FirstOrDefault(f => f.SubsectionID == ss.ID && ((f.JudgeUserID == s.JudgeUserID && (model.JudgeUserID == null || model.JudgeUserID == "null")) || f.JudgeUserID == model.JudgeUserID) && f.EventID == model.EventID && f.TeamID == model.TeamID).Photo,
                      }).OrderBy(ss => ss.SortIndex == null ? 999 : ss.SortIndex).ToList(),
                    Disqualifications = s.EventSection.Section.TeamSectionDisqualifications
                      .Where(tsd => tsd.EventID == model.EventID && (((model.JudgeUserID == null || model.JudgeUserID == "null") && tsd.JudgeUserID == s.JudgeUserID) || tsd.JudgeUserID == model.JudgeUserID) && tsd.TeamID == model.TeamID)
                      .Select(tsd => new DisqualificationViewModel
                      {
                          ID = tsd.DisqualificationID,
                          Name = tsd.Disqualification.Name,
                      }).ToList(),
                    Penalties = s.EventSection.Section.TeamSectionPenalties
                      .Where(tsp => tsp.EventID == model.EventID && tsp.PenaltyStatusID == Constants.PenaltyStatus.APPROVED && (((model.JudgeUserID == null || model.JudgeUserID == "null") && tsp.JudgeUserID == s.JudgeUserID) || tsp.JudgeUserID == model.JudgeUserID) && tsp.TeamID == model.TeamID)
                      .Select(tsp => new PenaltyViewModel
                      {
                          ID = tsp.PenaltyID,
                          Name = tsp.Penalty.Name,
                          DeductionScore = tsp.Deduction
                      }).ToList(),
                    SortOrder = s.EventSection.Section.SortOrder
                }).OrderBy(s => s.SortOrder);
            if (model.JudgeUserID == null || model.JudgeUserID == "null")
            {
                results = results.ThenBy(r => r.JudgeName);
            }
            return results.ToList();
        }

        public static List<RankingReportViewModel> GetSectionByEventAndTeam(RankingReportViewModel model, NPSIEntities db)
        {
            var listData = new List<RankingReportViewModel>();
            if (model.TeamID == null)
            {
                var teams = db.EventTeams.Where(et => et.EventID == model.EventID && et.Team.CategoryID == model.CategoryID)
                    .Select(et => new EventTeamViewModel
                    {
                        TeamID = et.TeamID,
                        TeamName = et.Team.Name,
                        StartTime = et.StartTime,
                        SortOrder = et.SortOrder,
                    }).OrderBy(et => et.StartTime).ThenBy(et => et.SortOrder).ToList();
                foreach (var item in teams)
                {
                    model.TeamID = item.TeamID;
                    var results = doGetSectionByEventAndTeam(model, db);
                    listData.Add(results);
                }
            }
            return listData;

        }

        public static RankingReportViewModel doGetSectionByEventAndTeam(RankingReportViewModel model, NPSIEntities db)
        {
            var eventResult = db.Events.FirstOrDefault(e => e.ID == model.EventID);

            var penalties = db.TeamSectionPenalties
                .Where(tsp => tsp.EventID == model.EventID && tsp.PenaltyStatusID == Constants.PenaltyStatus.APPROVED && (model.TeamID == 0 || tsp.TeamID == model.TeamID) && tsp.Section.CategoryID == model.CategoryID)
                .Select(tsp => new
                {
                  PenaltyID = tsp.PenaltyID,
                  PenaltyName = tsp.Penalty.Name,
                  Deduction = tsp.Deduction,
                  SectionID = tsp.SectionID,
                  JudgeUserID = tsp.JudgeUserID,
                })
                .GroupBy(p => new
                {
                  p.SectionID,
                  p.PenaltyID,
                  p.PenaltyName
                })
                .Select(p => new
                {
                  SectionID = p.Key.SectionID,
                  PenaltyID = p.Key.PenaltyID,
                  PenaltyName = p.Key.PenaltyName,
                  DeductionScore = p.Max(d => d.Deduction)
                })
                .GroupBy(p => new 
                { 
                  p.PenaltyName 
                })
                .Select(p => new PenaltyTeamViewModel
                {
                  DeductionScore = p.Sum(item => item.DeductionScore),
                  PenaltyName = p.Key.PenaltyName,
                })
                .ToList();

            var scores = db.Scores
                .Where(sc => sc.TeamID == model.TeamID && sc.Team.CategoryID == model.CategoryID && sc.EventID == model.EventID)
                .ToList();

            var result = eventResult.EventTeams
                .Where(et => et.TeamID == model.TeamID && et.Team.CategoryID == model.CategoryID)
                .Select(et => new RankingReportViewModel
                {
                  EventID = eventResult.ID,
                  EventName = eventResult.Name,
                  CategoryID = et.Team.CategoryID,
                  CategoryName = et.Team.Category.Name.ToUpper(),
                  TeamID = et.TeamID,
                  TeamName = et.Team.Name,
                  Sections = et.Event.EventSections.Where(es => es.Section.CategoryID == model.CategoryID)
                    .Select(es => new SectionTeamViewModel
                    {
                      SectionID = es.SectionID,
                      SectionName = es.Section.Name,
                      SortOrder = es.Section.SortOrder,
                      Subsections = es.Section.Subsections
                        .Select(ss => new SubsectionTeamViewModel
                        {
                          SubsectionID = ss.ID,
                          SubsectionName = ss.Name,
                          SortIndex = ss.SortIndex,
                          ScorePerCategory = scores.Count > 0 ? scores.Where(sc => sc.SubsectionID == ss.ID).Select(sc => sc.Score1).DefaultIfEmpty().Average() : 0
                        }).OrderBy(ss => ss.SortIndex == null ? 999 : ss.SortIndex).ToList(),
                      CountSubsections = es.Section.Subsections.Count,
                      TotalScoreReceived = scores.Count > 0 ? es.Section.Subsections.Sum(ss => scores.Where(sc => sc.SubsectionID == ss.ID).Select(sc => sc.Score1).DefaultIfEmpty().Average()) : 0,
                      TotalScorePossible = es.Section.Subsections.Sum(ss => ss.MaxScore),
                      PercentScoreReceived = (scores.Count > 0 || es.Section.Subsections.Sum(ss => ss.MaxScore) > 0) ? PercentScoreSection(es.Section.Subsections.Sum(ss => scores.Where(sc => sc.SubsectionID == ss.ID).Select(sc => sc.Score1).DefaultIfEmpty().Average()), es.Section.Subsections.Sum(ss => ss.MaxScore)) : 0
                    }).OrderBy(s => s.SortOrder).ToList(),
                  Penalties = penalties.Select(p => new PenaltyTeamViewModel
                  {
                    PenaltyName = p.PenaltyName,
                    DeductionScore = p.DeductionScore,
                  }).ToList(),
                  TotalPointsFromJudges = scores.Count > 0 ? et.Event.EventSections.Sum(es => es.Section.Subsections.Sum(ss => scores.Where(sc => sc.SubsectionID == ss.ID).Select(sc => sc.Score1).DefaultIfEmpty().Average())) : 0,
                  TotalPointsPenalties = penalties.Sum(p => p.DeductionScore),
                  TotalPointsReceived = scores.Count > 0 ? TotalScoreReceived(et.Event.EventSections.Sum(es => es.Section.Subsections.Sum(ss => scores.Where(sc => sc.SubsectionID == ss.ID).Select(sc => sc.Score1).DefaultIfEmpty().Average())), penalties.Sum(tsp => tsp.DeductionScore)) : 0,
                  CountPenalties = penalties.Count,
                }).FirstOrDefault();

            return result;
        }

        public static OverallRankingViewModel GetOverallRankByEventAndCategory(OverallRankingEventViewModel model, NPSIEntities db)
        {
            var eventResult = db.Events.FirstOrDefault(e => e.ID == model.EventID);
            var penalties = db.TeamSectionPenalties.Where(tsp => tsp.EventID == model.EventID && tsp.PenaltyStatusID == Constants.PenaltyStatus.APPROVED && tsp.Section.CategoryID == model.CategoryID)
                 .Select(tsp => new
                 {
                     SectionID = tsp.SectionID,
                     TeamID = tsp.TeamID,
                     PenaltyID = tsp.PenaltyID,
                     PenaltyName = tsp.Penalty.Name,
                     Deduction = tsp.Deduction
                 }).GroupBy(p => new { p.SectionID, p.TeamID, p.PenaltyID, p.PenaltyName }).Select(p => new PenaltyTeamViewModel
                 {
                     SectionID = p.Key.SectionID,
                     TeamID = p.Key.TeamID,
                     PenaltyID = p.Key.PenaltyID,
                     PenaltyName = p.Key.PenaltyName,
                     DeductionScore = p.Sum(d => d.Deduction)
                 }).ToList();
            var sectionRanks = eventResult.EventSections.Where(et => et.EventID == model.EventID && et.Section.CategoryID == model.CategoryID)
                 .Select(es => new OverallRankingSectionViewModel
                 {
                     CategoryID = es.Section.CategoryID,
                     CategoryName = es.Section.Category.Name,
                     EventID = es.EventID,
                     SectionID = es.SectionID,
                     SectionName = es.Section.Name,
                     SortOrder = es.Section.SortOrder,
                     Teams = es.Event.EventTeams.Where(et => et.Team.CategoryID == model.CategoryID)
                     .Select(et => new OverallRankingTeamViewModel
                     {
                         TeamID = et.TeamID,
                         TeamName = et.Team.Name,
                         StartTime = et.StartTime,
                         SortOrder = et.SortOrder,
                         Score = TotalScoreReceived(
                          et.Team.Scores.Where(sc => sc.Team.CategoryID == model.CategoryID && sc.Subsection.SectionID == es.SectionID && sc.EventID == model.EventID)
                           .Select(sc => new
                           {
                               Score = sc.Score1,
                               SubsectionID = sc.SubsectionID
                           }).GroupBy(sc => sc.SubsectionID)
                           .Select(ss => new { Score = ss.Average(a => a.Score) })
                           .Sum(s => s.Score), 
                          penalties.Where(p => p.TeamID == et.TeamID && p.SectionID == es.SectionID).Sum(p => p.DeductionScore)
                         ),
                     })
                     .OrderByDescending(et => et.Score)
                     .ThenBy(et => et.StartTime)
                     .ThenBy(et => et.SortOrder).ToList()
                 }).OrderBy(es => es.SortOrder).ToList();

            var result = new OverallRankingViewModel();
            result.Sections = sectionRanks;
            result.Overall = eventResult.EventTeams
                .Where(et => et.Team.CategoryID == model.CategoryID)
                .Select(et => new OverallRankingEventViewModel()
                {
                    CategoryID = et.Team.CategoryID,
                    CategoryName = et.Team.Category.Name,
                    EventID = et.EventID,
                    TeamID = et.TeamID,
                    TeamName = et.Team.Name,
                    StartTime = et.StartTime,
                    SortOrder = et.SortOrder,
                    Score = sectionRanks.Sum(sr => sr.Teams.FirstOrDefault(t => t.TeamID == et.TeamID).Score)
                }).OrderByDescending(et => et.Score).ThenBy(et => et.StartTime).ThenBy(et => et.SortOrder).ToList();
            return result;
        }

        private static decimal? PercentScoreSection(decimal? totalScoreReceived, decimal? totalMaxScore)
        {
            decimal? result = 0;
            if (totalMaxScore > 0)
            {
                result = (totalScoreReceived / totalMaxScore) * 100;
            }
            return result;
        }

        private static decimal? TotalScoreReceived(decimal? totalScore, decimal? totalScorePenalties)
        {
            return totalScore - totalScorePenalties;
        }

        public static byte[] AddImageAndParseToByteArray(DetailedScoringSheetsViewModel item, List<byte[]> arrByte)
        {
            item.JudgeContact = item.JudgePhone == null ? null : Convert.ToInt64(item.JudgePhone).ToString("###-###-####");
            foreach (var i in item.Subsections)
            {
                if (i.Image != null)
                {
                    i.Photo = Convert.ToBase64String(i.Image);
                }
                if (!string.IsNullOrEmpty(i.Comments))
                {
                    i.Comments = TextToHtml(i.Comments);
                }
            }
            var result = FillDataInHtml(item, 0);
            byte[] reportBytes = ParseToExcel.ParseHtmlToExcel(result, true, true);

            return reportBytes;
        }

        private static string TextToHtml(string text)
        {
            text = HttpUtility.HtmlEncode(text);
            text = text.Replace("\r\n", "\r");
            text = text.Replace("\n", "\r");
            text = text.Replace("\r", "<br />");
            text = text.Replace("  ", " &nbsp;");
            return text;
        }
    }
    public class JsonToHtmlHelper
    {
        public static string JsonToHtml(string path, object data)
        {
            AddNustacheHelpler("FormatDecimal", FormatDecimal);
            AddNustacheHelpler("FormatDecimal1", FormatDecimal1);
            AddNustacheHelpler("FormatTime", FormatTime);
            var html = Render.FileToString(path, data);
            return html;
        }

        static void AddNustacheHelpler(string name, Helper helper)
        {
            if (!Helpers.Contains(name))
            {
                Helpers.Register(name, helper);
            }
        }
        static void FormatDecimal(RenderContext context, IList<object> arguments, IDictionary<string, object> options, RenderBlock fn, RenderBlock inverse)
        {
            if (arguments != null && arguments.Count > 0 && arguments[0] != null)
            {

                string value = arguments[0].ToString();
                try
                {
                    Decimal decimalValue = Decimal.Parse(value);
                    string formatValue = String.Format("{0:n3}", decimalValue);
                    if (formatValue.EndsWith("000"))
                    {
                        formatValue = formatValue.Replace(".000", "");
                    }
                    context.Write(formatValue);
                }
                catch (Exception)
                {
                    context.Write(value);
                }
            }
        }

        static void FormatDecimal1(RenderContext context, IList<object> arguments, IDictionary<string, object> options, RenderBlock fn, RenderBlock inverse)
        {
            if (arguments != null && arguments.Count > 0 && arguments[0] != null)
            {

                string value = arguments[0].ToString();
                try
                {
                    Decimal decimalValue = Decimal.Parse(value);
                    string formatValue = String.Format("{0:n3}", decimalValue);
                    context.Write(formatValue);
                }
                catch (Exception)
                {
                    context.Write(value);
                }
            }
        }

        static void FormatTime(RenderContext context, IList<object> arguments, IDictionary<string, object> options, RenderBlock fn, RenderBlock inverse)
        {
            if (arguments != null && arguments.Count > 0 && arguments[0] != null)
            {
                string value = arguments[0].ToString();
                try
                {
                    DateTime datetime = DateTime.Parse(value);
                    if (options != null && options.ContainsKey("format"))
                        context.Write(datetime.ToString(options["format"] as string));
                    else
                        context.Write(datetime.ToString("hh:mm tt"));
                }
                catch (Exception)
                {
                    context.Write(value);
                }
            }
        }

    }
}

public class penaltyModel
{
    public int count { get; set; }
    public int sectionID { get; set; }
    public int penaltyID { get; set; }
    public int teamID { get; set; }
}