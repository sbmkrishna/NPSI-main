﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using iTextSharp.tool.xml.css;
using iTextSharp.tool.xml.html;
using iTextSharp.tool.xml.parser;
using iTextSharp.tool.xml.pipeline.css;
using iTextSharp.tool.xml.pipeline.end;
using iTextSharp.tool.xml.pipeline.html;
using NRAEF.NPSI.API.Models;
using NRAEF.NPSI.API.ViewModel;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace NRAEF.NPSI.API.Utils
{
    public class ParseToExcel
    {

        public static byte[] ParseHtmlToExcel(string htmlContent, bool isLandscapePage, bool isExistImage)
        {
            byte[] pdfFile = new byte[] { };
            using (var ms = new MemoryStream())
            {
                var doc = new Document();
                if (isLandscapePage)
                {
                    doc.SetPageSize(PageSize.A4.Rotate());
                }
                var writer = PdfWriter.GetInstance(doc, ms);
                doc.Open();

                var cssPath = System.Web.Hosting.HostingEnvironment.MapPath(Constants.HtmlPaths.CSS_FILE);
                string css = File.ReadAllText(cssPath);

                var tagProcessors = (DefaultTagProcessorFactory)Tags.GetHtmlTagProcessorFactory();

                if (isExistImage)
                {
                    tagProcessors.RemoveProcessor(HTML.Tag.IMG); // remove the default processor
                    tagProcessors.AddProcessor(HTML.Tag.IMG, new CustomImageTagProcessor()); // use our new processor
                }

                CssFilesImpl cssFiles = new CssFilesImpl();
                cssFiles.Add(XMLWorkerHelper.GetInstance().GetDefaultCSS());
                var cssResolver = new StyleAttrCSSResolver(cssFiles);
                cssResolver.AddCss(css, "utf-8", true);

                var hpc = new HtmlPipelineContext(new CssAppliersImpl(new XMLWorkerFontProvider()));
                hpc.SetAcceptUnknown(true).AutoBookmark(true).SetTagFactory(tagProcessors); // inject the tagProcessors

                var htmlPipeline = new HtmlPipeline(hpc, new PdfWriterPipeline(doc, writer));
                var pipeline = new CssResolverPipeline(cssResolver, htmlPipeline);

                //Parse the HTML
                var worker = new XMLWorker(pipeline, true);
                var xmlParser = new XMLParser(true, worker, Encoding.UTF8);
                xmlParser.Parse(new StringReader(htmlContent.Replace("<br>", "")));
               
                doc.Close();
                return pdfFile = ms.ToArray();

            }
        }

        public static byte[] ConcatAndAddContent(List<byte[]> pdfByteContent)
        {

            using (var ms = new MemoryStream())
            {
                using (var doc = new Document())
                {
                    using (var copy = new PdfSmartCopy(doc, ms))
                    {
                        doc.Open();
                        //Loop through each byte array
                        foreach (var p in pdfByteContent)
                        {
                            //Create a PdfReader bound to that byte array
                            using (var reader = new PdfReader(p))
                            {
                                //Add the entire document instead of page-by-page
                                copy.AddDocument(reader);
                            }
                        }
                        doc.Close();
                    }
                }

                //Return just before disposing
                return ms.ToArray();
            }
        }

        public static Stream CreateExcelFile(OverallRankingEventViewModel model, NPSIEntities db)
        {
            var stream = new MemoryStream();
            var rawData = ReportServices.GetOverallRankByEventAndCategory(model, db);
            using (var excelPackage = new ExcelPackage(stream))
            {
                // create author for file Excel
                excelPackage.Workbook.Properties.Author = "NPSI";
                // create title for file Excel
                excelPackage.Workbook.Properties.Title = "Overall Ranking";
                // Add Sheet in file Excel
                excelPackage.Workbook.Worksheets.Add("Overall Ranking");
                // call new Sheet to do
                var workSheet = excelPackage.Workbook.Worksheets[1];
                // Input TITLE to Excel file
                workSheet.Cells["A1:C1"].Value = "Overall " + rawData.Overall[0].CategoryName + " Team Ranking";
                // Input data from list
                BindingFormatForExcel(workSheet);
                //CREATE NEW SHEET IF EVENT HAVE SECTIONS
                if (rawData.Overall.Count > 0)
                {
                    // CREATE HEADER TABLE FOR NEW SHEET
                    for (int i = 0; i < rawData.Overall.Count; i++)
                    {
                        var item = rawData.Overall[i];
                        workSheet.Cells[i + 4, 1].Value = i + 1;
                        workSheet.Cells[i + 4, 2].Value = item.TeamName;
                        workSheet.Cells[i + 4, 3].Value = item.Score;
                        workSheet.Cells[i + 4, 3].Style.Numberformat.Format = item.Score == 0 ? "0.000" : "#,##.000";
                    }
                    // INPUT DATA FOR SHEET
                    for (var i = 0; i < rawData.Sections.Count; i++)
                    {
                        var item = rawData.Sections[i];
                        excelPackage.Workbook.Worksheets.Add(item.SectionName);
                        var sectionWorksheet = excelPackage.Workbook.Worksheets[i + 2];
                        // VALUE FOR TITLE CELLS
                        sectionWorksheet.Cells["A1:C1"].Value = item.SectionName + " Team Ranking";
                        BindingFormatForExcel(sectionWorksheet);
                        for (int j = 0; j < item.Teams.Count; j++)
                        {
                            var team = item.Teams[j];
                            sectionWorksheet.Cells[j + 4, 1].Value = j + 1;
                            sectionWorksheet.Cells[j + 4, 2].Value = team.TeamName;
                            sectionWorksheet.Cells[j + 4, 3].Value = team.Score;
                            sectionWorksheet.Cells[j + 4, 3].Style.Numberformat.Format = team.Score == 0 ? "0.000" : "#,##.000";
                        }
                    }
                }
                excelPackage.Save();
                return excelPackage.Stream;
            }
        }

        private static void BindingFormatForExcel(ExcelWorksheet worksheet)
        {
            System.Drawing.Color HEADER_FILL_BACKGROUND_COLOR = System.Drawing.Color.FromArgb(0, 0, 0);
            System.Drawing.Color HEADER_FILL_COLOR = System.Drawing.Color.FromArgb(255, 255, 255);
            // Set default width all column
            worksheet.DefaultColWidth = 10;
            // auto wrap when text is longer
            worksheet.Cells.Style.WrapText = true;
            // AUTO ALIGN CENTER FOR CELLS
            worksheet.Cells.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            // create header list
            var columnHeaders = new List<string>
            {
                "PLACE", "SCHOOL NAME", "SCORE"
            };
            // MERGE CELLS FOR TITLE SHEET
            worksheet.Cells["A1:C1"].Merge = true;
            // SET WIDTH FOR COLUMN SCHOOL NAME 
            worksheet.Column(2).Width = 35;
            for (var i = 0; i < columnHeaders.Count; i++)
            {
                worksheet.Cells[3, i + 1].Value = columnHeaders[i];
                worksheet.Cells[3, i + 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[3, i + 1].Style.Font.Bold = true;
                worksheet.Cells[3, i + 1].Style.Fill.BackgroundColor.SetColor(HEADER_FILL_BACKGROUND_COLOR);
                worksheet.Cells[3, i + 1].Style.Font.Color.SetColor(HEADER_FILL_COLOR);
                worksheet.Cells[3, i + 1].Style.Font.Size = 11;
            }

        }
    }

    public class CustomImageTagProcessor : iTextSharp.tool.xml.html.Image
    {
        public override IList<IElement> End(IWorkerContext ctx, Tag tag, IList<IElement> currentContent)
        {
            IDictionary<string, string> attributes = tag.Attributes;
            string src;
            if (!attributes.TryGetValue(HTML.Attribute.SRC, out src))
                return new List<IElement>(1);

            if (string.IsNullOrEmpty(src))
                return new List<IElement>(1);

            if (src.StartsWith("data:image/", StringComparison.InvariantCultureIgnoreCase))
            {
                // data:[<MIME-type>][;charset=<encoding>][;base64],<data>
                var base64Data = src.Substring(src.IndexOf(",") + 1);
                var imagedata = Convert.FromBase64String(base64Data);
                var image = iTextSharp.text.Image.GetInstance(imagedata);

                var list = new List<IElement>();
                var htmlPipelineContext = GetHtmlPipelineContext(ctx);
                list.Add(GetCssAppliers().Apply(new Chunk((iTextSharp.text.Image)GetCssAppliers().Apply(image, tag, htmlPipelineContext), 0, 0, true), tag, htmlPipelineContext));
                return list;
            }
            else
            {
                return base.End(ctx, tag, currentContent);
            }
        }
    }
}
