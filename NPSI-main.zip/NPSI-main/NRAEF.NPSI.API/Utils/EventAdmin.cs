﻿using Microsoft.AspNet.Identity;
using NRAEF.NPSI.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.Utils
{
    public class EventAdmin
    {
        public static bool CheckRolesAdminOrEventAdmin(string currentUserId)
        {
            using (NPSIEntities db = new NPSIEntities())
            {
                var roles = db.UserEventRoles.Where(s => s.UserID == currentUserId).Select(x => x.AspNetRole.Name).Distinct().ToList();
                var user = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserId);
                if (roles.Contains(Utils.Constants.Roles.EVENTADMIN) || user.IsSuperAdmin == true || roles.Contains(Utils.Constants.Roles.LEADJUDGE))
                {
                    return true;
                }
                return false;
            }
        }
        public static bool CheckEventRoles(string currentUserId, int eventID)
        {
            using (NPSIEntities db = new NPSIEntities())
            {
                var roles = db.UserEventRoles.Where(s => s.UserID == currentUserId && s.EventID == eventID).Select(x => x.AspNetRole.Name).Distinct().ToList();
                var user = db.AspNetUsers.FirstOrDefault(s => s.Id == currentUserId);
                if (roles.Contains(Utils.Constants.Roles.EVENTADMIN) || user.IsSuperAdmin == true)
                {
                    return true;
                }
                return false;
            }
        }
    }
}