﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.Utils
{
    public class Constants
    {
        public struct EventStatuses
        {
            public const string OPENED = "Opened";
            public const string STARTED = "Started";
            public const string COMPLETED = "Completed";
        }
        public struct Roles
        {
            public const string JUDGE = "Judge";
            public const string LEADJUDGE = "Lead Judge";
            public const string EVENTADMIN = "Event - Admin";
        }
        public struct HtmlPaths
        {
            public const string DETAILED_SCORING_SHEETS = "Html_files/detailedScoringSheets.html";
            public const string RANKING_REPORT = "Html_files/rankingReport.html";
            public const string CSS_FILE = "~/Html_files/asset.css";
        }
        public struct PenaltyStatus
        {
          public const int APPROVED = 1;
          public const int PENDING = 0;
          public const int DENIED = -1;
        }
    }
}