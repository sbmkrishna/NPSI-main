﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API
{
    public class LogUtilities
    {
        public static readonly log4net.ILog log = log4net.LogManager.GetLogger("RollingFileAppender");

        // Log error when the error jump to catch
        public static void LogError(object ex)
        {
            if (log != null)
            {
                log.Error(ex);
                try
                {
                    Exception exception = ex as Exception;
                    if (exception != null && exception.InnerException != null)
                    {
                        LogError(exception.InnerException);
                    }
                }
                catch (Exception)
                {
                }

            }
        }
    }
}