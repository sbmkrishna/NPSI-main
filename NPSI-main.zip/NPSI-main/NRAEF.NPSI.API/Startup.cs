﻿

using log4net.Config;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;
using NRAEF.NPSI.API.ViewModel;
using Owin;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http.Formatting;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;


[assembly: OwinStartup(typeof(NRAEF.NPSI.API.Startup))]
namespace NRAEF.NPSI.API
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            //XmlConfigurator.Configure();
            ConfigureOAuth(app);
        }

        private void ConfigureOAuth(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();
            var corsAttr = new EnableCorsAttribute("*", "*", "*") { SupportsCredentials = true };

            config.EnableCors(corsAttr);
            config.MapHttpAttributeRoutes();
            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            app.CreatePerOwinContext<AuthContext>(() => new AuthContext());
            app.CreatePerOwinContext<UserManager<IdentityUserViewModel>>(CreateManager);
            var jsonFormatter = config.Formatters.OfType<JsonMediaTypeFormatter>().First();
            jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            app.UseOAuthAuthorizationServer(new OAuthAuthorizationServerOptions
            {
                TokenEndpointPath = new PathString("/oauth/token"),
                Provider = new AuthorizationServerProvider(),
                AccessTokenExpireTimeSpan = TimeSpan.FromHours(12),
                AllowInsecureHttp = true,

            });
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions());
            app.UseWebApi(config);
        }

        public class AuthorizationServerProvider : OAuthAuthorizationServerProvider
        {
            public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
            {
                context.Validated();
            }
            public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
            {
                UserManager<IdentityUserViewModel> userManager = context.OwinContext.GetUserManager<UserManager<IdentityUserViewModel>>();
                IdentityUserViewModel user;
                try
                {
                    user = await userManager.FindAsync(context.UserName, context.Password);
                    int max = 10;
                    int.TryParse(ConfigurationManager.AppSettings["maxAccessFailedCount"], out max);
                    if (user == null)
                    {
                        var usr = await userManager.FindByNameAsync(context.UserName);
                        if (usr != null)
                        {
                            if (usr.LockoutEnabled)
                            {
                                context.SetError("invalid_grant", "Sorry, your account has been locked due to too many unsuccessfull login attempts. Please contact web administrator for unlock.");
                            }
                            else
                            {
                                usr.AccessFailedCount++;
                                context.SetError("invalid_grant", "Invalid username or password.");


                                if (usr.AccessFailedCount >= max) usr.LockoutEnabled = true;
                                await userManager.UpdateAsync(usr);
                            }
                        }
                        else
                        {
                            context.SetError("invalid_grant", "Invalid username or password.");
                        }

                        return;
                    }

                    if (user.AccessFailedCount >= max)
                    {
                        context.SetError("invalid_grant", "Sorry, your account has been locked due to too many unsuccessfull login attempts. Please contact web administrator for unlock.");
                        return;
                    }

                    if (user.LockoutEnabled)
                    {
                        context.SetError("invalid_grant", "Sorry, your account is waiting for approval or has been deactivated.");
                        return;
                    }

                    //check number login fail and reset 0 if login success
                    if (user.AccessFailedCount > 0)
                    {
                        user.AccessFailedCount = 0;
                        await userManager.UpdateAsync(user);
                    }
                }
                catch (Exception ex)
                {
                    // Could not retrieve the user due to error.
                    context.SetError("server_error");
                    context.Rejected();
                    return;
                }
                if (user != null)
                {
                    ClaimsIdentity identity = await userManager.CreateIdentityAsync(
                                                            user,
                                                            DefaultAuthenticationTypes.ExternalBearer);
                    if (user.IsSuperAdmin == true)
                    {
                        identity.AddClaims(new[] {
                            new Claim("IsSuperAdmin","true"),
                        });
                    }
                    context.Validated(identity);
                }
                else
                {
                    context.SetError("invalid_grant", "Invalid UserId or password'");
                    context.Rejected();
                }
            }
        }

        private static UserManager<IdentityUserViewModel> CreateManager(IdentityFactoryOptions<UserManager<IdentityUserViewModel>> options, IOwinContext context)
        {
            var userStore = new UserStore<IdentityUserViewModel>(context.Get<AuthContext>());
            var owinManager = new UserManager<IdentityUserViewModel>(userStore);
            return owinManager;
        }
    }
}