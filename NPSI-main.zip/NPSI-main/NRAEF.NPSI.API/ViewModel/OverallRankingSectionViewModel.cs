﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class OverallRankingSectionViewModel
    {
        public int EventID { get; set; }
        public int CategoryID { get; set; }
        public int SectionID { get; set; }
        public short? SortOrder { get; set; }
        public string SectionName { get; set; }
        public string CategoryName { get; set; }
        public List<OverallRankingTeamViewModel> Teams { get; set; }
    }
    public class OverallRankingTeamViewModel
    {
        public int Place { get; set; }
        public int TeamID { get; set; }
        public string TeamName { get; set; }
        public decimal? Score { get; set; }
        public decimal AverageScore { get; set; }
        public decimal AverageScore1 { get; set; }
        public int? SortOrder { get; set; }
        public DateTime StartTime { get; set; }
    }
}