﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class JudgeEventSectionViewModel
    {
        public string JudgeUserID { get; set; }
        public int SectionID { get; set; }
        public int EventID { get; set; }
    }
}