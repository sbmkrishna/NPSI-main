﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class RankingReportViewModel
    {
        public int EventID { get; set; }
        public int CategoryID { get; set; }
        public int? TeamID { get; set; }
        public int CountPenalties { get; set; }
        public string EventName { get; set; }
        public string CategoryName { get; set; }
        public string TeamName { get; set; }
        public decimal? TotalPointsFromJudges { get; set; }
        public decimal TotalPointsPenalties { get; set; }
        public decimal? TotalPointsReceived { get; set; }
        public List<PenaltyTeamViewModel> Penalties { get; set; }
        public List<SectionTeamViewModel> Sections { get; set; }
    }

    public class SectionTeamViewModel
    {
        public int SectionID { get; set; }
        public int CountSubsections { get; set; }
        public short? SortOrder { get; set; }
        public string SectionName { get; set; }
        public decimal? TotalScoreReceived { get; set; }
        public decimal? TotalScorePossible { get; set; }
        public decimal? PercentScoreReceived { get; set; }
        public List<SubsectionTeamViewModel> Subsections { get; set; }
    }

    public class SubsectionTeamViewModel
    {
        public int SubsectionID { get; set; }
        public string SubsectionName { get; set; }
        public decimal? ScorePerCategory { get; set; }
        public int? SortIndex { get; set; }
        public bool FirstIndex { get; set; }
    }

    public class PenaltyTeamViewModel
    {
        public int PenaltyID { get; set; }
        public int SectionID { get; set; }
        public int TeamID { get; set; }
        public int Count { get; set; }
        public string JudgeUserID { get; set; }
        public string PenaltyName { get; set; }
        public decimal Deduction { get; set; }
        public decimal DeductionScore { get; set; }
        public bool FirstIndex { get; set; }
        public int PenaltyStatusID { get; set; }
    }

    public class ListRankingReportViewModel
    {
        public List<RankingReportViewModel> ListData { get; set; }
        public ListRankingReportViewModel()
        {
            this.ListData = new List<RankingReportViewModel>();
        }
    }

}