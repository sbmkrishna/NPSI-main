﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class SectionViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }
        public short CategoryID { get; set; }
        public short? SortOrder { get; set; }
        public string CategoryName { get; set; }
        public List<EventTeamViewModel> Teams { get; set; }
        public DateTimeOffset? SubmittedDateTime { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public DateTime? DateTimeInOut { get; set; }
        public bool TimeInOutNeeded { get; set; }
    }
}