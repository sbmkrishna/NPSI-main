﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class JudgeSectionAssignmentViewModel
    {
        public string JudgeUserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int SectionID { get; set; }
        public int EventID { get; set; }
        public DateTimeOffset? SubmittedDateTime { get; set; }
        public bool IsExist { get; set; }
    }
}