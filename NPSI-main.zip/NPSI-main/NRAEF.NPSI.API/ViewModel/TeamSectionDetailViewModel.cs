﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class TeamSectionDetailViewModel
    {
        public int EventID { get; set; }
        public int SectionID { get; set; }
        public int TeamID { get; set; }
        public int CategoryID { get; set; }
        public short? SortOrder { get; set; }
        public string TeamName { get; set; }
        public string CategoryName { get; set; }
        public string EventName { get; set; }
        public string StatusName { get; set; }
        public string SectionName { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public bool TimeInOutNeeded { get; set; }
        public string GeneralComments { get; set; }
  }
}