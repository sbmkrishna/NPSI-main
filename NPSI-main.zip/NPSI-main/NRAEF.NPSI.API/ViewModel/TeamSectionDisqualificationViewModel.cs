﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class TeamSectionDisqualificationViewModel
    {
        public int ID { get; set; }
        public DateTimeOffset CreatedDateTime { get; set; }
        public int DisqualificationID { get; set; }
        public string JudgeUserID { get; set; }
        public int TeamID { get; set; }
        public int EventID { get; set; }
        public int SectionID { get; set; }
        public string Comments { get; set; }
        public byte[] Photo { get; set; }
        public string Name { get; set; }
    }
}