﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class EventSectionTeamJudgeViewModel
    {
        public int EventID { get; set; }
        public string EventName { get; set; }
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public int SectionID { get; set; }
        public string SectionName { get; set; }
        public int TeamID { get; set; }
        public string TeamName { get; set; }
        public string SchoolName { get; set; }
        public string TeamEmail { get; set; }
        public string TeamPhone { get; set; }
        public bool Active { get; set; }
        public DateTime Date { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string JudgeUserID { get; set; }
        public string JudgeFirstName { get; set; }
        public string JudgeLastName { get; set; }
        public bool Done { get; set; }
        public bool TimeInOutNeeded { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public DateTime? DateTimeInOut { get; set; }
        public int? SortOrder { get; set; }
        public string Comments { get; set; }
        public List<SubsectionScoreViewModel> SubsectionScores { get; set; }
        public List<TeamSectionPenaltiesViewModel> Penalties { get; set; }
        public List<TeamSectionDisqualificationViewModel> Disqualifications { get; set; }
    }
}