﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class JudgeSectionTimeInOutViewModel
    {
        public int EventID { get; set; }
        public int TeamID { get; set; }
        public int SectionID { get; set; }
        public string JudgeUserID { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public string GeneralComments { get; set; }
    }
}