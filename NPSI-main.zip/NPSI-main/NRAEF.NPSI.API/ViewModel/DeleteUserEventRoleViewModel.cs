﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class DeleteUserEventRoleViewModel
    {
        public int EventID { get; set; }
        public string UserID { get; set; }
        public int CategoryID { get; set; }
    }
}