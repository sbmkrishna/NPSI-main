﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class EventUserViewModel
    {
        public string Username { get; set; }
        public string Rolename { get; set; }
        public int EventId { get; set; }
        public string UserId { get; set; }
        public string RoleID { get; set; }
        public short CatogoryID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}