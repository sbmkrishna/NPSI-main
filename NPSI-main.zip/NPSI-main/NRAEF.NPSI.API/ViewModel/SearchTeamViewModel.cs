﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class SearchTeamViewModel
    {
        public string TeamEntity { get; set; }
        public string SchoolName { get; set; }
        public string TeamName { get; set; }
        public string PhoneNumber { get; set; }
        public int? CategoryID { get; set; }
        public string Email { get; set; }
        public bool? Active { get; set; }
        public string SortedBy { get; set; }
        public int? PageNumber { get; set; }
        public int? ItemsPerPage { get; set; }
        public bool? ReturnTotalCount { get; set; }
    }
}