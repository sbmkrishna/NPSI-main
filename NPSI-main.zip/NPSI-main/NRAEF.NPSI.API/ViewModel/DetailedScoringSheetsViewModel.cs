﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class DetailedScoringSheetsViewModel
    {
        public int EventID { get; set; }
        public int SectionID { get; set; }
        public int CategoryID { get; set; }
        public int? TeamID { get; set; }
        public short? SortOrder { get; set; }
        public string SectionName { get; set; }
        public string EventName { get; set; }
        public string CategoryName { get; set; }
        public string TeamName { get; set; }
        public string JudgeUserID { get; set; }
        public string JudgeName { get; set; }
        public string JudgeContact { get; set; }
        public string JudgePhone { get; set; }
        public bool TimeInOutNeeded { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public List<SubsectionScoreViewModel> Subsections { get; set; }
        public List<DisqualificationViewModel> Disqualifications { get; set; }
        public List<PenaltyViewModel> Penalties { get; set; }
    }

    public class ListDetailedScoringSheetsViewModel
    {
        public List<DetailedScoringSheetsViewModel> ListData { get; set; }
        public ListDetailedScoringSheetsViewModel()
        {
            this.ListData = new List<DetailedScoringSheetsViewModel>();
        }
    }
}