﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class JugdeSubsectionAssignmentViewModel
    {
        public string JudgeUserID { get; set; }
        public string SubsectionName { get; set; }
        public int EventID { get; set; }
        public int SubsectionID { get; set; }
        public bool IsExisted { get; set; }
    }
}