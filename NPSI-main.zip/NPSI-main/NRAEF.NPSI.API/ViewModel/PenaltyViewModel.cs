﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class PenaltyViewModel
    {
        public int? ID { get; set; }
        public string Name { get; set; }
        public string DeductionRange { get; set; }
        public decimal? Deduction { get; set; }
        public decimal DeductionMin { get; set; }
        public decimal? DeductionMax { get; set; }
        public bool Active { get; set; }
        public decimal? DeductionScore { get; set; }
        public List<PenaltyQuestionViewModel> Questions { get; set; }
    }
}