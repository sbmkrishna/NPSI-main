﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class CriteriaViewModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public int? MaxScore { get; set; }
        public int MinScore { get; set; }
        public int SubsectionId { get; set; }
      
    }
}