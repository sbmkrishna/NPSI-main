﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class EventViewModel
    {
        public int? ID { get; set; }
        public string Name { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string CreatedByUserID { get; set; }
        public int? StatusID { get; set; }
        public List<CategoryViewModel> Categories { get; set; }
        public List<short> CategoryIDs { get; set; }
        public string StatusName { get; set; }
        public string CategoryName { get; set; }
        public DateTimeOffset? StatusLogDatetime { get; set; }
        public int Sections { get; set; }
        public int Subsections { get; set; }
    }
}