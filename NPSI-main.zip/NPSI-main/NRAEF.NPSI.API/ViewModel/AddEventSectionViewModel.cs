﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class AddEventSectionViewModel
    {
        public int EventID { get; set; }
        public List<EventSectionViewModel> EventSection { get; set; }
    }
}