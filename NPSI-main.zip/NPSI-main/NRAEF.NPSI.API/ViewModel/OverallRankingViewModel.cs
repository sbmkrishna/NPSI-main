﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class OverallRankingViewModel
    {
        public List<OverallRankingEventViewModel> Overall { get; set; }
        public List<OverallRankingSectionViewModel> Sections { get; set; }

    }
}