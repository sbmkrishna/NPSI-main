﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace NRAEF.NPSI.API.ViewModel
{
    public class AspNetUserViewModel
    {
        public string Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public bool IsSuperAdmin { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public byte[] Photo { get; set; }
        public bool Active { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public List<string> Roles { get; set; }
        public string Fullname { get; set; }
        public bool Lock { get; set; }
        public string Status { get; set; }
        public bool IsJudge { get; set; }
        public string Organization { get; set; }
  }
}