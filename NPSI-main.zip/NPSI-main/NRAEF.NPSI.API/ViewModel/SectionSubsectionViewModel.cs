﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class SectionSubsectionViewModel
    {
        public int SectionID { get; set; }
        public List<SubsectionIDandSortIndexViewModel> SubSorts { get; set; }
    }
}