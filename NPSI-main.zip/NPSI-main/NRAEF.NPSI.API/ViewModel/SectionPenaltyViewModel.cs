﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class SectionPenaltyViewModel
    {
        public int SectionID { get; set; }
        public List<int> Ids { get; set; }
    }
}