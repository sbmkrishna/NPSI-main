﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class TeamViewModel
    {
        public int? ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string PrimaryContactName { get; set; }
        public string SchoolName { get; set; }
        public string Entity { get; set; }
        public int SectionID { get; set; }
        public short CategoryID { get; set; }
        public string CategoryName { get; set; }
        public bool Active { get; set; }
        public List<MemberViewModel> Members { get; set; }
    }
}