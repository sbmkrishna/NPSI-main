﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class SubsectionScoreViewModel
    {
        public int EventID { get; set; }
        public int SectionID { get; set; }
        public int CategoryID { get; set; }
        public int TeamID { get; set; }
        public int SubSectionID { get; set; }
        public string SubSectionName { get; set; }
        public string JudgeUserID { get; set; }
        public string Description { get; set; }
        public int MinScore { get; set; }
        public int MaxScore { get; set; }
        public List<CriteriaViewModel> Criteria { get; set; }
        public ScoreViewModel Score { get; set; }
        public decimal? ScoreConcept { get; set; }
        public int? SortIndex { get; set; }
        public string Excellent { get; set; }
        public string VeryGood { get; set; }
        public string Good { get; set; }
        public string Fair { get; set; }
        public string Poor { get; set; }
        public string Comments { get; set; }
        public byte[] Image{ get; set; }
        public string Photo{ get; set; }
    }
}