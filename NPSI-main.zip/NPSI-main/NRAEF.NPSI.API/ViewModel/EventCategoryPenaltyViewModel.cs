﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
  public class EventCategoryPenaltyViewModel
  {
    public int ID { get; set; }
    public DateTimeOffset CreatedDateTime { get; set; }
    public int PenaltyID { get; set; }
    public string Penalty { get; set; }
    public string Comments { get; set; }
    public byte[] Photo { get; set; }
    public int EventID { get; set; }
    public int TeamID { get; set; }
    public string Team { get; set; }
    public string JudgeUserID { get; set; }
    public string JudgeLastName { get; set; }
    public string JudgeFirstName { get; set; }
    public string JudgeUserName { get; set; }
    public int SectionID { get; set; }
    public string Section { get; set; }
    public decimal Deduction { get; set; }
    public decimal DeductionMin { get; set; }
    public decimal? DeductionMax { get; set; }
    public string DeductionRange { get; set; }
    public string UpdatedUserID { get; set; }
    public List<PenaltyQuestionViewModel> Questions { get; set; }
    public int PenaltyStatusID { get; set; }
    public string StatusCode { get; set; }
    public string StatusName { get; set; }
  }

  public class TeamSectionPenaltyStatusViewModel
  {
    public int ID { get; set; }
    public int PenaltyStatusID { get; set; }
  }
}