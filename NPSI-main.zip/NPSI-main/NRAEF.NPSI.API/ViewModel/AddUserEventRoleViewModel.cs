﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class AddUserEventRoleViewModel
    {
        public int EventID { get; set; }
        public short CategoryID { get; set; }
        public List<UserRole> ListUser { get; set; }
    }
    public class UserRole
    {
        public string UserID { get; set; }
        public string RoleID { get; set; }
    }
}