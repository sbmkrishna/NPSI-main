﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class EventTeamViewModel
    {
        public int EventID { get; set; }
        public int TeamID { get; set; }
        public int CategoryID { get; set; }
        public string TeamName { get; set; }
        public string CategoryName { get; set; }
        public string SchoolName { get; set; }
        public DateTime Date { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public List<MemberViewModel> Members { get; set; }
        public List<AspNetUserViewModel> Judges { get; set; }
        public bool Done { get; set; }
        public List<SubsectionScoreViewModel> SubsectionScore { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public DateTime? DateTimeInOut { get; set; }
        public string JudgeUserID { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string PrimaryContactName { get; set; }
        public bool Active { get; set; }
        public int? SortOrder { get; set; }
        public int? PenaltyCount { get; set; }
        public string Comments { get; set; }
    }
}