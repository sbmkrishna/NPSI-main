﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class SearchEventViewModel
    {
        public string Name { get; set; }
        public List<int> ListStatusID { get; set; }
        public DateTime? StartDateFrom { get; set; }
        public DateTime? StartDateTo { get; set; }
        public DateTime? EndDateFrom { get; set; }
        public DateTime? EndDateTo { get; set; }
        public short? CategoryID { get; set; }
        public string SortedBy { get; set; }
        public int? PageNumber { get; set; }
        public int? ItemsPerPage { get; set; }
        public bool? ReturnTotalCount { get; set; }
    }
}