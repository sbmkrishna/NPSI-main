﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NRAEF.NPSI.API.ViewModel
{
    public class AddEditSectionSubsectionViewModel
    {
        public int SectionID { get; set; }
        public int SubsectionID { get; set; }
        public int? SortIndex { get; set; }
    }
}